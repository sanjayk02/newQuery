from math import ceil

from ppui.PySide.QtCore import QModelIndex, QPointF, QSize, Qt, QTimer
from ppui.PySide.QtGui import QPainter, QPalette, QTextLayout, QTextOption
from ppui.PySide.QtWidgets import (
    QHeaderView,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableView,
    QTreeView,
)


class WrapTextDelegate(QStyledItemDelegate):
    def __init__(self, view: QTableView | QTreeView) -> None:
        super().__init__(view)
        self._view = view

    def _cellWidth(self, index: QModelIndex) -> int:
        return self._view.columnWidth(index.column()) - int(self._view.showGrid())

    def _textLayout(
        self, option: QStyleOptionViewItem, width: int,
    ) -> tuple[QTextLayout, float]:
        text = option.text.replace('\r\n', '\n').replace('\r', '\n')
        layout = QTextLayout(text.replace('\n', '\u2028'), option.font)
        textOption = QTextOption()
        textOption.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        textOption.setAlignment(option.displayAlignment & Qt.AlignmentFlag.AlignHorizontal_Mask)
        layout.setTextOption(textOption)
        height = 0.0
        layout.beginLayout()
        while True:
            line = layout.createLine()
            if not line.isValid():
                break
            line.setLineWidth(max(1, width))
            line.setPosition(QPointF(0, height))
            height += line.height()
        layout.endLayout()
        return layout, height

    def _textMargin(self) -> int:
        return self._view.style().pixelMetric(
            QStyle.PixelMetric.PM_FocusFrameHMargin, None, self._view,
        ) + 1

    def sizeHint(self, option: QStyleOptionViewItem, index: QModelIndex) -> QSize:
        size = super().sizeHint(option, index)
        if not self._view.wordWrap():
            return size
        return self._wrappedSizeHint(option, index, self._cellWidth(index), size)

    def _wrappedSizeHint(
        self, option: QStyleOptionViewItem, index: QModelIndex, width: int, size: QSize,
    ) -> QSize:
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        if opt.text and width > 0:
            _, height = self._textLayout(opt, width - 2 * self._textMargin())
            return QSize(size.width(), max(size.height(), ceil(height)))
        return size

    def paint(
        self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex,
    ) -> None:
        if not self._view.wordWrap():
            super().paint(painter, option, index)
            return

        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        if not opt.text:
            super().paint(painter, option, index)
            return

        margin = self._textMargin()
        textRect = opt.rect.adjusted(margin, 0, -margin, 0)
        layout, height = self._textLayout(opt, textRect.width())
        # Let the style draw the cell background and focus before painting the text.
        opt.text = ''
        self._view.style().drawControl(
            QStyle.ControlElement.CE_ItemViewItem, opt, painter, self._view,
        )

        top = textRect.top()
        if opt.displayAlignment & Qt.AlignmentFlag.AlignVCenter:
            top += max(0, (textRect.height() - height) / 2)
        elif opt.displayAlignment & Qt.AlignmentFlag.AlignBottom:
            top += max(0, textRect.height() - height)

        role = (
            QPalette.ColorRole.HighlightedText
            if opt.state & QStyle.StateFlag.State_Selected else QPalette.ColorRole.Text
        )
        painter.save()
        painter.setClipRect(textRect, Qt.ClipOperation.IntersectClip)
        painter.setPen(opt.palette.color(role))
        layout.draw(painter, QPointF(textRect.left(), top))
        painter.restore()


def configureDialogTableWrap(table: QTableView, enabled: bool) -> None:
    table.setWordWrap(enabled)
    if not enabled:
        return

    table.setItemDelegate(WrapTextDelegate(table))
    table.verticalHeader().setResizeContentsPrecision(-1)
    table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    resizeTimer = QTimer(table)
    resizeTimer.setSingleShot(True)
    resizeTimer.timeout.connect(table.resizeRowsToContents)
    table.horizontalHeader().sectionResized.connect(lambda *_: resizeTimer.start(0))
