"""Headless regression checks; substitutes unavailable pipeline imports only."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from PySide6 import QtCore, QtGui, QtWidgets

ROOT = Path(__file__).resolve().parents[1] / 'src' / 'ppiTracker'
for name in ('ppui', 'ppui.PySide', 'ppi_check', 'ppilib', 'ppilib.utils',
             'ppilib.utils.compat'):
    sys.modules[name] = types.ModuleType(name)
for module in (QtCore, QtGui, QtWidgets):
    sys.modules['ppui.PySide.' + module.__name__.split('.')[-1]] = module
for name, attr in (('apiClient', 'ApiClient'), ('tableData', 'Column')):
    module = types.ModuleType('ppi_check.' + name)
    setattr(module, attr, object)
    sys.modules[module.__name__] = module
path_module = types.ModuleType('ppilib.utils.compat.pathlib')
path_module.Path = Path
sys.modules[path_module.__name__] = path_module
serialize = types.ModuleType('ppilib.utils.serialize')
serialize.readJson = lambda path: json.loads(path.read_text())
serialize.writeJson = lambda path, data: path.write_text(json.dumps(data))
sys.modules[serialize.__name__] = serialize


def load(name):
    spec = importlib.util.spec_from_file_location('ppi_check.' + name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


editor = load('entityEditorDialog')
wrap = load('cellWrap')
prefs = load('appPrefs')
app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


def column(key, dtype='string'):
    col = Mock()
    for method, value in {'key': key, 'dataType': dtype, 'displayName': key,
                          'visibled': True, 'isSystem': False, 'scope': 'project',
                          'config': {'options': ['A', 'B']}}.items():
        getattr(col, method).return_value = value
    return col


class FeatureChecks(unittest.TestCase):
    def dialog(self, multi=True):
        groups = ['one', 'two'] if multi else ['one']
        entities = [{'id': group, 'data': {'notes': 'old', 'choice': 'A'}} for group in groups]
        api = Mock()
        dlg = editor.EntityEditorDialog(
            api, 'shots', groups, [column('notes'), column('choice', 'array')], entities,
        )
        self.addCleanup(dlg.close)
        return dlg, api

    def test_blank_bulk_input_keeps_existing_content(self):
        dlg, _ = self.dialog()
        dlg._widgets['notes'][0].setPlainText('temporary')
        dlg._widgets['notes'][0].clear()
        dlg._widgets['choice'][0].setCurrentText('')
        self.assertEqual(dlg._collectChanges(), {})

    def test_explicit_clear_can_be_undone_and_targets_only_chosen_field(self):
        dlg, _ = self.dialog()
        check = dlg._clearChecks['notes']
        check.setChecked(True)
        self.assertFalse(dlg._widgets['notes'][0].isEnabled())
        self.assertEqual(dlg._collectChanges(), {'notes': ''})
        check.setChecked(False)
        self.assertTrue(dlg._widgets['notes'][0].isEnabled())
        self.assertEqual(dlg._collectChanges(), {})

    def test_save_clears_each_selected_row_after_confirmation(self):
        dlg, api = self.dialog()
        dlg._clearChecks['notes'].setChecked(True)
        with patch.object(editor.QMessageBox, 'question', return_value=editor.QMessageBox.Ok) as ask:
            dlg.save()
        self.assertIn('Clear content in 2 selected rows', ask.call_args.args[2])
        self.assertEqual(api.updateEntity.call_count, 2)
        for call in api.updateEntity.call_args_list:
            self.assertEqual(call.args[-1], {'notes': ''})

    def test_cancel_does_not_write(self):
        dlg, api = self.dialog()
        dlg._clearChecks['choice'].setChecked(True)
        with patch.object(editor.QMessageBox, 'question', return_value=editor.QMessageBox.Cancel):
            dlg.save()
        api.updateEntity.assert_not_called()
        api.createEntity.assert_not_called()

    def test_single_edit_can_still_clear_text(self):
        dlg, _ = self.dialog(multi=False)
        self.assertFalse(dlg._clearChecks)
        dlg._widgets['notes'][0].clear()
        self.assertEqual(dlg._collectChanges(), {'notes': ''})

    def test_wrap_height_tracks_column_width(self):
        table = QtWidgets.QTableView()
        self.addCleanup(table.close)
        model = QtGui.QStandardItemModel(1, 1)
        model.setItem(0, 0, QtGui.QStandardItem('Long text in this cell ' * 12))
        table.setModel(model)
        wrap.configureDialogTableWrap(table, True)
        table.setColumnWidth(0, 300)
        table.resizeRowsToContents()
        wide = table.rowHeight(0)
        table.setColumnWidth(0, 90)
        app.processEvents()
        table.resizeRowsToContents()
        self.assertGreater(table.rowHeight(0), wide)
        table.setWordWrap(False)
        table.resizeRowsToContents()
        self.assertLess(table.rowHeight(0), wide)

    def test_wrap_preference_survives_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'prefs.json'
            settings = prefs.AppPrefs.loadFromFile(path)
            self.assertFalse(settings.wrapText())
            settings.setWrapText(True)
            settings.saveToFile()
            self.assertTrue(prefs.AppPrefs.loadFromFile(path).wrapText())


if __name__ == '__main__':
    unittest.main()
