"""Headless regression checks; substitutes unavailable pipeline imports only."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from PySide6 import QtCore, QtGui, QtWidgets

ROOT = Path(__file__).resolve().parents[1] / 'src' / 'ppiTracker'
for name in ('ppui', 'ppui.PySide', 'ppi_check', 'ppilib', 'ppilib.utils',
             'ppilib.utils.compat'):
    sys.modules[name] = types.ModuleType(name)
for module in (QtCore, QtGui, QtWidgets):
    sys.modules['ppui.PySide.' + module.__name__.split('.')[-1]] = module
for name, attr in (('apiClient', 'ApiClient'), ('tableData', 'Column')):
    module = types.ModuleType('ppi_check.' + name)
    setattr(module, attr, object)
    sys.modules[module.__name__] = module
path_module = types.ModuleType('ppilib.utils.compat.pathlib')
path_module.Path = Path
sys.modules[path_module.__name__] = path_module
serialize = types.ModuleType('ppilib.utils.serialize')
serialize.readJson = lambda path: json.loads(path.read_text())
serialize.writeJson = lambda path, data: path.write_text(json.dumps(data))
sys.modules[serialize.__name__] = serialize


def load(name):
    spec = importlib.util.spec_from_file_location('ppi_check.' + name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


editor = load('entityEditorDialog')
wrap = load('cellWrap')
prefs = load('appPrefs')
app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


def column(key, dtype='string'):
    col = Mock()
    for method, value in {'key': key, 'dataType': dtype, 'displayName': key,
                          'visibled': True, 'isSystem': False, 'scope': 'project',
                          'config': {'options': ['A', 'B']}}.items():
        getattr(col, method).return_value = value
    return col


class FeatureChecks(unittest.TestCase):
    def dialog(self, multi=True):
        groups = ['one', 'two'] if multi else ['one']
        entities = [{'id': group, 'data': {'notes': 'old', 'choice': 'A'}} for group in groups]
        api = Mock()
        dlg = editor.EntityEditorDialog(
            api, 'shots', groups, [column('notes'), column('choice', 'array')], entities,
        )
        self.addCleanup(dlg.close)
        return dlg, api

    def test_blank_bulk_input_keeps_existing_content(self):
        dlg, _ = self.dialog()
        dlg._widgets['notes'][0].setPlainText('temporary')
        dlg._widgets['notes'][0].clear()
        dlg._widgets['choice'][0].setCurrentText('')
        self.assertEqual(dlg._collectChanges(), {})

    def context_owner(self):
        tree = ast.parse((ROOT / 'mainWindow.py').read_text(encoding='utf-8'))
        method = next(n for n in ast.walk(tree)
                      if isinstance(n, ast.FunctionDef) and n.name == 'clearSelectedContent')
        namespace = {'QModelIndex': QtCore.QModelIndex, 'QMessageBox': QtWidgets.QMessageBox}
        exec(compile(ast.Module(body=[method], type_ignores=[]), '<actual clear method>', 'exec'),
             namespace)
        owner = Mock()
        owner.GROUPPATH_ROLE = 100
        owner._root = 'shots'
        owner.canDirectEditCell.return_value = True
        owner.columnForIndex.return_value = column('notes')
        owner._getSelection.return_value = ['one', 'two']
        owner._entities = {}
        for group in ['one', 'two', 'outside']:
            entity = Mock()
            entity.id.return_value = group
            entity.data.return_value = {'notes': 'old', 'other': 'keep'}
            owner._entities[group] = entity
        index = Mock()
        index.data.return_value = 'one'
        return namespace['clearSelectedContent'], owner, index

    def test_context_clear_only_clicked_column_in_selected_rows(self):
        clear, owner, index = self.context_owner()
        with patch.object(QtWidgets.QMessageBox, 'question', return_value=QtWidgets.QMessageBox.Ok):
            clear(owner, index)
        self.assertEqual(owner._api.updateEntity.call_count, 2)
        self.assertEqual([c.args[2] for c in owner._api.updateEntity.call_args_list], ['one', 'two'])
        for call in owner._api.updateEntity.call_args_list:
            self.assertEqual(call.args[-1], {'notes': ''})
        self.assertEqual(owner.updateSingleEntity.call_count, 2)

    def test_context_cancel_does_not_write(self):
        clear, owner, index = self.context_owner()
        with patch.object(QtWidgets.QMessageBox, 'question', return_value=QtWidgets.QMessageBox.Cancel):
            clear(owner, index)
        owner._api.updateEntity.assert_not_called()

    def test_context_click_outside_selection_targets_only_clicked_row(self):
        clear, owner, index = self.context_owner()
        index.data.return_value = 'outside'
        with patch.object(QtWidgets.QMessageBox, 'question', return_value=QtWidgets.QMessageBox.Ok):
            clear(owner, index)
        owner._api.updateEntity.assert_called_once_with('outside', 'shots', 'outside', {'notes': ''})

    def test_context_readonly_does_not_write(self):
        clear, owner, index = self.context_owner()
        owner.canDirectEditCell.return_value = False
        clear(owner, index)
        owner._api.updateEntity.assert_not_called()

    def test_single_edit_can_still_clear_text(self):
        dlg, _ = self.dialog(multi=False)
        self.assertFalse(any(c.text() == 'Clear content' for c in dlg.findChildren(QtWidgets.QCheckBox)))
        dlg._widgets['notes'][0].clear()
        self.assertEqual(dlg._collectChanges(), {'notes': ''})

    def test_wrap_height_tracks_column_width(self):
        table = QtWidgets.QTableView()
        self.addCleanup(table.close)
        model = QtGui.QStandardItemModel(1, 1)
        model.setItem(0, 0, QtGui.QStandardItem('Long text in this cell ' * 12))
        table.setModel(model)
        wrap.configureDialogTableWrap(table, True)
        table.setColumnWidth(0, 300)
        table.resizeRowsToContents()
        wide = table.rowHeight(0)
        table.setColumnWidth(0, 90)
        app.processEvents()
        table.resizeRowsToContents()
        self.assertGreater(table.rowHeight(0), wide)
        table.setWordWrap(False)
        table.resizeRowsToContents()
        self.assertLess(table.rowHeight(0), wide)

    def test_wrap_preference_survives_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'prefs.json'
            settings = prefs.AppPrefs.loadFromFile(path)
            self.assertFalse(settings.wrapText())
            settings.setWrapText(True)
            settings.saveToFile()
            self.assertTrue(prefs.AppPrefs.loadFromFile(path).wrapText())


if __name__ == '__main__':
    unittest.main()
