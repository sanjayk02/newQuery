__version__ = '3.1.00.00'
__copyright__ = 'Copyright © 2025 Polygon Pictures Inc. All rights reserved.'
