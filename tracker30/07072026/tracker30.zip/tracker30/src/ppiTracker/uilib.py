import sys
from contextlib import contextmanager
from traceback import format_exception
from types import TracebackType
from typing import Iterator, Type

from ppui.PySide.QtCore import Qt, QSize
from ppui.PySide.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QStyle,
    QWidget,
)

from .ui.messageBox import Ui_Dialog


@contextmanager
def excepthook(
    displayName: str,
    parent: QWidget | None = None,
) -> Iterator[None]:
    def _showDialog(
        type: Type[BaseException] | None,
        value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        title = displayName + ' Error'
        detail = ''.join(format_exception(type, value, traceback))
        dialog = MessageBox(title, str(value), detail, parent=parent)
        dialog.exec_()

    def _excepthook(
        type: Type[BaseException],
        value: BaseException,
        traceback: TracebackType,
    ) -> None:
        if type != RuntimeError:
            _showDialog(type, value, traceback)
        sys.__excepthook__(type, value, traceback)

    try:
        sys.excepthook = _excepthook
        yield

    except Exception as e:
        type, value, traceback = sys.exc_info()
        if type != RuntimeError:
            _showDialog(type, value, traceback)
        raise e

    finally:
        sys.excepthook = sys.__excepthook__


class MessageBox(QDialog, Ui_Dialog):
    def __init__(
        self,
        title: str,
        error: str,
        detail: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setupUi(self)
        self.showDetail = False
        self.detailText = '%s Details...'
        self.detailTextEditHeight = self.detailTextEdit.height()

        self.setWindowTitle(title)
        self.errorLabel.setText(error)
        self.detailTextEdit.setText(detail)
        criticalIcon = self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxCritical)
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowCloseButtonHint)
        self.iconLabel.setPixmap(criticalIcon.pixmap(QSize(64, 64)))
        self.showDetailButton = self.buttonBox.addButton(
            self.detailText % 'Show', QDialogButtonBox.ButtonRole.ActionRole
        )
        self.line.setVisible(False)
        self.detailTextEdit.setVisible(False)
        self.resize(self.width(), self.minimumSizeHint().height())

        self.buttonBox.button(QDialogButtonBox.StandardButton.Ok).clicked.connect(self._okClicked)
        self.showDetailButton.clicked.connect(self._showDetail)

    def _okClicked(self):
        self.close()

    def _showDetail(self):
        self.showDetail = not self.showDetail
        buttonText = self.detailText % ('Show' if not self.showDetail else 'Hide')
        self.showDetailButton.setText(buttonText)
        self.line.setVisible(self.showDetail)
        self.detailTextEdit.setVisible(self.showDetail)
        width = self.width()
        if not self.showDetail:
            self.detailTextEditHeight = self.detailTextEdit.height()
        else:
            self.detailTextEdit.setMinimumHeight(self.detailTextEditHeight)
        self.adjustSize()
        self.resize(width, self.minimumSizeHint().height())
