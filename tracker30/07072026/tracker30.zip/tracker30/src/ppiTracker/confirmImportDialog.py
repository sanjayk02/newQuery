from ppui.desktop.style.default import Colors
from ppui.PySide.QtGui import QColor
from ppui.PySide.QtWidgets import (
    QDialog,
    QHeaderView,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QAbstractItemView,
    QWidget,
)

from .config import CsvEntityData


class ConfirmImportDialog(QDialog):
    def __init__(
        self,
        changes: list[CsvEntityData],
        displayColumns: list[str],
        parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle('Confirm Import')
        self.resize(1000, 600)
        self._changes = changes
        self._displayColumns = displayColumns

        self._layout = QVBoxLayout(self)

        self._label = QLabel(f'{len(changes)} items will be updated. Please confirm the changes.')
        self._layout.addWidget(self._label)

        self._table = QTableWidget(self)

        headers = ['Name'] + self._displayColumns
        self._table.setColumnCount(len(headers))
        self._table.setHorizontalHeaderLabels(headers)

        self._table.setAlternatingRowColors(True)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        # Use Interactive to allow resizing if many columns, or Stretch if few
        if len(headers) < 6:
            self._table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        else:
            self._table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)

        self._layout.addWidget(self._table)

        self._btnLayout = QHBoxLayout()
        self._btnCancel = QPushButton('Cancel')
        self._btnImport = QPushButton('Import')
        self._btnLayout.addStretch()
        self._btnLayout.addWidget(self._btnCancel)
        self._btnLayout.addWidget(self._btnImport)
        self._layout.addLayout(self._btnLayout)

        self._btnCancel.clicked.connect(self.reject)
        self._btnImport.clicked.connect(self.accept)

        self._buildTable()

    def _buildTable(self) -> None:
        self._table.setRowCount(len(self._changes))

        for i, item in enumerate(self._changes):
            entity = item['entity']
            changes = item['changes']
            groupName = entity.group()

            # Name Column
            self._table.setItem(i, 0, QTableWidgetItem(groupName))

            # Data Columns
            for colIdx, colKey in enumerate(self._displayColumns):
                tableColIdx = colIdx + 1  # Offset by 1 for Name column

                if colKey in changes:
                    rawChange = changes[colKey]
                    newVal = rawChange['value']
                    status = rawChange['status']
                    currentVal = entity.data().get(colKey, '')

                    itemWidget = QTableWidgetItem(str(newVal))
                    if status == 'error':
                        itemWidget.setForeground(QColor(Colors.RED))
                        itemWidget.setToolTip(f'Error: Type mismatch. \nCurrent: {currentVal}')
                    elif status == 'warning':
                        itemWidget.setForeground(QColor(Colors.ORANGE))
                        itemWidget.setToolTip(f'Warning: Option missing. \nCurrent: {currentVal}')
                    else:  # valid
                        itemWidget.setForeground(QColor(Colors.GREEN))
                        itemWidget.setToolTip(f'Valid update. \nCurrent: {currentVal}')
                    self._table.setItem(i, tableColIdx, itemWidget)
                else:
                    currentVal = entity.data().get(colKey, '')
                    itemWidget = QTableWidgetItem(str(currentVal))
                    self._table.setItem(i, tableColIdx, itemWidget)
