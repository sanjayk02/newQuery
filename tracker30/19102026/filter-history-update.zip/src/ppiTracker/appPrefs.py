from typing import Any, Dict

from ppilib.utils.compat.pathlib import Path
from ppilib.utils.serialize import readJson, writeJson


class AppPrefs(object):
    __slots__ = ('_appPrefsPath', '_columnOrder', '_filterHistory', '_filterBookmarks')

    FILTER_HISTORY_LIMIT = 5

    @classmethod
    def loadFromFile(cls, filePath: Path) -> 'AppPrefs':
        data: Dict[str, Any] = readJson(filePath) if filePath.exists() else {}
        columnOrder: dict[str, dict[str, list[str]]] = data.get('column_order', {})
        return cls(
            columnOrder, filePath,
            data.get('filter_history', {}), data.get('filter_bookmarks', {}),
        )

    def __init__(
        self,
        columnOrder: dict[str, dict[str, list[str]]],
        filePath: Path,
        filterHistory: dict | None = None,
        filterBookmarks: dict | None = None,
    ) -> None:
        self._appPrefsPath = filePath
        self._columnOrder = columnOrder
        self._filterHistory = filterHistory if isinstance(filterHistory, dict) else {}
        self._filterBookmarks = filterBookmarks if isinstance(filterBookmarks, dict) else {}

    def columnOrder(self, projectKeyName: str, root: str) -> list[str]:
        if projectKeyName not in self._columnOrder or root not in self._columnOrder[projectKeyName]:
            if projectKeyName not in self._columnOrder:
                self._columnOrder[projectKeyName] = {}
            self._columnOrder[projectKeyName][root] = []
        return self._columnOrder[projectKeyName][root]

    def setColumnOrder(self, projectKeyName: str, root: str, columnKeys: list[str]) -> None:
        if projectKeyName not in self._columnOrder:
            self._columnOrder[projectKeyName] = {}
        self._columnOrder[projectKeyName][root] = columnKeys

    @staticmethod
    def _filterItems(data: dict, projectKeyName: str, root: str) -> list[str]:
        projectData = data.get(projectKeyName, {})
        if not isinstance(projectData, dict):
            return []
        items = projectData.get(root, [])
        if not isinstance(items, list):
            return []
        result: list[str] = []
        for item in items:
            if isinstance(item, str) and item.strip() and item.strip() not in result:
                result.append(item.strip())
        return result

    @staticmethod
    def _setFilterItems(data: dict, projectKeyName: str, root: str, items: list[str]) -> None:
        if not isinstance(data.get(projectKeyName), dict):
            data[projectKeyName] = {}
        data[projectKeyName][root] = list(items)

    def filterHistory(self, projectKeyName: str, root: str) -> list[str]:
        return self._filterItems(self._filterHistory, projectKeyName, root)[
            :self.FILTER_HISTORY_LIMIT
        ]

    def rememberFilter(self, projectKeyName: str, root: str, text: str) -> bool:
        text = text.strip()
        if not text:
            return False
        history = self.filterHistory(projectKeyName, root)
        updated = [text] + [item for item in history if item != text]
        updated = updated[:self.FILTER_HISTORY_LIMIT]
        if updated == history:
            return False
        self._setFilterItems(self._filterHistory, projectKeyName, root, updated)
        return True

    def filterBookmarks(self, projectKeyName: str, root: str) -> list[str]:
        return self._filterItems(self._filterBookmarks, projectKeyName, root)

    def setFilterBookmarked(
        self, projectKeyName: str, root: str, text: str, bookmarked: bool,
    ) -> bool:
        text = text.strip()
        if not text:
            return False
        bookmarks = self.filterBookmarks(projectKeyName, root)
        if bookmarked:
            if text in bookmarks:
                return False
            bookmarks.insert(0, text)
        else:
            if text not in bookmarks:
                return False
            bookmarks.remove(text)
        self._setFilterItems(self._filterBookmarks, projectKeyName, root, bookmarks)
        return True

    def asDict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if self._columnOrder:
            data['column_order'] = self._columnOrder
        if self._filterHistory:
            data['filter_history'] = self._filterHistory
        if self._filterBookmarks:
            data['filter_bookmarks'] = self._filterBookmarks
        return data

    def saveToFile(self, filePath: Path | None = None) -> None:
        _filePath = filePath
        if _filePath is None:
            _filePath = self._appPrefsPath
        _filePath.parent.mkdir(exist_ok=True, parents=True)
        writeJson(_filePath, self.asDict())
