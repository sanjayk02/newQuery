from logging import getLogger
from typing import TYPE_CHECKING

from ppui.PySide.QtCore import QRect, QSize, Qt, QTimer
from ppui.PySide.QtGui import QColor, QIcon, QPainter, QPalette, QPixmap
from ppui.PySide.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu, QMessageBox, QPushButton,
    QScrollArea, QToolButton, QVBoxLayout, QWidget, QWidgetAction,
)

if TYPE_CHECKING:
    from .state import State

_logger = getLogger(__name__)


class FilterHistoryButton(QToolButton):
    """Recent filters and persistent bookmarks for one project and entity tab."""

    def __init__(
        self, lineEdit: QLineEdit, state: 'State', root: str, parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._lineEdit = lineEdit
        self._state = state
        self._root = root
        self._refreshPending = False
        self._menu = QMenu(self)
        self._menu.aboutToShow.connect(self._prepareMenu)
        self.setMenu(self._menu)
        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.setObjectName('filterHistoryButton')
        self.setText('History')
        self.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.setArrowType(Qt.ArrowType.DownArrow)
        self.setFixedWidth(90)
        self.setToolTip('Filter history and bookmarks')
        self.setAccessibleName('Filter history and bookmarks')
        self._lineEdit.editingFinished.connect(self._rememberFilter)
        self._lineEdit.setToolTip(
            'Space separated for AND search. Press Enter or leave the field to save to history.'
        )

    def _rememberFilter(self) -> None:
        text = self._lineEdit.text().strip()
        if not text:
            return
        try:
            self._state.rememberFilter(self._root, text)
        except Exception:
            self._reportSaveFailure()

    def _reportSaveFailure(self) -> None:
        _logger.exception('Could not save filter preferences for %s', self._root)
        QMessageBox.warning(
            self, 'Filter preferences',
            'Could not save filter history and bookmarks. '
            'Changes are available only in this session.',
        )

    def _prepareMenu(self) -> None:
        self._rememberFilter()
        self._populateMenu()

    def _populateMenu(self) -> None:
        self._menu.clear()
        history = self._state.filterHistory(self._root)
        bookmarks = self._state.filterBookmarks(self._root)
        panel = QWidget(self._menu)
        panelLayout = QVBoxLayout(panel)
        panelLayout.setContentsMargins(4, 4, 4, 4)
        scroll = QScrollArea(panel)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setMinimumWidth(340)
        content = QWidget(scroll)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(3)
        self._addSection(layout, 'History', history, bookmarks, content)
        self._addSection(layout, 'Bookmarks', bookmarks, bookmarks, content)
        scroll.setWidget(content)
        scroll.setFixedHeight(min(360, content.sizeHint().height() + 4))
        panelLayout.addWidget(scroll)
        action = QWidgetAction(self._menu)
        action.setDefaultWidget(panel)
        self._menu.addAction(action)

    def _addSection(
        self, layout: QVBoxLayout, title: str, items: list[str],
        bookmarks: list[str], parent: QWidget,
    ) -> None:
        heading = QLabel(title, parent)
        font = heading.font()
        font.setBold(True)
        heading.setFont(font)
        layout.addWidget(heading)
        if not items:
            empty = QLabel('No recent filters' if title == 'History' else 'No bookmarks', parent)
            empty.setEnabled(False)
            layout.addWidget(empty)
            return
        for text in items:
            row = QWidget(parent)
            rowLayout = QHBoxLayout(row)
            rowLayout.setContentsMargins(0, 0, 0, 0)
            rowLayout.setSpacing(4)
            applyButton = QPushButton(row)
            displayText = applyButton.fontMetrics().elidedText(
                text, Qt.TextElideMode.ElideRight, 260,
            )
            applyButton.setText(displayText.replace('&', '&&'))
            applyButton.setToolTip(text)
            applyButton.setAccessibleName('Apply filter: ' + text)
            applyButton.setFlat(True)
            applyButton.setStyleSheet('QPushButton { text-align: left; padding: 4px; }')
            applyButton.clicked.connect(lambda checked=False, query=text: self._applyFilter(query))
            rowLayout.addWidget(applyButton, 1)
            bookmarkButton = QToolButton(row)
            bookmarkButton.setCheckable(True)
            bookmarkButton.setChecked(text in bookmarks)
            bookmarkButton.setAutoRaise(True)
            bookmarkButton.setFixedSize(28, 26)
            bookmarkButton.setIconSize(QSize(18, 18))
            bookmarkButton.setIcon(self._bookmarkIcon(text in bookmarks))
            bookmarkButton.setToolTip(
                'Remove bookmark' if text in bookmarks else 'Bookmark filter'
            )
            bookmarkButton.setAccessibleName('Bookmark filter: ' + text)
            bookmarkButton.toggled.connect(
                lambda checked, query=text: self._toggleBookmark(query, checked)
            )
            rowLayout.addWidget(bookmarkButton)
            layout.addWidget(row)

    def _bookmarkIcon(self, bookmarked: bool) -> QIcon:
        # Overlapping-page outline, matching the icon requested for this feature.
        pixmap = QPixmap(18, 18)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor('#e5b64c') if bookmarked else self.palette().color(
            QPalette.ColorRole.ButtonText,
        )
        pen = painter.pen()
        pen.setColor(color)
        pen.setWidthF(1.3)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(QRect(2, 6, 11, 9), 1, 1)
        painter.setBrush(color if bookmarked else self.palette().color(QPalette.ColorRole.Button))
        painter.drawRoundedRect(QRect(5, 3, 11, 9), 1, 1)
        painter.end()
        return QIcon(pixmap)

    def _applyFilter(self, text: str) -> None:
        self._lineEdit.setText(text)
        self._rememberFilter()
        self._menu.close()
        self._lineEdit.setFocus()

    def _toggleBookmark(self, text: str, checked: bool) -> None:
        try:
            self._state.setFilterBookmarked(self._root, text, checked)
        except Exception:
            self._reportSaveFailure()
        # Rebuild after the button's signal finishes, keeping the popup open.
        if not self._refreshPending:
            self._refreshPending = True
            QTimer.singleShot(0, self._refreshMenu)

    def _refreshMenu(self) -> None:
        self._refreshPending = False
        self._populateMenu()
        self._menu.adjustSize()
