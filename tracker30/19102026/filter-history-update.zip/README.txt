Filter History update

Copy the four files under src/ppiTracker to the src/ppiTracker directory
actually used by your office batch launcher. Back up the office files first;
merge instead of overwriting if those files contain newer office changes.

Close all PPI Breakdown windows and relaunch through your usual batch file.
The filter bar now has a button labeled History between the search field
and Columns. Click History to see recent filters and bookmarks.

The console should print:
[FILTER_HISTORY_V1] enabled for assets; mainWindow source: ...mainWindow.py
[FILTER_HISTORY_V1] enabled for shots; mainWindow source: ...mainWindow.py

That source path identifies the code being loaded. If no marker appears,
the app may be loading another copy or suppressing INFO-level logs.
Provide the launcher contents (with private values removed) or the startup
console output to diagnose further; remote access is not necessary.
