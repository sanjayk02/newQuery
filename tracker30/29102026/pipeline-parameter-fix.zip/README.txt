PipelineParameter display update

Install BOTH files under src/ppiTracker into the actual office source folder
used by your launcher: mainWindow.py and service.py. Back up office files
first; use the included focused patch to merge if office code differs.
Keep the working filterHistory.py, appPrefs.py and state.py from the earlier
feature update. Fully close and relaunch PPI Breakdown after installing.

What changed
- Removed the generated allAssets/testAllAssets project-specific lookup.
- PipelineParameter columns read the parameter explicitly selected in
  Column Manager, including columns whose key is allAssets or cut_number.
- Stored strings are displayed unchanged. Booleans display true/false,
  zero displays 0, missing/None/empty text stays blank. Lists and objects
  retain their structure as JSON instead of being joined into text.
- The direct lookup is shared by Assets, Shots and CSV export.
- Existing Shots Number generation is preserved for its normal column.

Legacy allAssets columns: if a column previously relied on the automatic
lookup, edit it in Column Manager, choose Data Type = PipelineParameter,
and explicitly choose allAssets or testAllAssets as required. Saved server
column definitions are not automatically migrated.

Manual office verification (project potoodev)
Choose testMultiTasks as the parameter for a test column and refresh.
Expected values from the provided CentralWeb screenshots:
  testAssetA: fxTestDustA
  testAssetB: fxTestSparksA
  testAssetD: cfxTestDust
  testAssetC and camAim: blank
A toCfx column for testAssetA should show false. Compare against the same
project/repository source as CentralWeb. Confirm Shots and CSV as well.

Validation: 18 isolated local regression tests passed using the actual
worker/display methods with test repositories. The office server and its
live PPI environment were not accessible for a complete application run.
