Copy mainWindow.py and service.py from src/ppiTracker into the correct office tracker source folder. Preserve or merge newer office changes first. Fully close and relaunch PPI Breakdown. If the previous pipeline fix was already installed, only mainWindow.py needs updating.

Empty values including None, [], and {} display blank. False and zero remain visible. Selected PipelineParameter values are used without automatic allAssets/testAllAssets substitution. Existing filterHistory.py, appPrefs.py, and state.py remain in place.
