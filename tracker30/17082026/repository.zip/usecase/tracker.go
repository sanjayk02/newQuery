package usecase

import (
	"context"
	"errors"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Tracker struct {
	repo    *repository.Tracker
	prjRepo *repository.ProjectInfo
	stuRepo *repository.StudioInfo
}

func NewTracker(
	repo *repository.Tracker,
	pr *repository.ProjectInfo,
	sr *repository.StudioInfo,
) *Tracker {
	return &Tracker{
		repo:    repo,
		prjRepo: pr,
		stuRepo: sr,
	}
}

func toBsonM(v interface{}) (bson.M, error) {
	bytes, err := bson.Marshal(v)
	if err != nil {
		return nil, err
	}

	var doc bson.M
	if err := bson.Unmarshal(bytes, &doc); err != nil {
		return nil, err
	}

	return doc, nil
}

func (uc *Tracker) checkForProject(ctx context.Context, project string) error {
	db := uc.prjRepo.WithContext(ctx)
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	return err
}

func (uc *Tracker) checkForStudio(ctx context.Context, studio string) error {
	db := uc.stuRepo.WithContext(ctx)
	_, err := uc.stuRepo.Get(db, &entity.GetStudioInfoParams{
		KeyName: studio,
	})
	return err
}

func (u *Tracker) GetColumns(ctx context.Context, project string, root string) ([]entity.TrackerColumn, error) {
	return u.repo.GetColumns(ctx, project, root)
}

func (u *Tracker) CreateColumn(ctx context.Context, req entity.CreateColumnRequest) error {
	col := entity.TrackerColumn{
		ID:              primitive.NewObjectID(),
		Project:         req.Project,
		Root:            req.Root,
		Scope:           req.Scope,
		ExcludeProjects: req.ExcludeProjects,
		IsSystem:        req.IsSystem,
		Key:             req.Key,
		DisplayName:     req.DisplayName,
		DataType:        req.DataType,
		Config:          req.Config,
		Visibled:        req.Visibled,
		Deleted:         "0",
		CreatedAtUTC:    time.Now().UTC(),
		ModifiedAtUTC:   time.Now().UTC(),
		CreatedBy:       req.User,
		ModifiedBy:      req.User,
	}

	if col.IsSystem {
		col.Scope = "global"
		col.ExcludeProjects = nil
	}

	if col.Scope == "" {
		col.Scope = "project"
	}
	if col.Scope == "project" && col.Project == "" {
		return errors.New("project id required for project scope")
	}

	return u.repo.CreateColumn(ctx, col)
}

func (u *Tracker) UpdateColumn(ctx context.Context, idHex string, req entity.UpdateColumnRequest) error {
	id, _ := primitive.ObjectIDFromHex(idHex)

	current, err := u.repo.GetColumnByID(ctx, id)
	if err != nil {
		return err
	}

	bsonMData, err := toBsonM(current)
	if err != nil {
		return err
	}

	history := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		TargetID:      current.ID,
		TargetType:    "column",
		Action:        "update",
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      bsonMData,
	}
	if err := u.repo.CreateHistory(ctx, history); err != nil {
		return err
	}

	col := entity.TrackerColumn{
		ID:              id,
		DisplayName:     req.DisplayName,
		DataType:        req.DataType,
		Config:          req.Config,
		Visibled:        req.Visibled,
		Scope:           req.Scope,
		ExcludeProjects: req.ExcludeProjects,
		IsSystem:        req.IsSystem,
		ModifiedAtUTC:   time.Now().UTC(),
		ModifiedBy:      req.User,
	}

	if col.IsSystem {
		col.Scope = "global"
		col.ExcludeProjects = nil
	}
	if col.Scope == "" {
		col.Scope = "project"
	}

	return u.repo.UpdateColumn(ctx, col)
}

func (u *Tracker) DeleteColumn(ctx context.Context, idHex string, project string, req entity.DeleteColumnParams) error {
	id, _ := primitive.ObjectIDFromHex(idHex)
	current, err := u.repo.GetColumnByID(ctx, id)
	if err != nil {
		return err
	}
	if err := u.checkForProject(ctx, current.Project); err != nil {
		return err
	}
	if err := u.checkForStudio(ctx, req.Studio); err != nil {
		return err
	}

	bsonMData, err := toBsonM(current)
	if err != nil {
		return err
	}

	history := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		TargetID:      current.ID,
		TargetType:    "column",
		Action:        "delete",
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      bsonMData,
	}
	if err := u.repo.CreateHistory(ctx, history); err != nil {
		return err
	}
	return u.repo.SoftDeleteColumn(ctx, id)
}

func (u *Tracker) SearchEntities(ctx context.Context, req entity.SearchRequest) ([]entity.TrackerEntity, error) {
	return u.repo.SearchEntities(ctx, req)
}

func (u *Tracker) CreateEntity(ctx context.Context, req entity.CreateEntityRequest) error {
	ent := entity.TrackerEntity{
		ID:            primitive.NewObjectID(),
		Project:       req.Project,
		Root:          req.Root,
		Group:         req.Group,
		Data:          req.Data,
		CreatedAtUTC:  time.Now().UTC(),
		ModifiedAtUTC: time.Now().UTC(),
		CreatedBy:     req.User,
		ModifiedBy:    req.User,
		Deleted:       "0",
	}
	return u.repo.CreateEntity(ctx, ent)
}

func (u *Tracker) UpdateEntity(ctx context.Context, idHex string, req entity.UpdateEntityRequest) error {
	id, _ := primitive.ObjectIDFromHex(idHex)

	current, err := u.repo.GetEntityByID(ctx, id)
	if err != nil {
		return err
	}

	bsonMData, err := toBsonM(current)
	if err != nil {
		return err
	}

	history := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		EntityID:      current.ID,
		TargetID:      current.ID,
		TargetType:    "entity",
		Action:        "update",
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      bsonMData,
	}
	if err := u.repo.CreateHistory(ctx, history); err != nil {
		return err
	}

	current.Root = req.Root
	current.Group = req.Group
	current.ModifiedAtUTC = time.Now().UTC()
	current.ModifiedBy = req.User

	if current.Data == nil {
		current.Data = make(map[string]interface{})
	}
	for k, v := range req.Data {
		current.Data[k] = v
	}

	return u.repo.UpdateEntity(ctx, *current)
}

func (u *Tracker) DeleteEntity(ctx context.Context, idHex string, req entity.DeleteEntityParams) error {
	id, _ := primitive.ObjectIDFromHex(idHex)

	current, err := u.repo.GetEntityByID(ctx, id)
	if err != nil {
		return err
	}

	bsonMData, err := toBsonM(current)
	if err != nil {
		return err
	}

	history := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		EntityID:      current.ID,
		TargetID:      current.ID,
		TargetType:    "entity",
		Action:        "delete",
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      bsonMData,
	}
	if err := u.repo.CreateHistory(ctx, history); err != nil {
		return err
	}
	return u.repo.SoftDeleteEntity(ctx, id)
}

func (u *Tracker) GetHistories(ctx context.Context, entityIDHex string) ([]entity.History, error) {
	id, _ := primitive.ObjectIDFromHex(entityIDHex)
	return u.repo.GetHistories(ctx, id)
}

func (u *Tracker) RollbackTarget(ctx context.Context, entityIDHex string, req entity.RollbackRequest) error {
	entID, _ := primitive.ObjectIDFromHex(entityIDHex)
	histID, _ := primitive.ObjectIDFromHex(req.HistoryID)

	targetHistory, err := u.repo.GetHistoryByID(ctx, histID, "entity")
	if err != nil {
		return err
	}

	snapshot, err := targetHistory.DecodeSnapshot()
	if err != nil {
		return err
	}

	current, err := u.repo.GetEntityByID(ctx, entID)
	if err != nil {
		return err
	}

	bsonMData, err := toBsonM(current)
	if err != nil {
		return err
	}
	backupHistory := entity.History{
		ID:            primitive.NewObjectID(),
		Project:       current.Project,
		Studio:        req.Studio,
		EntityID:      current.ID,
		TargetID:      current.ID,
		TargetType:    "entity",
		Action:        "rollback",
		ModifiedAtUTC: time.Now().UTC(),
		ModifiedBy:    req.User,
		Snapshot:      bsonMData,
	}
	u.repo.CreateHistory(ctx, backupHistory)

	switch v := snapshot.(type) {
	case *entity.TrackerEntity:
		if targetHistory.EntityID != entID {
			return errors.New("history does not belong to this entity")
		}
		v.ModifiedAtUTC = time.Now().UTC()
		v.ModifiedBy = req.User
		v.Deleted = "0"
		return u.repo.RestoreEntity(ctx, *v)
	}
	// TODO: Column のロールバックも対応する場合は、ここに case を追加して処理を実装する
	return errors.New("unsupported snapshot type")
}
