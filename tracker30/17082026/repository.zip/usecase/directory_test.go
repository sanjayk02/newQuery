package usecase

import (
	"context"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"github.com/PolygonPictures/central30-web/front/testutil"
)

func TestDirectory_Create_CreateGroupDirectory(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.CreateProjectInfo(t, testDB, studio, project)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	u := newDirectoryUsecaseForTest(t, testDB)
	ctx := context.Background()
	params := &entity.CreateDirectoryParams{
		Project: project,
		Path:    path,
	}
	_, err := u.Create(ctx, params)
	require.Nil(t, err)

	var ms []*model.GroupDirectory
	result := testDB.Find(&ms)
	assert.Nil(t, result.Error)
	assert.Equal(t, int64(1), result.RowsAffected)

	got := ms[0]
	want := &model.GroupDirectory{
		Project:    "potoodev",
		Root:       "assets",
		Depth:      4,
		Path:       "shared/publish/assets/testHero",
		GroupDepth: 1,
		Status:     "active",
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(t, cmp.Diff(got, want, diffOpt))
}

func TestDirectory_DeleteFromProject_ToDeleteGroupDirectory(t *testing.T) {
	const studio = "ppidev"
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.CreateProjectInfo(t, testDB, studio, project)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	preset := []any{
		&model.Directory{
			Project: project,
			Path:    path,
			Depth:   4,
			Status:  "active",
		},
		&model.GroupDirectory{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       path,
			GroupDepth: 1,
			Status:     "active",
		},
	}
	for _, m := range preset {
		require.Nil(t, testDB.Create(m).Error)
	}

	u := newDirectoryUsecaseForTest(t, testDB)
	ctx := context.Background()
	params := &entity.DeleteDirectoryParams{
		Project: project,
		Path:    path,
	}
	require.Nil(t, u.DeleteFromProject(ctx, params))

	var ms []*model.GroupDirectory
	result := testDB.Find(&ms)
	assert.Nil(t, result.Error)
	assert.Equal(t, int64(1), result.RowsAffected)

	got := ms[0]
	want := &model.GroupDirectory{
		Project:    "potoodev",
		Root:       "assets",
		Depth:      4,
		Path:       "shared/publish/assets/testHero",
		GroupDepth: 1,
		Status:     "to_delete",
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(t, cmp.Diff(got, want, diffOpt))
}

func TestDirectory_DeleteFromProject_DeletedGroupDirectory(t *testing.T) {
	assert := assert.New(t)
	require := require.New(t)

	const studio = "ppidev"
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.CreateProjectInfo(t, testDB, studio, project)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)

	// 通常ないことだが、意図的に関連するスタジオが存在しないようにする
	testDB.Exec("UPDATE t_project_studio_map SET deleted = 1 WHERE project = ?", project)

	preset := []any{
		&model.Directory{
			Project: project,
			Path:    path,
			Depth:   4,
			Status:  "to_delete",
		},
		&model.GroupDirectory{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       path,
			GroupDepth: 1,
			Status:     "to_delete",
		},
	}
	for _, m := range preset {
		require.Nil(testDB.Create(m).Error)
	}

	u := newDirectoryUsecaseForTest(t, testDB)
	ctx := context.Background()
	params := &entity.DeleteDirectoryParams{
		Project: project,
		Path:    path,
	}
	require.Nil(u.DeleteFromProject(ctx, params))

	var ms []*model.GroupDirectory
	result := testDB.Find(&ms)
	assert.Nil(result.Error)
	assert.Equal(int64(1), result.RowsAffected)

	got := ms[0]
	want := &model.GroupDirectory{
		Project:    "potoodev",
		Root:       "assets",
		Depth:      4,
		Path:       "shared/publish/assets/testHero",
		GroupDepth: 1,
		Status:     "deleted",
		Deleted:    got.ID,
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(cmp.Diff(got, want, diffOpt))
}

func TestDirectory_DeleteFromStudio_DeletedGroupDirectory(t *testing.T) {
	assert := assert.New(t)
	require := require.New(t)

	const studio = "ppidev"
	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	const prefKey = "/ppip/roots/assets/groups"
	groups := "asset"

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.CreateProjectInfo(t, testDB, studio, project)
	testutil.AddProjectPreference(t, testDB, project, prefKey, &groups)
	testDB.Exec("INSERT t_studio_info (name) VALUES (?)", studio)

	preset := []any{
		&model.Directory{
			Project: project,
			Path:    path,
			Depth:   4,
			Status:  "to_delete",
		},
		&model.DirectoryDeletionLog{
			DirectoryID: 1,
			Studio:      studio,
			Status:      "to_delete",
		},
		&model.GroupDirectory{
			Project:    project,
			Root:       "assets",
			Depth:      4,
			Path:       path,
			GroupDepth: 1,
			Status:     "to_delete",
		},
	}
	for _, m := range preset {
		require.Nil(testDB.Create(m).Error)
	}

	u := newDirectoryUsecaseForTest(t, testDB)
	ctx := context.Background()
	params := &entity.DeleteDirectoryFromStudioParams{
		Project: project,
		Studio:  studio,
		Path:    path,
	}
	require.Nil(u.DeleteFromStudio(ctx, params))

	var ms []*model.GroupDirectory
	result := testDB.Find(&ms)
	assert.Nil(result.Error)
	assert.Equal(int64(1), result.RowsAffected)

	got := ms[0]
	want := &model.GroupDirectory{
		Project:    "potoodev",
		Root:       "assets",
		Depth:      4,
		Path:       "shared/publish/assets/testHero",
		GroupDepth: 1,
		Status:     "deleted",
		Deleted:    got.ID,
	}

	diffOpt := cmpopts.IgnoreFields(
		model.GroupDirectory{},
		"ID",
		"CreatedBy",
		"ModifiedBy",
		"CreatedAtUTC",
		"ModifiedAtUTC",
	)

	assert.Empty(cmp.Diff(got, want, diffOpt))
}

func newDirectoryUsecaseForTest(t *testing.T, db *gorm.DB) *Directory {
	t.Helper()

	drepo, err := repository.NewDirectory(db)
	require.Nil(t, err)

	ddirepo, err := repository.NewDirectoryDeletionInfo(db)
	require.Nil(t, err)

	psmrepo, err := repository.NewProjectStudioMap(db)
	require.Nil(t, err)

	pjrepo, err := repository.NewProjectInfo(db, psmrepo)
	require.Nil(t, err)

	sdrepo, err := repository.NewStudioInfo(db)
	require.Nil(t, err)

	psrepo, err := repository.NewPipelineSetting(db)
	require.Nil(t, err)

	gdrepo, err := repository.NewGroupDirectory(db)
	require.Nil(t, err)

	readTimeout := 1 * time.Second
	writeTimeout := 1 * time.Second
	return NewDirectory(
		drepo,
		pjrepo,
		sdrepo,
		ddirepo,
		psrepo,
		gdrepo,
		readTimeout,
		writeTimeout,
	)
}
