package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type ShotProperty struct {
	repo         *repository.ShotProperty
	prjRepo      *repository.ProjectInfo
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

func NewShotProperty(
	repo *repository.ShotProperty,
	pr *repository.ProjectInfo,
	readTimeout time.Duration,
	writeTimeout time.Duration,
) *ShotProperty {
	return &ShotProperty{
		repo:         repo,
		prjRepo:      pr,
		ReadTimeout:  readTimeout,
		WriteTimeout: writeTimeout,
	}
}

func (uc *ShotProperty) checkForProject(db *gorm.DB, project string) error {
	_, err := uc.prjRepo.Get(db, &entity.GetProjectInfoParams{
		KeyName: project,
	})
	return err
}

func (uc *ShotProperty) Get(
	ctx context.Context,
	params *entity.GetShotPropertyParams,
) (*entity.ShotProperty, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.ReadTimeout)
	defer cancel()
	db := uc.repo.WithContext(timeoutCtx)
	if err := uc.checkForProject(db, params.Project); err != nil {
		return nil, err
	}
	return uc.repo.Get(db, params)
}

func (uc *ShotProperty) Create(
	ctx context.Context,
	params *entity.CreateShotPropertyParams,
) (*entity.ShotProperty, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.WriteTimeout)
	defer cancel()
	var e *entity.ShotProperty
	if err := uc.repo.TransactionWithContext(timeoutCtx, func(tx *gorm.DB) error {
		var err error
		e, err = uc.repo.Create(tx, params)
		return err
	}); err != nil {
		return nil, err
	}

	return e, nil
}
