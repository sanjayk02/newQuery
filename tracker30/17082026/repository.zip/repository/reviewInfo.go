/* ──────────────────────────────────────────────────────────────────────────
	Module Name:
    	reviewInfo/reviewInfo.go

	Module Description:
		Repository for managing review information in the database.
	Details:
	- Implements CRUD operations for review information.
	- Supports listing assets and their review information.
	- Provides functions for counting and listing latest submissions with dynamic filtering and sorting.

	Update and Modification History:
	* - 29-10-2025 - SanjayK PSI - Implemented dynamic filtering and sorting for latest submissions.
	* - 17-11-2025 - SanjayK PSI - Added phase-aware status filtering and sorting.
	* - 22-11-2025 - SanjayK PSI - Fixed bugs related to phase-specific filtering and sorting.
	* - 16-01-2026 - SanjayK PSI - Added asset pivot listing with grouped view  and sorting.
	* - 02-02-2026 - SanjayK PSI - Added component field to AssetPivot and related functions for better component tracking.
	* - 05-02-2026 - Added take fields for each phase (MDL, RIG, BLD, DSN, LDV)
	* - 03-06-2026 - Added review-queue shot functions (CountReviewShots, ListReviewShots, ListReviewShotsPivot).

	Functions:
	* - List: Lists review information based on provided parameters.
	* - Get: Retrieves a specific review information record.
	* - Create: Creates a new review information record.
	* - Update: Updates an existing review information record.
	* - Delete: Marks a review information record as deleted.
	* - ListAssets: Lists unique assets based on review information.
	* - ListShotReviewInfos: Lists review information for a specific shot.
	* - ListAssetReviewInfos: Lists review information for a specific asset.
	* - CountLatestSubmissions: Counts latest submissions with dynamic filtering.
	* - ListLatestSubmissionsDynamic: Lists latest submissions with dynamic filtering and sorting.
	* - buildPhaseAwareStatusWhere: Constructs a WHERE clause for phase-aware status filtering.
	* - buildOrderClause: Constructs an ORDER BY clause based on sorting parameters.
	* - ListAssetsPivot: Lists pivoted assets with filtering and sorting options.
	* - CountReviewShots: Counts unique review-queue shot groups (check status).
	* - ListReviewShots: Lists paged latest per-phase review-queue shot rows.
	* - ListReviewShotsPivot: Lists review-queue shots pivoted into ShotPivot.
	* - ListReviewShotPhases: Returns the distinct review-queue phases (dynamic phase set).

	────────────────────────────────────────────────────────────────────────── */

package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

type ReviewInfo struct {
	db *gorm.DB
}

func NewReviewInfo(db *gorm.DB) (*ReviewInfo, error) {
	info := model.ReviewInfo{}

	// Specification change: https://jira.ppi.co.jp/browse/POTOO-2406
	migrator := db.Migrator()
	if migrator.HasTable(&info) && !migrator.HasColumn(&info, "take_path") {
		if err := migrator.RenameColumn(&info, "path", "take_path"); err != nil {
			return nil, err
		}
	}

	if err := db.AutoMigrate(&info); err != nil {
		return nil, err
	}

	return &ReviewInfo{
		db: db,
	}, nil
}

func (r *ReviewInfo) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *ReviewInfo) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *ReviewInfo) List(
	db *gorm.DB,
	params *entity.ListReviewInfoParams,
) ([]*entity.ReviewInfo, int, error) {
	stmt := db
	for i, g := range params.Group {
		stmt = stmt.Where(fmt.Sprintf("group_%d = ?", i+1), g)
	}
	stmt = stmt.Where("`project` = ?", params.Project)
	if params.Studio != nil {
		stmt = stmt.Where("`studio` = ?", *params.Studio)
	}
	if params.TaskID != nil {
		stmt = stmt.Where("`task_id` = ?", *params.TaskID)
	}
	if params.SubtaskID != nil {
		stmt = stmt.Where("`subtask_id` = ?", *params.SubtaskID)
	}
	if params.Root != nil {
		stmt = stmt.Where("`root` = ?", *params.Root)
	}
	for i, g := range params.Group {
		stmt = stmt.Where(fmt.Sprintf("`groups`->\"$[%d]\" = ?", i), g)
	}
	if params.Relation != nil {
		stmt = stmt.Where("relation IN (?)", params.Relation)
	}
	if params.Phase != nil {
		stmt = stmt.Where("phase IN (?)", params.Phase)
	}
	if params.Component != nil {
		stmt = stmt.Where("`component` = ?", *params.Component)
	}
	if params.Take != nil {
		stmt = stmt.Where("`take` = ?", *params.Take)
	}

	order := "`id` desc"
	if params.OrderBy != nil {
		order = *params.OrderBy
	}
	showDeleted := false
	if params.ModifiedSince != nil {
		stmt = stmt.Where("`modified_at_utc` >= ?", *params.ModifiedSince)
		order = "`modified_at_utc` asc"
		showDeleted = true
	} else {
		stmt.Where("`deleted` = ?", 0)
	}

	var total int64
	var m model.ReviewInfo
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var models []*model.ReviewInfo
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Order(
		order,
	).Limit(perPage).Offset(offset).Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.ReviewInfo
	for _, m := range models {
		entities = append(entities, m.Entity(showDeleted))
	}
	return entities, int(total), nil
}

type ReviewInfoAndShotProperty struct {
	model.ReviewInfo
	model.ShotProperty
}

func (r *ReviewInfo) List2(
	db *gorm.DB,
	params *entity.ListReviewInfoParams,
) ([]*entity.ReviewInfo, []*entity.ShotProperty, int, error) {
	stmtA := db.Select(
		"*",
	).Model(
		&model.ReviewInfo{},
	)

	for i, g := range params.Group {
		stmtA = stmtA.Where(fmt.Sprintf("group_%d = ?", i+1), g)
	}
	stmtA = stmtA.Where("project = ?", params.Project)
	if params.Studio != nil {
		stmtA = stmtA.Where("studio = ?", *params.Studio)
	}
	if params.TaskID != nil {
		stmtA = stmtA.Where("task_id = ?", *params.TaskID)
	}
	if params.SubtaskID != nil {
		stmtA = stmtA.Where("subtask_id = ?", *params.SubtaskID)
	}
	if params.Root != nil {
		stmtA = stmtA.Where("root = ?", *params.Root)
	}
	for i, g := range params.Group {
		stmtA = stmtA.Where(fmt.Sprintf("`groups`->\"$[%d]\" = ?", i), g)
	}
	if params.Relation != nil {
		stmtA = stmtA.Where("relation IN (?)", params.Relation)
	}
	if params.Phase != nil {
		stmtA = stmtA.Where("phase IN (?)", params.Phase)
	}
	if params.Component != nil {
		stmtA = stmtA.Where("component = ?", *params.Component)
	}
	if params.Take != nil {
		stmtA = stmtA.Where("take = ?", *params.Take)
	}

	order := "a.id desc"
	if params.OrderBy != nil {
		order = *params.OrderBy
	}
	showDeleted := false
	if params.ModifiedSince != nil {
		stmtA = stmtA.Where("modified_at_utc >= ?", *params.ModifiedSince)
		order = "a.modified_at_utc asc"
		showDeleted = true
	} else {
		stmtA = stmtA.Where("deleted = ?", 0)
	}

	stmtB := db.Select(
		"*",
	).Model(
		&model.ShotProperty{},
	)

	stmt := db.Select(
		"a.*",
		"b.*",
	).Table(
		"(?) AS a", stmtA,
	).Joins(
		"LEFT JOIN (?) AS b ON a.project = b.project AND a.take_path = b.path AND a.deleted = b.deleted", stmtB,
	)

	var total int64
	var m ReviewInfoAndShotProperty
	if err := stmt.Model(&m).Count(&total).Error; err != nil {
		return nil, nil, 0, err
	}

	var models []*ReviewInfoAndShotProperty

	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Order(
		order,
	).Limit(perPage).Offset(offset).Find(&models).Error; err != nil {
		return nil, nil, 0, err
	}

	var entities []*entity.ReviewInfo
	var shotEntities []*entity.ShotProperty
	for _, m := range models {
		entities = append(entities, m.ReviewInfo.Entity(showDeleted))
		// entities[len(entities)-1].ShotData = entity.JSONObject(m.ShotProperty.Data)
		shotEntities = append(shotEntities, m.ShotProperty.Entity(showDeleted))
	}
	return entities, shotEntities, int(total), nil
}

func (r *ReviewInfo) Get(
	db *gorm.DB,
	params *entity.GetReviewParams,
) (*entity.ReviewInfo, error) {
	var m model.ReviewInfo
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	return m.Entity(false), nil
}

func (r *ReviewInfo) Create(
	tx *gorm.DB,
	params *entity.CreateReviewInfoParams,
) (*entity.ReviewInfo, error) {
	m := model.NewReviewInfo(params)
	if err := tx.Create(m).Error; err != nil {
		return nil, err
	}
	return m.Entity(false), nil
}

func (r *ReviewInfo) Update(
	tx *gorm.DB,
	params *entity.UpdateReviewInfoParams,
) (*entity.ReviewInfo, error) {
	now := time.Now().UTC()
	modifiedBy := ""
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m model.ReviewInfo
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, entity.ErrRecordNotFound
		}
		return nil, err
	}
	var modified = false
	if params.ApprovalStatus != nil {
		m.ApprovalStatus = *params.ApprovalStatus
		m.ApprovalStatusUpdatedAtUtc = now
		modified = true
	}
	if params.ApprovalStatusUpdatedUser != nil {
		m.ApprovalStatusUpdatedUser = *params.ApprovalStatusUpdatedUser
		m.ApprovalStatusUpdatedAtUtc = now
		modified = true
	}
	if params.WorkStatus != nil {
		m.WorkStatus = *params.WorkStatus
		m.WorkStatusUpdatedAtUtc = now
		modified = true
	}
	if params.WorkStatusUpdatedUser != nil {
		m.WorkStatusUpdatedUser = *params.WorkStatusUpdatedUser
		m.WorkStatusUpdatedAtUtc = now
		modified = true
	}
	if !modified {
		return nil, errors.New("no value is given to change")
	}
	m.ModifiedAtUTC = now
	m.ModifiedBy = modifiedBy
	return m.Entity(false), tx.Save(m).Error
}

func (r *ReviewInfo) Delete(
	tx *gorm.DB,
	params *entity.DeleteReviewInfoParams,
) error {
	now := time.Now().UTC()
	var modifiedBy string
	if params.ModifiedBy != nil {
		modifiedBy = *params.ModifiedBy
	}
	var m model.ReviewInfo
	if err := tx.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`id` = ?", params.ID,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return entity.ErrRecordNotFound
		}
		return err
	}
	m.Deleted = m.ID
	m.ModifiedAtUTC = now
	m.ModifiedBy = modifiedBy
	return tx.Save(m).Error
}

func (r *ReviewInfo) ListAssets(
	db *gorm.DB,
	params *entity.AssetListParams,
) ([]*entity.Asset, int, error) {
	stmt := db.Model(
		&ReviewInfo{},
	).Where(
		"deleted = ?", 0,
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "assets",
	).Group(
		"project",
	).Group(
		"root",
	).Group(
		"group_1",
	).Group(
		"relation",
	)

	var total int64
	if err := stmt.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	stmt = stmt.Order(
		"group_1",
	).Order(
		"relation",
	)

	var reviews []*model.ReviewInfo
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Select(
		"project", "root", "group_1", "relation",
	).Limit(perPage).Offset(offset).Find(&reviews).Error; err != nil {
		return nil, 0, err
	}

	assets := make([]*entity.Asset, len(reviews))
	for i, review := range reviews {
		assets[i] = &entity.Asset{
			Name:     review.Group1,
			Relation: review.Relation,
		}
	}
	return assets, int(total), nil
}

func (r *ReviewInfo) ListAssetReviewInfos(
	db *gorm.DB,
	params *entity.AssetReviewInfoListParams,
) ([]*entity.ReviewInfo, error) {
	stmtA := db.Select(
		"project",
		"root",
		"group_1",
		"relation",
		"phase",
		"MAX(modified_at_utc) AS modified_at_utc",
	).Model(
		&model.ReviewInfo{},
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "assets",
	).Where(
		"group_1 = ?", params.Asset,
	).Where(
		"relation = ?", params.Relation,
	).Where(
		"deleted = ?", 0,
	).Group(
		"project",
	).Group(
		"root",
	).Group(
		"group_1",
	).Group(
		"relation",
	).Group(
		"phase",
	)

	stmtB := db.Select(
		"*",
	).Model(
		&model.ReviewInfo{},
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "assets",
	).Where(
		"group_1 = ?", params.Asset,
	).Where(
		"relation = ?", params.Relation,
	).Where(
		"deleted = ?", 0,
	)

	stmt := db.Select(
		"b.*",
	).Table(
		"(?) AS a", stmtA,
	).Joins(
		"LEFT OUTER JOIN (?) AS b ON a.project = b.project AND a.root = b.root AND a.group_1 = b.group_1 AND a.relation = b.relation AND a.phase = b.phase AND a.modified_at_utc = b.modified_at_utc", stmtB,
	)

	var reviews []*model.ReviewInfo
	if err := stmt.Scan(&reviews).Error; err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	reviewInfos := make([]*entity.ReviewInfo, len(reviews))
	for i, review := range reviews {
		reviewInfos[i] = review.Entity(false)
	}
	return reviewInfos, nil
}

func (r *ReviewInfo) ListShots(
	db *gorm.DB,
	params *entity.AssetListParams,
) ([]*entity.Shot, int, error) {
	stmt := db.Model(
		&ReviewInfo{},
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "shots",
	).Where(
		"deleted = ?", 0,
	).Group(
		"project",
	).Group(
		"root",
	).Group(
		"group_1",
	).Group(
		"group_2",
	).Group(
		"group_3",
	).Group(
		"relation",
	)

	var total int64
	if err := stmt.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	stmt = stmt.Order(
		"group_1",
	).Order(
		"group_2",
	).Order(
		"group_3",
	).Order(
		"relation",
	)

	var reviews []*model.ReviewInfo
	perPage := params.GetPerPage()
	offset := perPage * (params.GetPage() - 1)
	if err := stmt.Select(
		"project", "root", "group_1", "group_2", "group_3", "relation",
	).Limit(perPage).Offset(offset).Find(&reviews).Error; err != nil {
		return nil, 0, err
	}

	shots := make([]*entity.Shot, len(reviews))
	for i, review := range reviews {
		shots[i] = &entity.Shot{
			Group1:   review.Group1,
			Group2:   review.Group2,
			Group3:   review.Group3,
			Relation: review.Relation,
		}
	}
	return shots, int(total), nil
}

func (r *ReviewInfo) ListShotReviewInfos(
	db *gorm.DB,
	params *entity.ShotReviewInfoListParams,
) ([]*entity.ReviewInfo, error) {
	stmtA := db.Select(
		"project",
		"root",
		"group_1",
		"group_2",
		"group_3",
		"relation",
		"phase",
		"MAX(modified_at_utc) AS modified_at_utc",
	).Model(
		&model.ReviewInfo{},
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "shots",
	).Where(
		"group_1 = ?", params.Groups[0],
	).Where(
		"group_2 = ?", params.Groups[1],
	).Where(
		"group_3 = ?", params.Groups[2],
	).Where(
		"relation = ?", params.Relation,
	).Where(
		"deleted = ?", 0,
	).Group(
		"project",
	).Group(
		"root",
	).Group(
		"group_1",
	).Group(
		"group_2",
	).Group(
		"group_3",
	).Group(
		"relation",
	).Group(
		"phase",
	)

	stmtB := db.Select(
		"*",
	).Model(
		&model.ReviewInfo{},
	).Where(
		"project = ?", params.Project,
	).Where(
		"root = ?", "shots",
	).Where(
		"group_1 = ?", params.Groups[0],
	).Where(
		"group_2 = ?", params.Groups[1],
	).Where(
		"group_3 = ?", params.Groups[2],
	).Where(
		"relation = ?", params.Relation,
	).Where(
		"deleted = ?", 0,
	)

	stmt := db.Select(
		"b.*",
	).Table(
		"(?) AS a", stmtA,
	).Joins(
		"LEFT OUTER JOIN (?) AS b ON a.project = b.project AND a.root = b.root AND a.group_1 = b.group_1 AND a.group_2 = b.group_2 AND a.group_3 = b.group_3 AND a.relation = b.relation AND a.phase = b.phase AND a.modified_at_utc = b.modified_at_utc", stmtB,
	)

	var reviews []*model.ReviewInfo
	if err := stmt.Scan(&reviews).Error; err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	reviewInfos := make([]*entity.ReviewInfo, len(reviews))
	for i, review := range reviews {
		reviewInfos[i] = review.Entity(false)
	}
	return reviewInfos, nil
}

// ---- Asset Pivot Row ----
/* ──────────────────────────────────────────────────────────────────────────
	LatestSubmissionRow struct represents a row of data for the latest submissions,
	containing fields for project, root, group, relation, component, phase, and submission date.
	Each field is tagged for JSON serialization and GORM column mapping, facilitating
	easy integration with database queries and API responses.
   ────────────────────────────────────────────────────────────────────────── */
// ---- Latest Submission row ----
type LatestSubmissionRow struct {
	Root           string     `json:"root"              gorm:"column:root"`
	Project        string     `json:"project"           gorm:"column:project"`
	Group1         string     `json:"group_1"           gorm:"column:group_1"`
	Relation       string     `json:"relation"          gorm:"column:relation"`
	Component      string     `json:"component"         gorm:"column:component"`
	Phase          string     `json:"phase"             gorm:"column:phase"`
	SubmittedAtUTC *time.Time `json:"submitted_at_utc"  gorm:"column:submitted_at_utc"`
}

/*
	 ____________________________________________________________________________________
		The LatestSubmissionRow struct represents a row of data for the latest submissions,
		containing fields for project, root, group, relation, component, phase, and submission date.
		Each field is tagged for JSON serialization and GORM column mapping, facilitating
		easy integration with database queries and API responses.
	  ____________________________________________________________________________________
*/
type AssetPivot struct {
	Root      string `json:"root"`
	Project   string `json:"project"`
	Group1    string `json:"group_1"`
	Relation  string `json:"relation"`
	Component string `json:"component"`

	// Grouping info
	LeafGroupName     string `json:"leaf_group_name"`
	GroupCategoryPath string `json:"group_category_path"`
	TopGroupNode      string `json:"top_group_node"`

	// Latest review info fields (for ListAssetsPivot2)
	WorkStatus     *string    `json:"work_status"`
	ApprovalStatus *string    `json:"approval_status"`
	SubmittedAtUTC *time.Time `json:"submitted_at_utc"`
	ModifiedAtUTC  *time.Time `json:"modified_at_utc"`
	Take           *string    `json:"take"` // Added take field for generic phase

	// MDL Phase
	MDLWorkStatus     *string    `json:"mdl_work_status"`
	MDLApprovalStatus *string    `json:"mdl_approval_status"`
	MDLSubmittedAtUTC *time.Time `json:"mdl_submitted_at_utc"`
	MDLTake           *string    `json:"mdl_take"` // Added take for MDL
	MDLAssignTo       *string    `json:"modeling_assigned_to"`

	// RIG Phase
	RIGWorkStatus     *string    `json:"rig_work_status"`
	RIGApprovalStatus *string    `json:"rig_approval_status"`
	RIGSubmittedAtUTC *time.Time `json:"rig_submitted_at_utc"`
	RIGTake           *string    `json:"rig_take"` // Added take for RIG
	RIGAssignTo       *string    `json:"rigging_assigned_to"`

	// BLD Phase
	BLDWorkStatus     *string    `json:"bld_work_status"`
	BLDApprovalStatus *string    `json:"bld_approval_status"`
	BLDSubmittedAtUTC *time.Time `json:"bld_submitted_at_utc"`
	BLDTake           *string    `json:"bld_take"` // Added take for BLD

	// DSN Phase
	DSNWorkStatus     *string    `json:"dsn_work_status"`
	DSNApprovalStatus *string    `json:"dsn_approval_status"`
	DSNSubmittedAtUTC *time.Time `json:"dsn_submitted_at_utc"`
	DSNTake           *string    `json:"dsn_take"` // Added take for DSN
	DSNAssignTo       *string    `json:"dsn_assign_to"`

	// LDV Phase
	LDVWorkStatus     *string    `json:"ldv_work_status"`
	LDVApprovalStatus *string    `json:"ldv_approval_status"`
	LDVSubmittedAtUTC *time.Time `json:"ldv_submitted_at_utc"`
	LDVTake           *string    `json:"ldv_take"` // Added take for LDV
	LDVAssignTo       *string    `json:"lookdev_assigned_to"`
}

/*
	 ____________________________________________________________________________________
		The AssetPivot struct represents a pivoted view of asset review information,
		containing fields for project, root, group, relation, component, and phase.
		It also includes grouping information such as leaf group name, group category path,
		and top group node. Additionally, it has fields for the latest work status, approval status,
		submission date for the generic phase and specific fields for MDL, RIG, BLD, DSN, and LDV phases,
		including their respective work status, approval status, submission date, and take information.
	  ____________________________________________________________________________________
*/
type phaseRow struct {
	Project        string     `gorm:"column:project"`
	Root           string     `gorm:"column:root"`
	Group1         string     `gorm:"column:group_1"`
	Relation       string     `gorm:"column:relation"`
	Phase          string     `gorm:"column:phase"`
	WorkStatus     *string    `gorm:"column:work_status"`
	ApprovalStatus *string    `gorm:"column:approval_status"`
	SubmittedAtUTC *time.Time `gorm:"column:submitted_at_utc"`
	Component      *string    `gorm:"column:component"`
	Take           *string    `gorm:"column:take"` // Added take field

	LeafGroupName     string `gorm:"column:leaf_group_name"`
	GroupCategoryPath string `gorm:"column:group_category_path"`
	TopGroupNode      string `gorm:"column:top_group_node"`
}

// ---- Sort Direction ----
type SortDirection string

// SortDirection constants
const (
	SortASC  SortDirection = "ASC"
	SortDESC SortDirection = "DESC"
)

// ---- Grouped Asset Bucket ----
type GroupedAssetBucket struct {
	TopGroupNode string       `json:"top_group_node"` // camera / character / prop / ...
	ItemCount    int          `json:"item_count"`
	Items        []AssetPivot `json:"items"`
	TotalCount   *int         `json:"total_count"` // optional total count across pages
}

/*
──────────────────────────────────────────────────────────────────────────

	GroupAndSortByTopNode groups a slice of AssetPivot items by their TopGroupNode field,
	sorts the group headers alphabetically (A→Z, case-insensitive), and always places the
	"Unassigned" group last. Within each group, the items are sorted by their Group1 field
	in either ascending or descending order, as specified by the dir parameter.
	Returns a slice of GroupedAssetBucket, each containing a group header and its sorted items.

	Parameters:
	- rows: Slice of AssetPivot items to be grouped and sorted.
	- dir: SortDirection specifying ascending or descending order for items within each group.

	Returns:
	- []GroupedAssetBucket: Slice of grouped and sorted asset buckets.

───────────────────────────────────────────────────────────────────────────
*/
func GroupAndSortByTopNode(rows []AssetPivot, dir SortDirection) []GroupedAssetBucket {
	grouped := make(map[string][]AssetPivot)
	order := make([]string, 0)

	// group and collect TopGroupNode keys
	for _, row := range rows {
		key := strings.TrimSpace(row.TopGroupNode)
		if key == "" {
			key = "Unassigned" // represents NULL / no group
		}
		if _, exists := grouped[key]; !exists {
			grouped[key] = []AssetPivot{}
			order = append(order, key)
		}
		grouped[key] = append(grouped[key], row)
	}

	/* ____________________________________________________________________________________
	Sorting logic for group headers (TopGroupNode):
		1. "Unassigned" group (representing NULL/empty) is always placed last.
		2. All other group headers are sorted alphabetically (A→Z), case-insensitive.
	____________________________________________________________________________________*/
	isUnassigned := func(s string) bool {
		return strings.EqualFold(strings.TrimSpace(s), "unassigned")
	}

	sort.Slice(order, func(i, j int) bool {
		ai := strings.TrimSpace(order[i])
		aj := strings.TrimSpace(order[j])

		aui := isUnassigned(ai)
		auj := isUnassigned(aj)

		// Unassigned always last
		if aui && !auj {
			return false
		}
		if !aui && auj {
			return true
		}

		// Always A→Z (case-insensitive)
		return strings.ToLower(ai) < strings.ToLower(aj)
	})

	// sort children inside each group by Group1 using requested dir
	for _, key := range order {
		children := grouped[key]
		sort.SliceStable(children, func(i, j int) bool {
			gi := strings.ToLower(children[i].Group1)
			gj := strings.ToLower(children[j].Group1)

			if dir == SortDESC {
				return gi > gj
			}
			return gi < gj
		})
		grouped[key] = children
	}

	result := make([]GroupedAssetBucket, 0, len(order))
	for _, key := range order {
		result = append(result, GroupedAssetBucket{
			TopGroupNode: key,
			Items:        grouped[key],
		})
	}
	return result
}

/*
──────────────────────────────────────────────────────────────────────────

	buildPhaseAwareStatusWhere constructs a SQL WHERE clause segment that filters rows based on the provided
	approvalStatuses and workStatuses. It generates case-insensitive "IN" conditions for the columns
	"approval_status" and "work_status" if their respective status slices are non-empty.
	The function returns the WHERE clause string (prefixed with " AND ") and a slice of arguments
	corresponding to the status values, all converted to lowercase and trimmed of whitespace.
	If both status slices are empty, it returns an empty string and nil arguments.

───────────────────────────────────────────────────────────────────────────
*/
func buildPhaseAwareStatusWhere(_ string, approvalStatuses, workStatuses []string) (string, []any) {
	buildIn := func(col string, vals []string) (string, []any) {
		if len(vals) == 0 {
			return "", nil
		}
		ph := strings.Repeat("?,", len(vals))
		ph = ph[:len(ph)-1]

		args := make([]any, len(vals))
		for i, v := range vals {
			args[i] = strings.ToLower(strings.TrimSpace(v))
		}

		return fmt.Sprintf("LOWER(%s) IN (%s)", col, ph), args
	}

	clauses := []string{}
	args := []any{}

	if c, a := buildIn("approval_status", approvalStatuses); c != "" {
		clauses = append(clauses, "("+c+")")
		args = append(args, a...)
	}
	if c, a := buildIn("work_status", workStatuses); c != "" {
		clauses = append(clauses, "("+c+")")
		args = append(args, a...)
	}

	if len(clauses) == 0 {
		return "", nil
	}
	return " AND " + strings.Join(clauses, " AND "), args
}

/*
──────────────────────────────────────────────────────────────────────────

	buildOrderClause constructs an SQL ORDER BY clause string based on the provided
	alias, key, and direction. It supports various keys for sorting, including generic
	columns (e.g., submitted_at_utc, modified_at_utc, phase), name/relation combinations,
	phase-specific submitted dates, work status, and approval status. The direction
	(dir) is normalized to "ASC" or "DESC", defaulting to "ASC" if invalid. The alias
	is prepended to column names if provided. For unrecognized keys, a default ordering
	by group_1, relation, and submitted_at_utc is used. The function ensures proper
	handling of NULL values and alphabetical sorting where applicable.

	Parameters:

		alias string - Optional table alias to prefix column names.
		key   string - The column or logical key to sort by.
		dir   string - Sort direction ("ASC" or "DESC").

	Returns:

		string - The constructed SQL ORDER BY clause.

──────────────────────────────────────────────────────────────────────────
*/
func buildOrderClause(alias, key, dir string) string {
	dir = strings.ToUpper(strings.TrimSpace(dir))
	if dir != "ASC" && dir != "DESC" {
		dir = "ASC"
	}

	col := func(c string) string {
		if alias == "" {
			return c
		}
		return alias + "." + c
	}

	sortComponent := func() string {
		return fmt.Sprintf(
			"CASE WHEN %s IS NULL OR %s = '' THEN 1 ELSE 0 END ASC, LOWER(TRIM(%s)) %s",
			col("component"),
			col("component"),
			col("component"),
			dir,
		)
	}

	switch key {
	// generic columns
	case "submitted_at_utc", "modified_at_utc", "phase":
		return col(key) + " " + dir

	// name / relation
	case "group1_only":
		// PRIMARY for LIST VIEW:
		// ORDER BY group_1, relation, submitted_at_utc (NULL last)
		return fmt.Sprintf(
			"LOWER(%s) %s, LOWER(%s) ASC, (%s IS NULL) ASC, %s %s",
			col("group_1"), dir,
			col("relation"),
			col("submitted_at_utc"),
			col("submitted_at_utc"), dir,
		)

	case "relation_only":
		return fmt.Sprintf(
			"LOWER(%s) %s, LOWER(%s) ASC, (%s IS NULL) ASC, %s %s",
			col("relation"), dir,
			col("group_1"),
			col("submitted_at_utc"),
			col("submitted_at_utc"), dir,
		)

	case "component", "component_only":
		return fmt.Sprintf(
			"%s, LOWER(%s) ASC",
			sortComponent(),
			col("group_1"),
		)

	case "group_rel_submitted":
		return fmt.Sprintf(
			"LOWER(%s) ASC, LOWER(%s) ASC, (%s IS NULL) ASC, %s %s",
			col("group_1"),
			col("relation"),
			col("submitted_at_utc"),
			col("submitted_at_utc"), dir,
		)

	// phase-specific submitted date (NULL last)
	case "mdl_submitted", "rig_submitted", "bld_submitted", "dsn_submitted", "ldv_submitted":
		phase := strings.ToUpper(strings.Split(key, "_")[0])
		return fmt.Sprintf(
			"(CASE WHEN %s = '%s' THEN 0 ELSE 1 END) ASC, %s %s, LOWER(%s) ASC",
			col("phase"), phase,
			col("submitted_at_utc"), dir,
			col("group_1"),
		)

	// work columns (alphabetical, NULL last)
	case "mdl_work", "rig_work", "bld_work", "dsn_work", "ldv_work":
		phase := strings.ToUpper(strings.Split(key, "_")[0])
		return fmt.Sprintf(
			"(CASE WHEN %s = '%s' THEN 0 ELSE 1 END) ASC, (%s IS NULL) ASC, LOWER(%s) %s, LOWER(%s) ASC",
			col("phase"), phase,
			col("work_status"),
			col("work_status"), dir,
			col("group_1"),
		)

	case "work_status":
		return fmt.Sprintf(
			"(%s IS NULL) ASC, LOWER(%s) %s, LOWER(%s) ASC",
			col("work_status"),
			col("work_status"), dir,
			col("group_1"),
		)

	// approval columns (alphabetical, NULL last)
	case "mdl_appr", "rig_appr", "bld_appr", "dsn_appr", "ldv_appr":
		phase := strings.ToUpper(strings.Split(key, "_")[0])
		return fmt.Sprintf(
			"(CASE WHEN %s = '%s' THEN 0 ELSE 1 END) ASC, (%s IS NULL) ASC, LOWER(%s) %s, LOWER(%s) ASC",
			col("phase"), phase,
			col("approval_status"),
			col("approval_status"), dir,
			col("group_1"),
		)

	// ============================================
	// ALTERNATIVE: Using RIGHT() function (MySQL/PostgreSQL)
	// ============================================
	case "mdl_take", "rig_take", "bld_take", "dsn_take", "ldv_take":
		phase := strings.ToUpper(strings.Split(key, "_")[0])
		return fmt.Sprintf(
			"(CASE WHEN %s = '%s' THEN 0 ELSE 1 END) ASC, "+
				"CASE WHEN %s IS NULL OR %s = '' THEN 1 ELSE 0 END ASC, "+
				"CAST(RIGHT(%s, 4) AS UNSIGNED) %s, "+
				"LOWER(%s) ASC",
			col("phase"), phase,
			col("take"), col("take"),
			col("take"), dir,
			col("group_1"),
		)

	case "take":
		return fmt.Sprintf(
			"CASE WHEN %s IS NULL OR %s = '' THEN 1 ELSE 0 END ASC, "+
				"CAST(RIGHT(%s, 4) AS UNSIGNED) %s, "+
				"LOWER(%s) ASC",
			col("take"), col("take"),
			col("take"), dir,
			col("group_1"),
		)

	// default: group_1 + relation + submitted_at_utc
	default:
		return fmt.Sprintf(
			"LOWER(%s) %s, LOWER(%s) ASC, LOWER(TRIM(LEADING '_' FROM %s)) ASC, (%s IS NULL) ASC, %s %s",
			col("group_1"), dir,
			col("relation"),
			col("component"),
			col("submitted_at_utc"),
			col("submitted_at_utc"), dir,
		)
	}
}

/*
	──────────────────────────────────────────────────────────────────────────
	CountLatestSubmissions returns the count of latest review submissions for a given project and asset root,
	optionally filtered by asset name prefix, approval statuses, and work statuses.
	The function ignores the preferredPhase parameter for filtering but keeps it for API compatibility.
	It queries the database for the latest (by modified_at_utc) review info per asset and relation,
	applying the specified filters, and returns the total count.
	Returns an error if the project is not specified or if the database query fails.

	Parameters:
	ctx              - Context for database operations.
	project          - Project identifier (required).
	root             - Asset root; defaults to "assets" if empty.
	assetNameKey     - Optional asset name prefix filter (case-insensitive).
	preferredPhase   - Phase parameter (ignored in filtering; kept for compatibility).
	approvalStatuses - List of approval statuses to filter by.
	workStatuses     - List of work statuses to filter by.

	Returns:
	int64 - Count of latest submissions matching the filters.
	error - Error if project is missing or database query fails.

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) CountLatestSubmissions(
	ctx context.Context,
	project, root, assetNameKey string,
	preferredPhase string, // kept for API compatibility; ignored in filtering
	approvalStatuses []string,
	workStatuses []string,
) (int64, error) {
	if project == "" {
		return 0, fmt.Errorf("project is required")
	}
	if root == "" {
		root = "assets"
	}

	db := r.db.WithContext(ctx)

	// name prefix filter
	nameCond := ""
	var nameArg any
	if strings.TrimSpace(assetNameKey) != "" {
		nameCond = " AND LOWER(group_1) LIKE ?"
		nameArg = strings.ToLower(strings.TrimSpace(assetNameKey)) + "%"
	}

	// status filter (no phase restriction)
	statusWhere, statusArgs := buildPhaseAwareStatusWhere(preferredPhase, approvalStatuses, workStatuses)

	sql := `
WITH latest_phase AS (
  SELECT
    project,
    root,
    group_1,
    relation,
    phase,
    work_status,
    approval_status,
    submitted_at_utc,
    modified_at_utc,
    ROW_NUMBER() OVER (
      PARTITION BY project, root, group_1, relation, phase
      ORDER BY modified_at_utc DESC
    ) AS rn
  FROM t_review_info
  WHERE project = ? AND root = ? AND deleted = 0` + nameCond + `
)
SELECT COUNT(*) FROM (
  SELECT project, root, group_1, relation
  FROM latest_phase
  WHERE rn = 1` + statusWhere + `
  GROUP BY project, root, group_1, relation
) AS x;
`

	args := []any{project, root}
	if nameArg != nil {
		args = append(args, nameArg)
	}
	args = append(args, statusArgs...)

	var total int64
	if err := db.Raw(sql, args...).Scan(&total).Error; err != nil {
		return 0, fmt.Errorf("CountLatestSubmissions: %w", err)
	}

	return total, nil
}

/*
	──────────────────────────────────────────────────────────────────────────

	ListLatestSubmissionsDynamic retrieves a list of the latest review submissions
	for a specified project and asset root, with dynamic filtering and sorting options.
	Parameters:
	- ctx: Context for database operations.
	- project: Project identifier (required).
	- root: Asset root; defaults to "assets" if empty.
	- preferredPhase: Phase to prioritize in sorting; if empty or "none", no bias is applied.
	- orderKey: Column or logical key to sort by (e.g., "submitted_at_utc", "group1_only").
	- direction: Sort direction ("ASC" or "DESC").
	- limit: Maximum number of results to return; defaults to 60 if <= 0.
	- offset: Number of results to skip; defaults to 0 if < 0.
	- assetNameKey: Optional asset name prefix filter (case-insensitive).
	- approvalStatuses: List of approval statuses to filter by.
	- workStatuses: List of work statuses to filter by.
	Returns:
	- []LatestSubmissionRow: Slice of latest submission rows matching the filters.
	- error: Error if project is missing or database query fails.

───────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListLatestSubmissionsDynamic(
	ctx context.Context,
	project string,
	root string,
	preferredPhase string,
	orderKey string,
	direction string,
	limit, offset int,
	assetNameKey string,
	approvalStatuses []string,
	workStatuses []string,
) ([]LatestSubmissionRow, error) {
	if project == "" {
		return nil, fmt.Errorf("project is required")
	}
	if root == "" {
		root = "assets"
	}
	if limit <= 0 {
		limit = 60
	}
	if offset < 0 {
		offset = 0
	}

	// phaseGuard: 1 = no phase bias, 0 = prefer preferredPhase
	phaseGuard := 0
	if preferredPhase == "" || strings.EqualFold(preferredPhase, "none") {
		phaseGuard = 1
	}

	orderClauseWindow := buildOrderClause("", orderKey, direction)
	orderClauseInner := buildOrderClause("b", orderKey, direction)

	// name prefix filter
	nameCond := ""
	var nameArg any
	if strings.TrimSpace(assetNameKey) != "" {
		nameCond = " AND LOWER(group_1) LIKE ?"
		nameArg = strings.ToLower(strings.TrimSpace(assetNameKey)) + "%"
	}

	// status filter
	statusWhere, statusArgs := buildPhaseAwareStatusWhere(preferredPhase, approvalStatuses, workStatuses)

	// keys subquery: which assets (root+project+group_1+relation) are in scope
	keysSQL := `
WITH latest_phase AS (
  SELECT
    project,
    root,
    group_1,
    relation,
	component,
    phase,
    work_status,
    approval_status,
    submitted_at_utc,
    modified_at_utc,
    ROW_NUMBER() OVER (
      PARTITION BY project, root, group_1, relation, phase
      ORDER BY modified_at_utc DESC
    ) AS rn
  FROM t_review_info
  WHERE project = ? AND root = ? AND deleted = 0` + nameCond + `
)
SELECT project, root, group_1, relation, component
FROM latest_phase
WHERE rn = 1` + statusWhere + `
GROUP BY project, root, group_1, relation, component
`

	q := fmt.Sprintf(`
WITH ordered AS (
  SELECT
    *,
    ROW_NUMBER() OVER (ORDER BY %s) AS _order
  FROM (
    SELECT b.*
    FROM (
      SELECT
        project,
        root,
        group_1,
        relation,
		component,
        phase,
        MAX(modified_at_utc) AS modified_at_utc
      FROM t_review_info
      WHERE project = ? AND root = ? AND deleted = 0
      GROUP BY project, root, group_1, relation, phase, component
    ) AS a
    LEFT JOIN (
      SELECT
        root,
        project,
        group_1,
        phase,
        relation,
		component,
        work_status,
        approval_status,
        submitted_at_utc,
        modified_at_utc,
		take
      FROM t_review_info
      WHERE project = ? AND root = ? AND deleted = 0
    ) AS b
      ON a.project = b.project
     AND a.root    = b.root
     AND a.group_1 = b.group_1
     AND a.relation = b.relation
     AND a.phase    = b.phase
     AND a.modified_at_utc = b.modified_at_utc

    INNER JOIN ( %s ) AS fk
      ON b.project = fk.project
     AND b.root    = fk.root
     AND b.group_1 = fk.group_1
     AND b.relation = fk.relation
     AND b.component = fk.component
    ORDER BY %s
  ) AS k
),
offset_ordered AS (
  SELECT
    c.*,
    CASE
      WHEN ? = 1 THEN c._order
      WHEN c.phase = ? THEN c._order
      ELSE 100000 + c._order
    END AS __order
  FROM ordered c
),
ranked AS (
  SELECT
    b.*,
    ROW_NUMBER() OVER (
      PARTITION BY b.root, b.project, b.group_1, b.relation
      ORDER BY
        CASE
          WHEN ? = 1 THEN 0
          WHEN b.phase = ? THEN 0
          ELSE 1
        END,
        LOWER(b.group_1)   ASC,
        LOWER(b.relation)  ASC,
        b.modified_at_utc  DESC
    ) AS _rank
  FROM offset_ordered b
)
SELECT
  root,
  project,
  group_1,
  relation,
  component,
  phase,
  submitted_at_utc
FROM ranked
WHERE _rank = 1
ORDER BY __order ASC
LIMIT ? OFFSET ?;
`, orderClauseWindow, keysSQL, orderClauseInner)

	args := []any{
		// 'a' CTE
		project, root,
		// 'b' join
		project, root,
		// keys subquery
		project, root,
	}
	if nameArg != nil {
		args = append(args, nameArg)
	}
	args = append(args, statusArgs...)
	// phase bias + limit/offset
	args = append(args,
		phaseGuard, preferredPhase,
		phaseGuard, preferredPhase,
		limit, offset,
	)

	var rows []LatestSubmissionRow
	if err := r.db.WithContext(ctx).Raw(q, args...).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("ListLatestSubmissionsDynamic: %w", err)
	}

	return rows, nil
}

/*
──────────────────────────────────────────────────────────────────────────

	ListAssetsPivot retrieves a paginated list of AssetPivot rows for a specified project and asset root,
	optionally filtered by asset name prefix, preferred phase, approval statuses, and work statuses.
	Parameters:
	- ctx: Context for database operations.
	- project: Project identifier (required).
	- root: Asset root; defaults to "assets" if empty.
	- preferredPhase: Phase to prioritize in sorting; if empty or "none", no bias is applied.
	- orderKey: Column or logical key to sort by (e.g., "submitted_at_utc", "group1_only").
	- direction: Sort direction ("ASC" or "DESC").
	- limit: Maximum number of results to return; defaults to 60 if <= 0.
	- offset: Number of results to skip; defaults to 0 if < 0.
	- assetNameKey: Optional asset name prefix filter (case-insensitive).
	- approvalStatuses: List of approval statuses to filter by.
	- workStatuses: List of work statuses to filter by.
	Returns:
	- []AssetPivot: Slice of AssetPivot rows matching the filters.
	- int64: Total count of assets matching the filters (for pagination).
	- error: Error if project is missing or database query fails.

───────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListAssetsPivot(
	ctx context.Context,
	project, root, preferredPhase, orderKey, direction string,
	limit, offset int,
	assetNameKey string,
	approvalStatuses []string,
	workStatuses []string,
) ([]AssetPivot, int64, error) {
	if project == "" {
		return nil, 0, fmt.Errorf("project is required")
	}
	if root == "" {
		root = "assets"
	}

	// 1) Get total count for pagination (after filters)
	total, err := r.CountLatestSubmissions(
		ctx,
		project,
		root,
		assetNameKey,
		preferredPhase,
		approvalStatuses,
		workStatuses,
	)
	if err != nil {
		return nil, 0, err
	}

	// 2) Get page "keys" (one primary row per asset, correctly ordered)
	keys, err := r.ListLatestSubmissionsDynamic(
		ctx,
		project,
		root,
		preferredPhase,
		orderKey,
		direction,
		limit,
		offset,
		assetNameKey,
		approvalStatuses,
		workStatuses,
	)
	if err != nil {
		return nil, 0, err
	}
	if len(keys) == 0 {
		return []AssetPivot{}, total, nil
	}

	// 3) Build dynamic WHERE ( ... OR ... ) to restrict phase fetch
	//    strictly to this page's assets.
	var sb strings.Builder
	var params []any

	sb.WriteString(`
WITH latest_phase AS (
  SELECT
    ri.project,
    ri.root,
    ri.group_1,
    ri.relation,
	COALESCE(ri.component, '') AS component,
    ri.phase,
    ri.work_status,
    ri.approval_status,
    ri.submitted_at_utc,
    ri.modified_at_utc,
	RIGHT(ri.take, 4) AS take,
    JSON_UNQUOTE(JSON_EXTRACT(ri.` + "`groups`" + `, '$[0]')) AS leaf_group_name,
    gc.path AS group_category_path,
    SUBSTRING_INDEX(gc.path, '/', 1) AS top_group_node,
    ROW_NUMBER() OVER (
      PARTITION BY ri.project, ri.root, ri.group_1, ri.relation, ri.component, ri.phase
      ORDER BY ri.modified_at_utc DESC
    ) AS rn
  FROM t_review_info AS ri
  LEFT JOIN t_group_category_group AS gcg
         ON gcg.project = ri.project
        AND gcg.deleted = 0
        AND gcg.path = JSON_UNQUOTE(JSON_EXTRACT(ri.` + "`groups`" + `, '$[0]'))
  LEFT JOIN t_group_category AS gc
         ON gc.id = gcg.group_category_id
        AND gc.deleted = 0
        AND gc.root = 'assets'
  WHERE ri.project = ? AND ri.root = ? AND ri.deleted = 0
    AND (
`)

	params = append(params, project, root)

	for i, k := range keys {
		if i > 0 {
			sb.WriteString("      OR ")
		}
		sb.WriteString("(ri.group_1 = ? AND ri.relation = ? AND ri.component = ?)\n")
		params = append(params, k.Group1, k.Relation, k.Component)
	}

	sb.WriteString(`    )
)
SELECT
  project,
  root,
  group_1,
  relation,
  component,
  phase,
  work_status,
  approval_status,
  submitted_at_utc,
  take,
  leaf_group_name,
  group_category_path,
  top_group_node
FROM latest_phase
WHERE rn = 1;
`)

	var phases []phaseRow
	if err := r.db.WithContext(ctx).Raw(sb.String(), params...).Scan(&phases).Error; err != nil {
		return nil, 0, fmt.Errorf("ListAssetsPivot.phaseFetch: %w", err)
	}

	// 4) Stitch phases into pivot rows, preserving the page order from `keys`.
	type keyStruct struct {
		p, r, g, rel, comp string
	}

	// helper to safely dereference *string
	ptrToString := func(s *string) string {
		if s == nil {
			return ""
		}
		return *s
	}

	m := make(map[keyStruct]*AssetPivot, len(keys))
	orderedPtrs := make([]*AssetPivot, 0, len(keys))

	// create base pivot row per asset in the same order as `keys`
	for _, k := range keys {
		id := keyStruct{k.Project, k.Root, k.Group1, k.Relation, k.Component}
		ap := &AssetPivot{
			Root:      k.Root,
			Project:   k.Project,
			Group1:    k.Group1,
			Relation:  k.Relation,
			Component: k.Component,
		}
		m[id] = ap
		orderedPtrs = append(orderedPtrs, ap)
	}

	// fill per-phase fields + grouping info
	for _, pr := range phases {
		id := keyStruct{pr.Project, pr.Root, pr.Group1, pr.Relation, ptrToString(pr.Component)}
		ap, ok := m[id]
		if !ok {
			continue
		}

		//  -- Add your code here----
		if pr.Component != nil && *pr.Component != "" {
			ap.Component = strings.TrimPrefix(*pr.Component, "_")
		}

		// Grouping info (set once)
		if ap.LeafGroupName == "" {
			ap.LeafGroupName = pr.LeafGroupName
			ap.GroupCategoryPath = pr.GroupCategoryPath
			ap.TopGroupNode = pr.TopGroupNode
		}

		switch strings.ToLower(pr.Phase) {
		case "mdl":
			ap.MDLWorkStatus = pr.WorkStatus
			ap.MDLApprovalStatus = pr.ApprovalStatus
			ap.MDLSubmittedAtUTC = pr.SubmittedAtUTC
			ap.MDLTake = pr.Take // Added take for MDL

		case "rig":
			ap.RIGWorkStatus = pr.WorkStatus
			ap.RIGApprovalStatus = pr.ApprovalStatus
			ap.RIGSubmittedAtUTC = pr.SubmittedAtUTC
			ap.RIGTake = pr.Take // Added take for RIG

		case "bld":
			ap.BLDWorkStatus = pr.WorkStatus
			ap.BLDApprovalStatus = pr.ApprovalStatus
			ap.BLDSubmittedAtUTC = pr.SubmittedAtUTC
			ap.BLDTake = pr.Take // Added take for BLD

		case "dsn":
			ap.DSNWorkStatus = pr.WorkStatus
			ap.DSNApprovalStatus = pr.ApprovalStatus
			ap.DSNSubmittedAtUTC = pr.SubmittedAtUTC
			ap.DSNTake = pr.Take // Added take for DSN

		case "ldv":
			ap.LDVWorkStatus = pr.WorkStatus
			ap.LDVApprovalStatus = pr.ApprovalStatus
			ap.LDVSubmittedAtUTC = pr.SubmittedAtUTC
			ap.LDVTake = pr.Take // Added take for LDV
		}
	}

	// 5) Convert []*AssetPivot → []AssetPivot in the same order as keys.
	ordered := make([]AssetPivot, len(orderedPtrs))
	for i, ap := range orderedPtrs {
		ordered[i] = *ap
	}

	return ordered, total, nil
}

/* ──────────────────────────────────────────────────────────────────────────
	ShotPivot represents a pivoted view of review information for shots, structured to facilitate
	easy access to phase-specific data. Each ShotPivot contains identifying information (root, project, group1-3, relation, component)
	and a map of phases to their corresponding data (work status, approval status, submission time, and take).
───────────────────────────────────────────────────────────────────────────
*/

type ShotPivot struct {
	Root      string `json:"root"`
	Project   string `json:"project"`
	Group1    string `json:"group_1"`
	Group2    string `json:"group_2"`
	Group3    string `json:"group_3"`
	Relation  string `json:"relation"`
	Component string `json:"component"`

	Phases map[string]PhaseData `json:"phases"`
}

type PhaseData struct {
	WorkStatus     *string    `json:"work_status"`
	ApprovalStatus *string    `json:"approval_status"`
	SubmittedAtUTC *time.Time `json:"submitted_at_utc"`
	Take           *string    `json:"take"`
}

func getStr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

var ReviewShotPhases = []string{
	"lay", "anm", "cmp", "mat", "cloth", "snd", "rel", "gnz", "dsp",
	"cfxCloth", "crd", "drw", "rtcgnz", "rtcmat", "rtcMatNuke", "rtcDrw",
}

/*
	 ──────────────────────────────────────────────────────────────────────────
		ReviewShotStatuses defines the set of statuses considered for filtering review shots.
		Currently, it includes only the "check" status, but can be expanded as needed.

───────────────────────────────────────────────────────────────────────────
*/
var ReviewShotStatuses = []string{"check"}

/*
	 ──────────────────────────────────────────────────────────────────────────
		reviewShotPhaseRow represents a single row of review shot phase data, including identifying information
		(project, root, group1-3, relation, phase) and status information (work status, approval status, submission time, and take).

───────────────────────────────────────────────────────────────────────────
*/
type reviewShotPhaseRow struct {
	Project        string     `gorm:"column:project"`
	Root           string     `gorm:"column:root"`
	Group1         string     `gorm:"column:group_1"`
	Group2         *string    `gorm:"column:group_2"`
	Group3         *string    `gorm:"column:group_3"`
	Relation       string     `gorm:"column:relation"`
	Phase          string     `gorm:"column:phase"`
	WorkStatus     *string    `gorm:"column:work_status"`
	ApprovalStatus *string    `gorm:"column:approval_status"`
	SubmittedAtUTC *time.Time `gorm:"column:submitted_at_utc"`
	Take           *string    `gorm:"column:take"`
}

/*
	 ──────────────────────────────────────────────────────────────────────────
		buildReviewShotPhaseIn constructs a SQL WHERE clause segment that filters rows based on the provided
		phases. If no phases are provided, it defaults to the predefined ReviewShotPhases.
		It returns the SQL fragment (e.g., "phase IN (?, ?, ?)") and a slice of arguments corresponding to the phases.

───────────────────────────────────────────────────────────────────────────
*/
func buildReviewShotPhaseIn(phases []string) (string, []any) {
	if len(phases) == 0 {
		phases = ReviewShotPhases
	}
	ph := strings.TrimRight(strings.Repeat("?,", len(phases)), ",")
	args := make([]any, len(phases))
	for i, p := range phases {
		args[i] = p
	}
	return "phase IN (" + ph + ")", args
}

/*
	 ───────────────────────────────────────────────────────────────────────────
		buildReviewShotStatusWhere constructs a SQL WHERE clause segment that filters rows based on the provided
		statuses. If no statuses are provided, it defaults to the predefined ReviewShotStatuses.
		It returns the SQL fragment (e.g., "(work_status IN (?, ?) OR approval_status IN (?, ?))")
		and a slice of arguments corresponding to the statuses for both work_status and approval_status.

───────────────────────────────────────────────────────────────────────────
*/
func buildReviewShotStatusWhere(statuses []string) (string, []any) {
	if len(statuses) == 0 {
		statuses = ReviewShotStatuses
	}
	ph := strings.TrimRight(strings.Repeat("?,", len(statuses)), ",")
	args := make([]any, 0, len(statuses)*2)
	for _, s := range statuses { // work_status IN (...)
		args = append(args, s)
	}
	for _, s := range statuses { // approval_status IN (...)
		args = append(args, s)
	}
	clause := fmt.Sprintf("(work_status IN (%s) OR approval_status IN (%s))", ph, ph)
	return clause, args
}

/*
	──────────────────────────────────────────────────────────────────────────
	buildReviewShotSort constructs the SQL ORDER BY clause for review shots based on the provided orderKey and direction.
	It returns the sort selection (if any), sort arguments, and the group order string for stable sorting.

______________________________________________________________________________
*/
func buildReviewShotSort(orderKey, dir string) (sortSelect string, sortArgs []any, groupOrder string) {
	// stable, grouped tiebreaker appended to every ordering
	groupTie := "group_1 ASC, group_2 ASC, group_3 ASC, relation ASC, _min_phase_order ASC"

	defaultOrder := "group_1 IS NULL, group_1 " + dir + ", group_2 ASC, group_3 ASC, relation ASC, _min_phase_order ASC"

	switch orderKey {
	case "", "group1_only", "group_1":
		return "", nil, defaultOrder
	case "group2_only", "group_2":
		return "", nil, "(group_2 IS NULL OR group_2 = '') ASC, group_2 " + dir +
			", group_1 ASC, group_3 ASC, relation ASC, _min_phase_order ASC"
	case "group3_only", "group_3":
		return "", nil, "(group_3 IS NULL OR group_3 = '') ASC, group_3 " + dir +
			", group_1 ASC, group_2 ASC, relation ASC, _min_phase_order ASC"
	case "relation_only", "relation":
		return "", nil, "(relation IS NULL OR relation = '') ASC, relation " + dir +
			", group_1 ASC, group_2 ASC, group_3 ASC, _min_phase_order ASC"
	}

	// phase-specific: "<phase>_<field>"
	parts := strings.SplitN(orderKey, "_", 2)
	if len(parts) == 2 {
		phase := strings.ToLower(strings.TrimSpace(parts[0]))
		switch parts[1] {
		case "work":
			return "MAX(CASE WHEN LOWER(phase) = ? THEN work_status END) AS _sort_val",
				[]any{phase},
				"(_sort_val IS NULL OR _sort_val = '') ASC, LOWER(_sort_val) " + dir + ", " + groupTie
		case "appr":
			return "MAX(CASE WHEN LOWER(phase) = ? THEN approval_status END) AS _sort_val",
				[]any{phase},
				"(_sort_val IS NULL OR _sort_val = '') ASC, LOWER(_sort_val) " + dir + ", " + groupTie
		case "take":
			// take is already parsed to its numeric tail by SUBSTRING_INDEX upstream
			return "MAX(CASE WHEN LOWER(phase) = ? THEN CAST(NULLIF(take, '') AS UNSIGNED) END) AS _sort_val",
				[]any{phase},
				"(_sort_val IS NULL) ASC, _sort_val " + dir + ", " + groupTie
		case "submitted":
			return "MAX(CASE WHEN LOWER(phase) = ? THEN submitted_at_utc END) AS _sort_val",
				[]any{phase},
				"(_sort_val IS NULL) ASC, _sort_val " + dir + ", " + groupTie
		}
	}

	// unrecognized key -> default group ordering
	return "", nil, defaultOrder
}

/*
──────────────────────────────────────────────────────────────────────────

	CountReviewShots implements count_reviews.sql: the number of unique shot
	groups that have at least one phase (in the whitelist) whose work_status OR
	approval_status is in the requested set.

	The GROUP BY matches the pagination unit in ListReviewShots
	(project, root, group_1, group_2, group_3, relation), so this total lines up
	exactly with the number of pageable groups (the footer's "of N").

	Parameters:
	- ctx:      Context for database operations.
	- project:  Project identifier (required).
	- phases:   Phase whitelist; defaults to ReviewShotPhases when empty.
	- statuses: Status set applied to work_status OR approval_status; defaults to ReviewShotStatuses.

	Returns the total count, or an error if project is missing or the query fails.

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) CountReviewShots(
	ctx context.Context,
	project string,
	phases []string,
	statuses []string,
) (int64, error) {
	if project == "" {
		return 0, fmt.Errorf("project is required")
	}

	phaseClause, phaseArgs := buildReviewShotPhaseIn(phases)
	statusClause, statusArgs := buildReviewShotStatusWhere(statuses)

	query := `
WITH unique_groups AS (
    SELECT project, root, group_1, group_2, group_3, relation
    FROM t_review_info
    WHERE project = ? AND root = 'shots' AND deleted = 0
      AND ` + phaseClause + `
      AND ` + statusClause + `
    GROUP BY project, root, group_1, group_2, group_3, relation
)
SELECT COUNT(*) FROM unique_groups;
`

	args := []any{project}
	args = append(args, phaseArgs...)
	args = append(args, statusArgs...)

	var total int64
	if err := r.db.WithContext(ctx).Raw(query, args...).Scan(&total).Error; err != nil {
		return 0, fmt.Errorf("CountReviewShots: %w", err)
	}
	return total, nil
}

/*
──────────────────────────────────────────────────────────────────────────

	ListReviewShots implements query_reviews.sql. For shots matching the phase
	whitelist and status set, it keeps the latest review row per
	(group_1, group_2, group_3, relation, phase) (by modified_at_utc), pages the
	resulting shot groups, and returns every kept phase row for the paged groups.

	The result is ordered by group (group_1 dir, group_2, group_3, relation) and
	then by the original phase-order key, so the caller can pivot rows in a
	stable, page-consistent order.

	Parameters:
	- ctx:       Context for database operations.
	- project:   Project identifier (required).
	- phases:    Phase whitelist; defaults to ReviewShotPhases when empty.
	- statuses:  Status set applied to work_status OR approval_status; defaults to ReviewShotStatuses.
	- direction: Sort direction for group_1 ("ASC"/"DESC"); defaults to "ASC".
	- limit:     Max number of shot groups; defaults to 15 when <= 0.
	- offset:    Number of shot groups to skip; defaults to 0 when < 0.

	Returns the per-phase rows for the paged groups, or an error.

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListReviewShots(
	ctx context.Context,
	project string,
	phases []string,
	statuses []string,
	orderKey string,
	direction string,
	limit, offset int,
) ([]reviewShotPhaseRow, error) {
	if project == "" {
		return nil, fmt.Errorf("project is required")
	}
	if limit <= 0 {
		limit = 15
	}
	if offset < 0 {
		offset = 0
	}
	dir := strings.ToUpper(strings.TrimSpace(direction))
	if dir != "ASC" && dir != "DESC" {
		dir = "ASC"
	}

	phaseClause, phaseArgs := buildReviewShotPhaseIn(phases)
	statusClause, statusArgs := buildReviewShotStatusWhere(statuses)

	// Per-group sort: optional aggregate sort column + the group ORDER BY.
	sortSelect, sortArgs, groupOrder := buildReviewShotSort(orderKey, dir)
	sortCol := ""
	if sortSelect != "" {
		sortCol = ",\n           " + sortSelect
	}

	// The phase/status filters appear in both the MAX() subquery (a) and the
	// detail subquery (b), so their args are supplied twice (see args assembly).
	query := `
WITH latest_reviews AS (
    SELECT b.*
    FROM (
        SELECT project, root, group_1, group_2, group_3, relation, phase,
               MAX(modified_at_utc) AS modified_at_utc
        FROM t_review_info
        WHERE project = ? AND root = 'shots' AND deleted = 0
          AND ` + phaseClause + `
          AND ` + statusClause + `
        GROUP BY project, root, group_1, group_2, group_3, relation, phase
    ) a
    LEFT JOIN (
        SELECT project, root, group_1, group_2, group_3, relation, phase,
               work_status, approval_status, submitted_at_utc, modified_at_utc,
               SUBSTRING_INDEX(take, 't', -1) AS take
        FROM t_review_info
        WHERE project = ? AND root = 'shots' AND deleted = 0
          AND ` + phaseClause + `
          AND ` + statusClause + `
    ) b
      ON  a.project = b.project
      AND a.root    = b.root
      AND a.group_1 = b.group_1
      AND a.group_2 <=> b.group_2
      AND a.group_3 <=> b.group_3
      AND a.relation = b.relation
      AND a.phase    = b.phase
      AND a.modified_at_utc = b.modified_at_utc
),
latest_reviews_sort AS (
    SELECT *, ROW_NUMBER() OVER (ORDER BY group_1 ASC) AS _sort_order
    FROM latest_reviews
),
latest_reviews_phase_sort AS (
    SELECT *,
        CASE WHEN phase = '' THEN _sort_order ELSE 99999999 + _sort_order END AS _phase_order
    FROM latest_reviews_sort
),
grp_agg AS (
    SELECT project, root, group_1, group_2, group_3, relation,
           MIN(_phase_order) AS _min_phase_order` + sortCol + `
    FROM latest_reviews_phase_sort
    GROUP BY project, root, group_1, group_2, group_3, relation
),
unique_groups AS (
    SELECT *, ROW_NUMBER() OVER (ORDER BY ` + groupOrder + `) AS _group_rank
    FROM grp_agg
    ORDER BY ` + groupOrder + `
    LIMIT ? OFFSET ?
),
all_phase_reviews AS (
    SELECT r.*, ug._group_rank
    FROM latest_reviews_phase_sort r
    RIGHT JOIN unique_groups ug
      ON  r.group_1 = ug.group_1
      AND r.group_2 <=> ug.group_2
      AND r.group_3 <=> ug.group_3
      AND r.relation = ug.relation
)
SELECT project, root, group_1, group_2, group_3, relation, phase,
       work_status, approval_status, submitted_at_utc, take
FROM all_phase_reviews
ORDER BY _group_rank ASC, _phase_order ASC;
`

	args := []any{project}
	args = append(args, phaseArgs...)
	args = append(args, statusArgs...)
	args = append(args, project)
	args = append(args, phaseArgs...)
	args = append(args, statusArgs...)
	args = append(args, sortArgs...) // grp_agg sort column (0 or 1 arg)
	args = append(args, limit, offset)

	var rows []reviewShotPhaseRow
	if err := r.db.WithContext(ctx).Raw(query, args...).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("ListReviewShots: %w", err)
	}
	return rows, nil
}

/*
──────────────────────────────────────────────────────────────────────────

	ListReviewShotsPivot orchestrates CountReviewShots + ListReviewShots and
	pivots the per-phase rows into one ShotPivot per shot group, preserving the
	paged group order returned by ListReviewShots. Each phase is keyed by its
	lowercase name in ShotPivot.Phases. Component is left empty because the
	review-queue query does not group by component.

	Returns the page of ShotPivot rows, the total group count, or an error.

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListReviewShotsPivot(
	ctx context.Context,
	project string,
	phases []string,
	statuses []string,
	orderKey string,
	direction string,
	limit, offset int,
) ([]ShotPivot, []string, int64, error) {
	if project == "" {
		return nil, nil, 0, fmt.Errorf("project is required")
	}

	// Resolve the phase set dynamically from live data when the caller did not
	// pass an explicit subset, instead of relying on a hardcoded list. An empty
	// result simply yields an empty page.
	if len(phases) == 0 {
		dyn, err := r.ListReviewShotPhases(ctx, project, statuses)
		if err != nil {
			return nil, nil, 0, err
		}
		phases = dyn
	}

	total, err := r.CountReviewShots(ctx, project, phases, statuses)
	if err != nil {
		return nil, nil, 0, err
	}

	rows, err := r.ListReviewShots(ctx, project, phases, statuses, orderKey, direction, limit, offset)
	if err != nil {
		return nil, nil, 0, err
	}
	if len(rows) == 0 {
		return []ShotPivot{}, phases, total, nil
	}

	type key struct {
		project, root, g1, g2, g3, rel string
	}

	m := make(map[key]*ShotPivot, len(rows))
	order := make([]*ShotPivot, 0, len(rows))

	for _, row := range rows {
		g2 := getStr(row.Group2)
		g3 := getStr(row.Group3)
		id := key{row.Project, row.Root, row.Group1, g2, g3, row.Relation}

		sp, ok := m[id]
		if !ok {
			sp = &ShotPivot{
				Project:  row.Project,
				Root:     row.Root,
				Group1:   row.Group1,
				Group2:   g2,
				Group3:   g3,
				Relation: row.Relation,
				Phases:   map[string]PhaseData{},
			}
			m[id] = sp
			order = append(order, sp)
		}

		sp.Phases[strings.ToLower(row.Phase)] = PhaseData{
			WorkStatus:     row.WorkStatus,
			ApprovalStatus: row.ApprovalStatus,
			SubmittedAtUTC: row.SubmittedAtUTC,
			Take:           row.Take,
		}
	}

	final := make([]ShotPivot, len(order))
	for i, sp := range order {
		final[i] = *sp
	}
	return final, phases, total, nil
}

/*
──────────────────────────────────────────────────────────────────────────

	ListReviewShotPhases returns the distinct phases that currently have at
	least one shot whose work_status OR approval_status is in the requested set,
	for the given project. This is the dynamic replacement for the hardcoded
	ReviewShotPhases list — the phase set is derived from live data instead of
	being maintained in code. Phases are returned alphabetically; if you need a
	canonical pipeline ordering (e.g. lay → anm → cmp ...), source the list from
	project pipeline settings instead and pass it in explicitly.

	Parameters:
	- ctx:      Context for database operations.
	- project:  Project identifier (required).
	- statuses: Status set applied to work_status OR approval_status; defaults to ReviewShotStatuses.

	Returns the distinct phase names, or an error.

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListReviewShotPhases(
	ctx context.Context,
	project string,
	statuses []string,
) ([]string, error) {
	if project == "" {
		return nil, fmt.Errorf("project is required")
	}

	statusClause, statusArgs := buildReviewShotStatusWhere(statuses)

	query := `
SELECT DISTINCT phase
FROM t_review_info
WHERE project = ? AND root = 'shots' AND deleted = 0
  AND phase IS NOT NULL AND phase <> ''
  AND ` + statusClause + `
ORDER BY phase;
`

	args := []any{project}
	args = append(args, statusArgs...)

	var rows []struct {
		Phase string `gorm:"column:phase"`
	}
	if err := r.db.WithContext(ctx).Raw(query, args...).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("ListReviewShotPhases: %w", err)
	}

	phases := make([]string, 0, len(rows))
	for _, row := range rows {
		phases = append(phases, row.Phase)
	}
	return phases, nil
}

/*
──────────────────────────────────────────────────────────────────────────

	ReviewShotGroupCount represents the count of distinct review-queue shots
	under a specific (group_1, group_2) combination. It is used to provide
	aggregate information about the number of shots per group, which can be
	leveraged for pagination and filtering in the client application.

──────────────────────────────────────────────────────────────────────────
*/
type ReviewShotGroupCount struct {
	Group1    string `gorm:"column:group_1" json:"group_1"`
	Group2    string `gorm:"column:group_2" json:"group_2"`
	ShotCount int    `gorm:"column:shot_count" json:"shot_count"`
}

/*
──────────────────────────────────────────────────────────────────────────

	ListReviewShotGroupCounts returns, per (group_1, group_2), the number of
	distinct review-queue shots (group_1, group_2, group_3, relation) under it.
	From this the client can derive:
	  - per group_1: total shots and number of group_2s,
	  - per group_1/group_2: shot count,
	  - the group_1 filter-menu counts,
	without fetching any shot rows. This lets group view paginate per page
	instead of loading the entire data set.

	Parameters mirror the pivot: project (required), phases (defaults to the
	dynamic set when empty), statuses (defaults to ReviewShotStatuses).

──────────────────────────────────────────────────────────────────────────
*/
func (r *ReviewInfo) ListReviewShotGroupCounts(
	ctx context.Context,
	project string,
	phases []string,
	statuses []string,
) ([]ReviewShotGroupCount, error) {
	if project == "" {
		return nil, fmt.Errorf("project is required")
	}

	// Resolve the phase set dynamically when none supplied, matching the pivot.
	if len(phases) == 0 {
		dyn, err := r.ListReviewShotPhases(ctx, project, statuses)
		if err != nil {
			return nil, err
		}
		phases = dyn
	}

	phaseClause, phaseArgs := buildReviewShotPhaseIn(phases)
	statusClause, statusArgs := buildReviewShotStatusWhere(statuses)

	query := `
WITH groups AS (
    SELECT DISTINCT project, root, group_1, group_2, group_3, relation
    FROM t_review_info
    WHERE project = ? AND root = 'shots' AND deleted = 0
      AND ` + phaseClause + `
      AND ` + statusClause + `
)
SELECT group_1, COALESCE(group_2, '') AS group_2, COUNT(*) AS shot_count
FROM groups
GROUP BY group_1, group_2
ORDER BY group_1, group_2;
`

	args := []any{project}
	args = append(args, phaseArgs...)
	args = append(args, statusArgs...)

	var rows []ReviewShotGroupCount
	if err := r.db.WithContext(ctx).Raw(query, args...).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("ListReviewShotGroupCounts: %w", err)
	}
	return rows, nil
}
