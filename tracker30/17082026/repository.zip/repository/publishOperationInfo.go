package repository

import (
	"context"
	"log"

	"github.com/PolygonPictures/central30-web/front/entity"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type PublishOperationInfo struct {
	db *mongo.Database
}

func NewPublishOperationInfo(db *mongo.Database) *PublishOperationInfo {
	return &PublishOperationInfo{
		db: db,
	}
}

func (poi *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	param *entity.LatestAssetComponentParams,
) (documents []*entity.LatestComponentDocuments, err error) {
	col := poi.db.Collection("pc_publishOperationInfo")

	// Project, Asset, Relation, Componentでフィルタリング
	matchStage := bson.D{
		{"$match", bson.D{
			{"_central.project", param.Project},
			{"root", "assets"},
			{"groups.0", param.Asset},
			{"relation", param.Relation},
			{"component", bson.D{{"$in", param.Component}}},
		}},
	}

	// id, groups, submitted_at_utc, phase, component フィールドのみ取得
	projectStage := bson.D{
		{"$project", bson.D{
			{"id", 1},
			{"groups", 1},
			{"submitted_at_utc", 1},
			{"phase", 1},
			{"component", 1},
			{"_id", 0},
		}},
	}

	// submitted_at_utcで降順にソート
	sortStage := bson.D{
		{"$sort", bson.D{
			// -1 は降順を意味
			{"submitted_at_utc", -1},
		}},
	}

	// component ごとに最新のドキュメントを取得
	groupStage := bson.D{
		{"$group", bson.D{
			{"_id", "$component"},
			{"latest_document", bson.D{{"$first", "$$ROOT"}}},
		}},
	}

	pipeline := mongo.Pipeline{matchStage, projectStage, sortStage, groupStage}
	cursor, err := col.Aggregate(ctx, pipeline)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)

	if err = cursor.All(ctx, &documents); err != nil {
		return
	}
	if documents == nil {
		documents = []*entity.LatestComponentDocuments{}
	}
	return
}

func (poi *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) (documents []*entity.ShotDocument, total int64, err error) {
	documents = []*entity.ShotDocument{}
	col := poi.db.Collection("pc_publishOperationInfo")

	filter := bson.D{
		{"_central.project", params.Project},
		{"root", "shots"},
	}

	offset := (params.GetPage() - 1) * params.GetPerPage()
	if offset < 0 {
		offset = 0
	}

	groupsStringStage := bson.D{
		{"$addFields", bson.D{
			{"groupsString", bson.D{
				{"$reduce", bson.D{
					{"input", "$groups"},
					{"initialValue", ""},
					{"in", bson.D{
						{"$cond", bson.A{
							bson.D{{"$eq", bson.A{"$$value", ""}}},
							"$$this",
							bson.D{{"$concat", bson.A{"$$value", "/", "$$this"}}},
						}},
					}},
				}},
			}},
		}},
	}

	groupStage := bson.D{
		{"$group", bson.D{
			{"_id", bson.D{
				{"groups", "$groups"},
				{"relation", "$relation"},
			}},
			{"sortKey", bson.D{
				{"$first", "$groupsString"},
			}},
		}},
	}

	pipeline := mongo.Pipeline{
		{
			{"$match", filter},
		},
		groupsStringStage,
		groupStage,
		{
			// $facetを使用して総数とデータを同時に取得
			{"$facet", bson.D{
				{"total", bson.A{
					bson.D{{"$count", "totalCount"}},
				}},
				{"documents", bson.A{
					bson.D{
						{"$sort", bson.D{
							{"sortKey", 1},
						}},
					},
					bson.D{
						{"$skip", offset},
					},
					bson.D{
						{"$limit", params.PerPage},
					},
					bson.D{
						{"$project", bson.D{
							{"_id", 0},
							{"groups", "$_id.groups"},
							{"relation", "$_id.relation"},
						}},
					},
				}},
			}},
		},
	}

	// 大文字小文字を区別しない
	collation := options.Collation{
		Locale:   "en",
		Strength: 2,
	}
	aggregateOptions := options.Aggregate().SetCollation(&collation)

	cursor, err := col.Aggregate(ctx, pipeline, aggregateOptions)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)

	// $facet結果をデコードするための構造体
	var result struct {
		Total []struct {
			TotalCount int64 `bson:"totalCount"`
		} `bson:"total"`
		Documents []*entity.ShotDocument `bson:"documents"`
	}

	if cursor.Next(ctx) {
		if err = cursor.Decode(&result); err != nil {
			return
		}
	} else if err = cursor.Err(); err != nil {
		return
	}

	if len(result.Total) > 0 {
		total = result.Total[0].TotalCount
	} else {
		total = 0
	}

	documents = result.Documents

	return
}

func (poi *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	param *entity.LatestShotComponentParams,
) (documents []*entity.LatestComponentDocuments, err error) {
	col := poi.db.Collection("pc_publishOperationInfo")

	// Project, Asset, Relation, Componentでフィルタリング
	matchStage := bson.D{
		{"$match", bson.D{
			{"_central.project", param.Project},
			{"root", "shots"},
			{"groups.0", param.Group1},
			{"groups.1", param.Group2},
			{"groups.2", param.Group3},
			{"relation", param.Relation},
			{"component", bson.D{{"$in", param.Component}}},
		}},
	}

	// id, groups, submitted_at_utc, phase, component フィールドのみ取得
	projectStage := bson.D{
		{"$project", bson.D{
			{"id", 1},
			{"groups", 1},
			{"submitted_at_utc", 1},
			{"phase", 1},
			{"component", 1},
			{"_id", 0},
		}},
	}

	// submitted_at_utcで降順にソート
	sortStage := bson.D{
		{"$sort", bson.D{
			// -1 は降順を意味
			{"submitted_at_utc", -1},
		}},
	}

	// component ごとに最新のドキュメントを取得
	groupStage := bson.D{
		{"$group", bson.D{
			{"_id", "$component"},
			{"latest_document", bson.D{{"$first", "$$ROOT"}}},
		}},
	}

	pipeline := mongo.Pipeline{matchStage, projectStage, sortStage, groupStage}
	cursor, err := col.Aggregate(ctx, pipeline)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)

	if err = cursor.All(ctx, &documents); err != nil {
		return
	}
	if documents == nil {
		documents = []*entity.LatestComponentDocuments{}
	}
	return
}

// CamDataTypeShotKey identifies a single shot for cam_data_type lookup.
type CamDataTypeShotKey struct {
	Group1   string
	Group2   string
	Group3   string
	Relation string
}

// GetLatestCamDataTypes returns the latest cam_data_type per shot for the
// given batch. Result is keyed by "g1/g2/g3/relation".
//
// "Latest" = document with the most recent submitted_at_utc for the shot,
// across any phase/component. Documents where component_info.cam_data_type
// is missing or empty are excluded.
//
// Pass an empty slice and you get an empty map — no Mongo call is made.
func (poi *PublishOperationInfo) GetLatestCamDataTypes(
	ctx context.Context,
	project string,
	shots []CamDataTypeShotKey,
) (map[string]string, error) { // ← CHANGED: was map[string][]string
	result := make(map[string]string) // ← CHANGED: was make(map[string][]string)

	log.Printf("[CamDataType] Repository called — project=%s, shots count=%d", project, len(shots))

	if len(shots) == 0 {
		log.Printf("[CamDataType] No shots provided, returning empty map")
		return result, nil
	}

	for i, s := range shots {
		if i >= 3 {
			log.Printf("[CamDataType] ... and %d more shots", len(shots)-3)
			break
		}
		log.Printf("[CamDataType] Input shot[%d]: %s/%s/%s/%s", i, s.Group1, s.Group2, s.Group3, s.Relation)
	}

	col := poi.db.Collection("pc_publishOperationInfo")

	orBranches := make(bson.A, 0, len(shots))
	for _, s := range shots {
		orBranches = append(orBranches, bson.D{
			{"groups.0", s.Group1},
			{"groups.1", s.Group2},
			{"groups.2", s.Group3},
			{"relation", s.Relation},
		})
	}

	pipeline := mongo.Pipeline{
		{{"$match", bson.D{
			{"_central.project", project},
			{"root", "shots"},
			{"component_info.cam_data_type", bson.D{
				{"$exists", true}, // ← CHANGED
				{"$ne", ""},       // ← CHANGED (was $not: {$size: 0})
			}},
			{"$or", orBranches},
		}}},
		{{"$project", bson.D{
			{"_id", 0},
			{"groups", 1},
			{"relation", 1},
			{"submitted_at_utc", 1},
			{"cam_data_type", "$component_info.cam_data_type"},
		}}},
		{{"$sort", bson.D{
			{"submitted_at_utc", -1},
		}}},
		{{"$group", bson.D{
			{"_id", bson.D{
				{"groups", "$groups"},
				{"relation", "$relation"},
			}},
			{"cam_data_type", bson.D{{"$first", "$cam_data_type"}}},
		}}},
	}

	cursor, err := col.Aggregate(ctx, pipeline)
	if err != nil {
		log.Printf("[CamDataType] Aggregation error: %v", err)
		return result, err
	}
	defer cursor.Close(ctx)

	var rows []struct {
		ID struct {
			Groups   []string `bson:"groups"`
			Relation string   `bson:"relation"`
		} `bson:"_id"`
		CamDataType string `bson:"cam_data_type"` // ← CHANGED: was []string
	}
	if err = cursor.All(ctx, &rows); err != nil {
		log.Printf("[CamDataType]  Cursor decode error: %v", err)
		return result, err
	}

	for _, r := range rows {
		if len(r.ID.Groups) < 3 {
			log.Printf("[CamDataType]  Skipping row with <3 groups: %v", r.ID.Groups)
			continue
		}
		key := r.ID.Groups[0] + "/" + r.ID.Groups[1] + "/" + r.ID.Groups[2] + "/" + r.ID.Relation
		result[key] = r.CamDataType
	}

	return result, nil
}
