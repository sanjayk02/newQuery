package repository

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/entity"
	grpdir "github.com/PolygonPictures/central30-web/front/repository/groupDirectory"
	"github.com/PolygonPictures/central30-web/front/repository/model"
)

// GroupDirectory is a repository that manages group directory records.
type GroupDirectory struct {
	db *gorm.DB
}

// NewGroupDirectory creates a new GroupDirectory repository.
func NewGroupDirectory(db *gorm.DB) (*GroupDirectory, error) {
	if err := db.AutoMigrate(&model.GroupDirectory{}); err != nil {
		return nil, err
	}
	return &GroupDirectory{
		db: db,
	}, nil
}

func (r *GroupDirectory) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

// ListWithDirectoryParams retrieves group directories matching the
// conditions specified in params (excluding ModifiedSince and SQLite).
func (r *GroupDirectory) ListWithDirectoryParams(
	db *gorm.DB,
	params *entity.ListDirectoryParams,
) ([]*entity.GroupDirectory, int, error) {
	if params.ModifiedSince != nil {
		return nil, 0, entity.NewBadRequestErrorf("ModifiedSince parameter is not supported: params=%+v", params)
	}
	if params.SQLite {
		return nil, 0, entity.NewBadRequestErrorf("SQLite parameter is not supported: params=%+v", params)
	}

	stmt := db.Where("`project`", params.Project)

	var root string
	if params.PathPrefix != nil {
		rest, found := strings.CutPrefix(*params.PathPrefix, "shared/publish/")
		if found {
			root, _, _ = strings.Cut(rest+"/", "/")
		}
	}

	// Set the path and depth conditions.
	if root != "" && params.Depth != nil {
		// Fast path: use ix_directory_3 index
		stmt = stmt.Where(
			"`root` = ?", root,
		).Where(
			"`depth` = ?", *params.Depth,
		).Where(
			"`path` LIKE ?", *params.PathPrefix+"%",
		)
	} else {
		// Use uix_directory_1 index
		if params.PathPrefix != nil {
			stmt = stmt.Where("`path` LIKE ?", *params.PathPrefix+"%")
		} else if len(params.Paths) != 0 {
			stmt = stmt.Where("`path` IN ?", params.Paths)
		}

		if params.Depth != nil {
			stmt = stmt.Where("`depth` = ?", *params.Depth)
		}
	}

	if params.Status != nil {
		stmt = stmt.Where("`status` = ?", (*params.Status).String())
	}

	stmt = stmt.Where("`deleted` = ?", 0)

	var total int64
	if err := stmt.Model(&model.GroupDirectory{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	stmt = orderBy(stmt, params.OrderBy)
	stmt = limitOffset(stmt, params.BaseListParams)

	var models []*model.GroupDirectory
	if err := stmt.Find(&models).Error; err != nil {
		return nil, 0, err
	}

	var entities []*entity.GroupDirectory
	for _, m := range models {
		entities = append(entities, m.Entity())
	}
	return entities, int(total), nil
}

// Create creates group path records within the path parameter.
func (r *GroupDirectory) Create(tx *gorm.DB, project, path string) ([]*model.GroupDirectory, error) {
	groupPaths, err := grpdir.ParseToGroupPaths(tx, project, path)
	if err != nil {
		return nil, fmt.Errorf("failed to parse to group-path: %w", err)
	}

	if len(groupPaths) == 0 {
		return nil, nil
	}

	root := groupPaths[0].Root

	// 既存レコードを取得
	var paths []string
	for _, groupPath := range groupPaths {
		paths = append(paths, groupPath.Path)
	}

	stmt := tx.Where(
		"`project` = ?", project,
	).Where(
		"`path` IN ?", paths,
	).Where(
		"`deleted` = ?", 0,
	)

	var dirs []*model.GroupDirectory
	if err := stmt.Find(&dirs).Error; err != nil {
		return nil, err
	}

	dirMap := map[string]string{}
	for _, dir := range dirs {
		dirMap[strings.ToLower(dir.Path)] = dir.Path
	}

	// 既存レコードが存在しないパスのレコードを作成
	var created []*model.GroupDirectory
	const createdBy = ""
	for _, groupPath := range groupPaths {
		if recordedPath, ok := dirMap[strings.ToLower(groupPath.Path)]; ok {
			if recordedPath != groupPath.Path {
				return nil, fmt.Errorf(
					"group directory differing with %q only in letter case already exists for project %q",
					groupPath.Path, project,
				)
			}
			continue
		}

		m := model.NewGroupDirectory(
			project,
			root,
			int32(groupPath.Depth),
			groupPath.Path,
			int32(groupPath.GroupDepth),
			createdBy,
		)
		if err := tx.Create(m).Error; err != nil {
			if !r.isMySQLDuplicateEntryError(err) {
				return nil, err
			}
		} else {
			created = append(created, m)
		}
	}

	return created, nil
}

func (r *GroupDirectory) isMySQLDuplicateEntryError(err error) bool {
	if err == nil {
		return false
	}

	var mysqlErr *mysql.MySQLError
	return errors.As(err, &mysqlErr) && mysqlErr.Number == 1062

}

// ToDelete updates the status of the records in the group directory under
// the path parameter from "active" to "to_delete".
func (r *GroupDirectory) ToDelete(tx *gorm.DB, project, path string) (int, error) {
	return r.updateStatus(tx, project, path, entity.Active, entity.ToDelete)
}

// Deleted updates the status of the records in the group directory under
// the path parameter from "to_delete" to "deleted".
func (r *GroupDirectory) Deleted(tx *gorm.DB, project, path string) (int, error) {
	return r.updateStatus(tx, project, path, entity.ToDelete, entity.Deleted)
}

func (r *GroupDirectory) updateStatus(
	tx *gorm.DB,
	project, path string,
	before, after entity.DeletionState,
) (int, error) {
	pathTrimmed := strings.Trim(path, "/")

	rest, found := strings.CutPrefix(pathTrimmed, "shared/publish/")
	if !found {
		log.Printf("`path` not starts with 'shared/publish/': %s", path)
		return 0, nil
	}

	root, rest, found := strings.Cut(rest, "/")
	if !found || root == "" {
		log.Printf("`path` not contains root: %s", path)
		return 0, nil
	}

	numGroups, err := grpdir.GetNumGroups(tx, project, root)
	if err != nil {
		return 0, fmt.Errorf("failed to get number of groups: %w", err)
	}

	const rootDepth = 3
	maxGroupDepth := rootDepth + numGroups
	depth := strings.Count(pathTrimmed, "/") + 1
	if depth > maxGroupDepth {
		log.Printf("`path` is under group hierarchy: %s", path)
		return 0, nil
	}

	now := time.Now().UTC()
	updates := map[string]any{
		"status":          after.String(),
		"modified_at_utc": &now,
		"modified_by":     "",
	}
	if after == entity.Deleted {
		updates["deleted"] = gorm.Expr("id")
	}

	result := tx.Model(&model.GroupDirectory{}).Where(
		"`project` = ?", project,
	).Where(
		"`path` = ? OR `path` LIKE ?", pathTrimmed, pathTrimmed+"/%",
	).Where(
		"`deleted` = ?", 0,
	).Where(
		"`status` = ?", before.String(),
	).Updates(updates)

	return int(result.RowsAffected), result.Error
}
