package repository

import (
	"context"
	"database/sql"
	"errors"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository/model"
	"gorm.io/gorm"
)

// ShotProperty is a repository that manages shot property records.
type ShotProperty struct {
	db *gorm.DB
}

// NewShotProperty creates a new ShotProperty repository.
func NewShotProperty(db *gorm.DB) (*ShotProperty, error) {
	db.AutoMigrate(&model.ShotProperty{})
	return &ShotProperty{
		db: db,
	}, nil
}

func (r *ShotProperty) WithContext(ctx context.Context) *gorm.DB {
	return r.db.WithContext(ctx)
}

func (r *ShotProperty) TransactionWithContext(
	ctx context.Context,
	fc func(tx *gorm.DB) error,
	opts ...*sql.TxOptions,
) error {
	db := r.WithContext(ctx)
	return db.Transaction(fc, opts...)
}

func (r *ShotProperty) Get(
	db *gorm.DB,
	params *entity.GetShotPropertyParams,
) (*entity.ShotProperty, error) {
	var m model.ShotProperty
	if err := db.Where(
		"`deleted` = ?", 0,
	).Where(
		"`project` = ?", params.Project,
	).Where(
		"`path` = ?", params.Path,
	).Take(&m).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, err
	}
	return m.Entity(false), nil
}

func (r *ShotProperty) Create(
	tx *gorm.DB,
	params *entity.CreateShotPropertyParams,
) (*entity.ShotProperty, error) {
	m := model.NewShotProperty(params)
	if err := tx.Create(m).Error; err != nil {
		return nil, err
	}
	return m.Entity(false), nil
}
