package groupDirectory

import (
	"testing"

	"gorm.io/gorm"

	"github.com/PolygonPictures/central30-web/front/testutil"
)

const testDBName = "test_groupDirectory"
var testDB *gorm.DB

func TestMain(m *testing.M) {
	testDB = testutil.NewTestDB(testDBName)
	m.Run()
}
