package groupDirectory

import (
	"fmt"
	"testing"

	"github.com/PolygonPictures/central30-web/front/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestParseToGroupPaths(t *testing.T) {
	const project = "potoodev"

	tests := map[string]struct {
		root   string
		groups string
		path   string
		want   []*GroupPath
	}{
		"single group": {
			root:   "assets",
			groups: "asset",
			path:   "shared/publish/assets/testHero",
			want: []*GroupPath{
				{
					Path:       "shared/publish/assets/testHero",
					Root:       "assets",
					Depth:      4,
					GroupDepth: 1,
				},
			},
		},
		"multiple group": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01",
			want: []*GroupPath{
				{
					Path:       "shared/publish/shots/ep01",
					Root:       "shots",
					Depth:      4,
					GroupDepth: 1,
				},
				{
					Path:       "shared/publish/shots/ep01/sq01",
					Root:       "shots",
					Depth:      5,
					GroupDepth: 2,
				},
				{
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					Root:       "shots",
					Depth:      6,
					GroupDepth: 3,
				},
			},
		},
		"revision path": {
			root:   "shots",
			groups: "episode,sequence,shot",
			path:   "shared/publish/shots/ep01/sq01/sh01/com/cmp/_org/20250724071724144616.s001r0004",
			want: []*GroupPath{
				{
					Path:       "shared/publish/shots/ep01",
					Root:       "shots",
					Depth:      4,
					GroupDepth: 1,
				},
				{
					Path:       "shared/publish/shots/ep01/sq01",
					Root:       "shots",
					Depth:      5,
					GroupDepth: 2,
				},
				{
					Path:       "shared/publish/shots/ep01/sq01/sh01",
					Root:       "shots",
					Depth:      6,
					GroupDepth: 3,
				},
			},
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			prefKey := fmt.Sprintf("/ppip/roots/%s/groups", test.root)
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.AddProjectPreference(t, testDB, project, prefKey, &test.groups)

			groupPaths, err := ParseToGroupPaths(testDB, project, test.path)
			require.Nil(t, err)
			assert.Equal(t, test.want, groupPaths)
		})
	}
}

func TestParseToGroupPaths_GroupNotContains(t *testing.T) {
	const project = "potoodev"
	paths := []string{"", "shared", "shared/tools", "unshared/publish", "shared/publish/assets"}
	for _, path := range paths {
		t.Run(path, func(t *testing.T) {
			groupPaths, err := ParseToGroupPaths(testDB, project, path)
			assert.Nil(t, groupPaths)
			assert.Nil(t, err)
		})
	}
}

func TestParseToGroupPaths_NoGroupPreference(t *testing.T) {
	testutil.SetupTablesWithCleanup(t, testDB)

	const project = "potoodev"
	const path = "shared/publish/assets/testHero"
	groupPaths, err := ParseToGroupPaths(testDB, project, path)
	assert.Nil(t, groupPaths)
	assert.ErrorContains(t, err, "no preference key:")
}

func TestGetNumGroups(t *testing.T) {
	const project = "potoodev"

	tests := map[string]struct {
		root   string
		groups string
		want   int
	}{
		"single group": {
			root:   "assets",
			groups: "asset",
			want:   1,
		},
		"multiple groups": {
			root:   "shots",
			groups: "episode,sequence,shot",
			want:   3,
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			prefKey := fmt.Sprintf("/ppip/roots/%s/groups", test.root)
			testutil.SetupTablesWithCleanup(t, testDB)
			testutil.AddProjectPreference(t, testDB, project, prefKey, &test.groups)

			got, err := GetNumGroups(testDB, project, test.root)
			require.Nil(t, err)
			assert.Equal(t, test.want, got)
		})
	}
}

func TestGetNumGroups_NoPreferenceKey(t *testing.T) {
	const project = "potoodev"

	testutil.SetupTablesWithCleanup(t, testDB)

	_, err := GetNumGroups(testDB, project, "assets")
	require.NotNil(t, err)
	assert.ErrorContains(t, err, "no preference key:")
}

func TestGetNumGroups_NoPreferenceValue(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const key = "/ppip/roots/assets/groups"

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, key, nil)

	_, err := GetNumGroups(testDB, project, root)
	require.NotNil(t, err)
	assert.ErrorContains(t, err, "no preference value:")
}

func TestGetNumGroups_EmptyPreferenceValue(t *testing.T) {
	const project = "potoodev"
	const root = "assets"
	const key = "/ppip/roots/assets/groups"
	value := ""

	testutil.SetupTablesWithCleanup(t, testDB)
	testutil.AddProjectPreference(t, testDB, project, key, &value)

	_, err := GetNumGroups(testDB, project, root)
	require.NotNil(t, err)
	assert.ErrorContains(t, err, "empty preference value:")
}
