package model

import (
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
)

// GroupDirectory represents a group directory information record.
type GroupDirectory struct {
	Project       string     `gorm:"size:30;not null;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	Root          string     `gorm:"size:30;not null;index:ix_directory_3"`
	Depth         int32      `gorm:"not null;index:ix_directory_3"`
	Path          string     `gorm:"size:1000;not null;uniqueIndex:uix_directory_1,length:255;index:ix_directory_3,length:255"`
	GroupDepth    int32      `gorm:"not null"`
	Status        string     `gorm:"size:10;not null;index:ix_directory_3"`
	CreatedAtUTC  *time.Time `gorm:"type:datetime(6)"`
	ModifiedAtUTC *time.Time `gorm:"type:datetime(6);index:ix_directory_2"`
	Deleted       int32      `gorm:"not null;default:0;uniqueIndex:uix_directory_1;index:ix_directory_2;index:ix_directory_3"`
	ModifiedBy    *string    `gorm:"size:100"`
	CreatedBy     *string    `gorm:"size:100"`
	ID            int32      `gorm:"primaryKey"`
}

// NewGroupDirectory creates a new GroupDirectory model.
func NewGroupDirectory(
	project string,
	root string,
	depth int32,
	path string,
	groupDepth int32,
	createdBy string,
) *GroupDirectory {
	now := time.Now().UTC()
	return &GroupDirectory{
		Project:       project,
		Root:          root,
		Depth:         depth,
		Path:          path,
		GroupDepth:    groupDepth,
		Status:        entity.Active.String(),
		CreatedAtUTC:  &now,
		ModifiedAtUTC: &now,
		CreatedBy:     &createdBy,
		ModifiedBy:    &createdBy,
	}
}

func (m *GroupDirectory) Entity() *entity.GroupDirectory {
	status, _ := entity.ParseDeletionStats(m.Status)
	return &entity.GroupDirectory{
		Project:       m.Project,
		Path:          m.Path,
		Depth:         m.Depth,
		Status:        status,
		CreatedAtUTC:  m.CreatedAtUTC,
		ModifiedAtUTC: m.ModifiedAtUTC,
		CreatedBy:     m.CreatedBy,
		ModifiedBy:    m.ModifiedBy,
		ID:            m.ID,
	}
}
