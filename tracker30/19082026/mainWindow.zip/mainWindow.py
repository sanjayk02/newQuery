# --------------------------------------------------------------------------
# PPITRACKER-48: MainWindow used to fetch columns and entity data (and, via
# Service()/State(), thumbnails and role data) synchronously during
# construction, blocking the window from appearing for several seconds.
#
# What changed:
#   - MainWindow.__init__ no longer calls _rebuildColumns()/_refresh()
#     directly; QTimer.singleShot(0, self._startInitialLoad) defers all
#     data loading until after the window's first paint (see showEvent()).
#   - New background tasks: LoadColumnsTask, LoadEntitiesTask,
#     LoadRoleDataTask (mirrors the pre-existing LoadThumbnailTask pattern
#     in service.py) - each runs on a QThreadPool worker thread and reports
#     back via a Qt signal, safely queued onto the main thread.
#   - Load order on startup: Columns -> Assets rows -> Assets thumbnails ->
#     Shots rows -> Shots thumbnails, staged one after another via
#     DataWidget's dataLoaded signal. Role data loads independently, in
#     parallel with columns, since it doesn't share a widget.
#   - DataWidget.refreshData()/_onEntitiesLoaded() now fetch via
#     LoadEntitiesTask instead of calling ApiClient.searchEntities()
#     directly; TableWidget/TreeWidget's old refreshData() bodies became
#     _applyEntities(), fed already-fetched data.
#   - showEvent()/_logElapsed() log window-open time and each load stage's
#     elapsed time to the real application logger, for verification on
#     every future launch (see ppiTracker.log).
#
# Unrelated, pre-existing code in this file is unchanged.
# --------------------------------------------------------------------------
from collections import OrderedDict
import csv
import re
import time
from logging import getLogger
from typing import Any, Callable, Iterator

from ppilib.core.launcher import AppInfo
from ppilib.core.phase.structure2 import Group
from ppui.PySide.QtCore import (
    QAbstractItemModel,
    QEvent,
    QItemSelectionModel,
    QModelIndex,
    QRect,
    QObject,
    QPersistentModelIndex,
    QPoint,
    QSize,
    QSortFilterProxyModel,
    Qt,
    QTimer,
    Signal,
)
from ppui.PySide.QtGui import (
    QAction,
    QColor,
    QIcon,
    QImage,
    QPainter,
    QPalette,
    QPixmap,
    QShowEvent,
    QStandardItem,
    QStandardItemModel,
)
from ppui.PySide.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMenuBar,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QSpacerItem,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
    QTableView,
    QTreeView,
    QToolButton,
    QWidget,
    QWidgetAction,
    QVBoxLayout,
)

from .apiClient import ApiClient
from .centralClient import Sections
from .columnManagerDialog import ColumnListDialog
from .config import CsvEntityData
from .confirmImportDialog import ConfirmImportDialog
from .entityEditorDialog import CheckableComboBox, EntityEditorDialog
from .roleManagerDialog import RoleManagerDialog
from .service import LoadThumbnailPathsTask, LoadThumbnailTask, Service, ThreadPool, ThumbnailPaths
from .state import State
from .tableData import Column, Entity, DataRepository
from .ui.mainWindow import Ui_MainWindow
from .userRole import Permission, Role

_logger = getLogger(__name__)

READ_ONLY_COLUMN_KEYS = ('name', 'thumbnail', 'cut_number')
GENERATED_COLUMN_KEYS = ('cut_number',)
ALWAYS_VISIBLE_COLUMN_KEYS = ('thumbnail', 'name')
THUMBNAIL_DEFAULT_SIZE = 90
THUMBNAIL_MAX_SIZE = 220
ROW_DEFAULT_HEIGHT = 70
ROW_HEIGHT_PADDING = 12
THUMBNAIL_COLUMN_PADDING = 60
ASSIGNMENT_COLUMN_DISPLAY_NAMES = {
    'modeling_assigned_to': 'MDL Assign to',
    'rigging_assigned_to': 'RIG Assign to',
    'lookdev_assigned_to': 'LDV Assign to',
    'layout_assigned_to': 'LAY Assign to',
    'animation_assigned_to': 'ANM Assign to',
    'genzu_assigned_to': 'GNZ Assign to',
    'fx_assigned_to': 'FX Assign to',
    'display_assigned_to': 'DSP Assign to',
    'compositing_assigned_to': 'CMP Assign to',
}
ASSIGNMENT_COLUMN_ORDER = (
    'dsn_assign_to',
    'modeling_assigned_to',
    'rigging_assigned_to',
    'lookdev_assigned_to',
    'layout_assigned_to',
    'animation_assigned_to',
    'genzu_assigned_to',
    'mat_assign_to',
    'fx_assigned_to',
    'display_assigned_to',
    'compositing_assigned_to',
    'cloth_assign_to',
    'cfhair_assign_to',
    'rtcgnz_assign_to',
    'rtcmat_assign_to',
    'crd_assign_to',
    'drw_assign_to',
    'rtcdrw_assign_to',
)
ASSIGNMENT_COLUMN_ORDER_INDEX = {
    key: index for index, key in enumerate(ASSIGNMENT_COLUMN_ORDER)
}


class LoadColumnsTask(QObject):  # PPITRACKER-48 (new)
    """Fetches column definitions and role overrides off the main thread."""

    columnsLoaded: Signal = Signal(list, dict)  # type: ignore

    def __init__(self, api: ApiClient, state: State) -> None:
        super().__init__()
        self._api = api
        self._state = state

    def run(self) -> None:
        dbColumns = self._api.getColumns()
        roleOverridesByRoot = {
            root: self._state.columnRoleOverrides(root) for root in ('assets', 'shots')
        }
        self.columnsLoaded.emit(dbColumns, roleOverridesByRoot)


class LoadRoleDataTask(QObject):  # PPITRACKER-48 (new)
    """Fetches role preference data off the main thread."""

    roleDataLoaded: Signal = Signal(object)  # type: ignore

    def __init__(self, state: State) -> None:
        super().__init__()
        self._state = state

    def run(self) -> None:
        roleData = self._state.loadRolePreference()
        self.roleDataLoaded.emit(roleData)


class LoadEntitiesTask(QObject):  # PPITRACKER-48 (new)
    """Fetches entity search results for a single root off the main thread."""

    entitiesLoaded: Signal = Signal(str, list)  # type: ignore

    def __init__(
        self,
        api: ApiClient,
        root: str,
        sortKey: str,
        sortDirection: int,
    ) -> None:
        super().__init__()
        self._api = api
        self._root = root
        self._sortKey = sortKey
        self._sortDirection = sortDirection

    def run(self) -> None:
        rawEntities = self._api.searchEntities(
            '',
            self._root,
            self._sortKey,
            self._sortDirection,
        )
        self.entitiesLoaded.emit(self._root, rawEntities)


class InlineCellEditDelegate(QStyledItemDelegate):
    def __init__(self, owner: 'DataWidget', parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._owner = owner

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> None:
        column = self._owner.columnForIndex(index)
        if column is None or column.key() != 'thumbnail':
            super().paint(painter, option, index)
            return

        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        iconData = index.data(Qt.ItemDataRole.DecorationRole)
        icon = opt.icon
        pixmap = QPixmap()
        if isinstance(iconData, QIcon):
            icon = iconData
        elif isinstance(iconData, QPixmap):
            pixmap = iconData
        elif isinstance(iconData, QImage):
            pixmap = QPixmap.fromImage(iconData)
        opt.icon = QIcon()
        featureContainer = getattr(QStyleOptionViewItem, 'ViewItemFeature', QStyleOptionViewItem)
        opt.features &= ~featureContainer.HasDecoration
        opt.text = ''
        widget = opt.widget
        style = widget.style() if widget is not None else QApplication.style()
        controlElement = getattr(QStyle, 'CE_ItemViewItem', None)
        if controlElement is None:
            controlElement = QStyle.ControlElement.CE_ItemViewItem
        style.drawControl(controlElement, opt, painter, widget)

        iconSize = self._owner.thumbnailIconSize()
        if pixmap.isNull() and not icon.isNull():
            pixmap = icon.pixmap(iconSize, QIcon.Mode.Normal, QIcon.State.Off)
        if pixmap.isNull():
            return
        if pixmap.width() > iconSize.width() or pixmap.height() > iconSize.height():
            pixmap = pixmap.scaled(
                iconSize,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        pixmapSize = pixmap.size()
        iconRect = QRect(
            option.rect.x() + (option.rect.width() - pixmapSize.width()) // 2,
            option.rect.y() + (option.rect.height() - pixmapSize.height()) // 2,
            pixmapSize.width(),
            pixmapSize.height(),
        )
        painter.drawPixmap(iconRect, pixmap)

    def createEditor(
        self,
        parent: QWidget,
        _: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> QWidget | None:
        column = self._owner.columnForIndex(index)
        if column is None or not self._owner.canDirectEditCell(index, showWarning=False):
            return None

        dtype = column.dataType()
        if dtype == 'array':
            options = column.config().get('options', [])
            if not options:
                return QLineEdit(parent)
            if column.config().get('multi_select', False):
                editor = CheckableComboBox(parent)
            else:
                editor = QComboBox(parent)
                editor.addItem('')
            editor.addItems(options)
            return editor
        if dtype in ('int', 'float'):
            return QLineEdit(parent)
        if dtype == 'bool':
            return QCheckBox(parent)
        if dtype == 'string':
            return QLineEdit(parent)
        return None

    def setEditorData(self, editor: QWidget, index: QModelIndex) -> None:
        column = self._owner.columnForIndex(index)
        if column is None:
            return

        value = self._owner.valueForIndex(index, column)
        if isinstance(editor, CheckableComboBox):
            values = [val.strip() for val in str(value or '').split(',') if val.strip()]
            for row in range(editor.model().rowCount()):
                item = editor.model().item(row)
                if item.text() in values:
                    item.setCheckState(Qt.CheckState.Checked)
            editor.updateDisplayText()
        elif isinstance(editor, QComboBox):
            editor.setCurrentText(str(value or ''))
        elif isinstance(editor, QCheckBox):
            editor.setChecked(
                str(value).lower() in ('true', '1')
                if isinstance(value, str)
                else bool(value)
            )
        elif isinstance(editor, QLineEdit):
            editor.setText(str(value or ''))

    def setModelData(
        self,
        editor: QWidget,
        _: QAbstractItemModel,
        index: QModelIndex,
    ) -> None:
        column = self._owner.columnForIndex(index)
        if column is None:
            return

        if isinstance(editor, CheckableComboBox):
            value = ', '.join(editor.getCheckedItems())
        elif isinstance(editor, QComboBox):
            value = editor.currentText()
        elif isinstance(editor, QCheckBox):
            value = editor.isChecked()
        elif isinstance(editor, QLineEdit):
            text = editor.text()
            if column.dataType() == 'int':
                try:
                    value = int(text)
                except ValueError:
                    QMessageBox.warning(editor, 'Invalid Value', 'Please enter a valid integer.')
                    return
            elif column.dataType() == 'float':
                try:
                    value = float(text)
                except ValueError:
                    QMessageBox.warning(editor, 'Invalid Value', 'Please enter a valid number.')
                    return
            else:
                value = text
        else:
            return

        self._owner.saveDirectCellEdit(index, column, value)


class KeywordFilterProxyModel(QSortFilterProxyModel):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._pattern = ''
        self._keywords: list[tuple[str | None, str]] = []
        self._columnFilterNames: list[set[str]] = []

    def setKeywordFilterPattern(self, text: str):
        self._pattern = text.lower()
        self._keywords = [
            parsed
            for k in self._iterKeywordTokens(self._pattern)
            if k
            for parsed in (self._parseKeywordToken(k),)
            if parsed[1]
        ]
        self.invalidateFilter()

    def setColumnFilterNames(self, columns: list[Column]) -> None:
        self._columnFilterNames = [
            {
                self._normalizeColumnName(column.key()),
                self._normalizeColumnName(column.displayName()),
            }
            for column in columns
        ]
        self.invalidateFilter()

    @staticmethod
    def _normalizeColumnName(name: str) -> str:
        return name.strip().lower()

    @staticmethod
    def _iterKeywordTokens(text: str) -> Iterator[str]:
        token = ''
        bracketDepth = 0
        for char in text:
            if char == '[':
                bracketDepth += 1
            elif char == ']' and bracketDepth > 0:
                bracketDepth -= 1

            if char.isspace() and bracketDepth == 0:
                if token:
                    yield token
                    token = ''
                continue

            token += char

        if token:
            yield token

    def _parseKeywordToken(self, token: str) -> tuple[str | None, str]:
        if token.startswith('['):
            colEnd = token.find(']:')
            if colEnd > 1:
                columnName = self._normalizeColumnName(token[1:colEnd])
                keyword = token[colEnd + 2:]
                return columnName, keyword
        return None, token

    def _matchesColumnName(self, source_col: int, columnName: str) -> bool:
        if 0 <= source_col < len(self._columnFilterNames):
            return columnName in self._columnFilterNames[source_col]

        model = self.sourceModel()
        headerData = model.headerData(
            source_col,
            Qt.Orientation.Horizontal,
            Qt.ItemDataRole.DisplayRole,
        )
        return columnName == self._normalizeColumnName(str(headerData or ''))

    def filterAcceptsRow(
        self,
        source_row: int,
        source_parent: QModelIndex | QPersistentModelIndex,
    ) -> bool:
        if not self._keywords:
            return True

        model = self.sourceModel()
        cols = model.columnCount(source_parent)

        for columnName, kw in self._keywords:
            kwFound = False
            for col in range(cols):
                if columnName is not None and not self._matchesColumnName(col, columnName):
                    continue
                index = model.index(source_row, col, source_parent)
                data = model.data(index, Qt.ItemDataRole.UserRole + 3)
                if data is not None and kw in str(data).lower():
                    kwFound = True
                    break
            if not kwFound:
                return False
        return True

    @staticmethod
    def _naturalSortKey(value: Any) -> tuple[tuple[int, Any], ...]:
        if value is None:
            return ((1, ''),)
        parts = re.split(r'(\d+)', str(value).lower())
        return tuple(
            (0, int(part)) if part.isdigit() else (1, part)
            for part in parts
        )

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:
        leftData = left.data(DataWidget.SORT_ROLE)
        rightData = right.data(DataWidget.SORT_ROLE)

        if isinstance(leftData, (int, float, bool)) and isinstance(
            rightData,
            (int, float, bool),
        ):
            return leftData < rightData

        return self._naturalSortKey(leftData) < self._naturalSortKey(rightData)


class ColumnVisibilityComboBox(QToolButton):
    columnVisibilityChanged: Signal = Signal(str, bool)  # type: ignore

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._isUpdatingColumns = False
        self._columns: list[Column] = []
        self._hiddenColumnKeys: set[str] = set()
        self._checkboxes: dict[str, QCheckBox] = {}
        self._menu = QMenu(self)
        self.setMenu(self._menu)
        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.setMinimumWidth(150)
        self.setText('Columns (0/0)')

    def setColumns(self, columns: list[Column], hiddenColumnKeys: set[str]) -> None:
        self._isUpdatingColumns = True
        try:
            self._columns = [
                column
                for column in columns
                if column.key() not in ALWAYS_VISIBLE_COLUMN_KEYS
            ]
            self._hiddenColumnKeys = set(hiddenColumnKeys)
            self._rebuildMenu()
        finally:
            self._isUpdatingColumns = False
        self._updateButtonText()

    def _rebuildMenu(self) -> None:
        self._menu.clear()
        self._checkboxes.clear()

        panel = QWidget(self._menu)
        panelLayout = QVBoxLayout(panel)
        panelLayout.setContentsMargins(10, 8, 10, 8)
        panelLayout.setSpacing(6)

        scrollArea = QScrollArea(panel)
        scrollArea.setWidgetResizable(True)
        scrollArea.setFrameShape(QFrame.Shape.NoFrame)
        scrollArea.setMinimumWidth(220)
        scrollArea.setMaximumHeight(360)

        scrollContent = QWidget(scrollArea)
        scrollLayout = QVBoxLayout(scrollContent)
        scrollLayout.setContentsMargins(0, 0, 0, 0)
        scrollLayout.setSpacing(4)

        if self._columns:
            for column in self._columns:
                checkbox = QCheckBox(column.displayName(), scrollContent)
                checkbox.setChecked(column.key() not in self._hiddenColumnKeys)
                checkbox.toggled.connect(
                    lambda checked, key=column.key(): self._onColumnToggled(key, checked)
                )
                scrollLayout.addWidget(checkbox)
                self._checkboxes[column.key()] = checkbox
        else:
            emptyLabel = QLabel('No optional columns', scrollContent)
            emptyLabel.setEnabled(False)
            scrollLayout.addWidget(emptyLabel)

        scrollLayout.addStretch(1)
        scrollArea.setWidget(scrollContent)
        panelLayout.addWidget(scrollArea)

        buttonsLayout = QHBoxLayout()
        hideAllButton = QPushButton('Hide All', panel)
        showAllButton = QPushButton('Show All', panel)
        hideAllButton.setEnabled(bool(self._columns))
        showAllButton.setEnabled(bool(self._columns))
        hideAllButton.clicked.connect(lambda: self._setAllVisible(False))
        showAllButton.clicked.connect(lambda: self._setAllVisible(True))
        buttonsLayout.addWidget(hideAllButton)
        buttonsLayout.addWidget(showAllButton)
        panelLayout.addLayout(buttonsLayout)

        action = QWidgetAction(self._menu)
        action.setDefaultWidget(panel)
        self._menu.addAction(action)

    def _onColumnToggled(self, key: str, visible: bool) -> None:
        if self._isUpdatingColumns:
            return
        if visible:
            self._hiddenColumnKeys.discard(key)
        else:
            self._hiddenColumnKeys.add(key)
        self._updateButtonText()
        self.columnVisibilityChanged.emit(key, visible)

    def _setAllVisible(self, visible: bool) -> None:
        for checkbox in self._checkboxes.values():
            checkbox.setChecked(visible)
        self._updateButtonText()

    def _updateButtonText(self) -> None:
        columnCount = len(self._columns)
        checkedCount = len(
            [column for column in self._columns if column.key() not in self._hiddenColumnKeys]
        )
        self.setText(f'Columns ({checkedCount}/{columnCount})')


class CornerWidget(QWidget):
    def __init__(self, text: str, menuBar: QMenuBar) -> None:
        super(CornerWidget, self).__init__(parent=menuBar)
        self._layout = QVBoxLayout()
        self._layout.setContentsMargins(9, 3, 9, 3)
        self._label = QLabel(text, parent=self)
        self._layout.addWidget(self._label)
        self.setLayout(self._layout)

    def setText(self, text: str) -> None:
        self._label.setText(text)


class StatusProgressWidget(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._startedAt = time.perf_counter()
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(8)
        self._progressBar = QProgressBar(self)
        self._progressBar.setRange(0, 100)
        self._progressBar.setFixedWidth(220)
        self._progressBar.setTextVisible(True)
        self._label = QLabel('', self)
        self._label.setMinimumWidth(420)
        self._layout.addWidget(self._progressBar)
        self._layout.addWidget(self._label)
        self._hideTimer = QTimer(self)
        self._hideTimer.setSingleShot(True)
        self._hideTimer.timeout.connect(self.hide)
        self.hide()

    def begin(self, message: str) -> None:
        self._hideTimer.stop()
        self._startedAt = time.perf_counter()
        self.setProgress(0, message)
        self.show()

    def setProgress(self, percent: int, message: str) -> None:
        percent = max(0, min(100, percent))
        self._progressBar.setValue(percent)
        remaining = self._remainingText(percent)
        suffix = f' - {remaining} remaining' if remaining else ''
        self._label.setText(f'{message}{suffix}')

    def finish(self, message: str) -> None:
        self.setProgress(100, message)
        self._hideTimer.start(5000)

    def _remainingText(self, percent: int) -> str:
        if percent <= 0 or percent >= 100:
            return ''
        elapsed = time.perf_counter() - self._startedAt
        remaining = elapsed * (100 - percent) / percent
        if remaining < 1:
            return '<1s'
        if remaining < 60:
            return f'{remaining:.0f}s'
        minutes = int(remaining // 60)
        seconds = int(remaining % 60)
        return f'{minutes}m {seconds:02d}s'


class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(
        self,
        appInfo: AppInfo,
        state: State,
        isDev: bool,
        parent: QWidget | None = None,
    ) -> None:
        # PPITRACKER-48 (new): captured before super().__init__ so showEvent()
        # can report true end-to-end window-open time.
        self._initStartTime = time.perf_counter()
        self._openTimeReported = False
        super().__init__(parent)
        self._appInfo = appInfo
        self._state = state
        self._pipelineSetting = state.pipelineSetting()
        self._service = Service(self._pipelineSetting)
        self._isDev = isDev
        _project = self._pipelineSetting.project()
        assert _project is not None, 'No project selected in pipeline setting.'
        self._project = _project
        _studio = self._pipelineSetting.studio()
        assert _studio is not None, 'No studio selected in pipeline setting.'
        self._studio = _studio

        self._api = ApiClient(self._pipelineSetting, isDev=self._isDev)
        self._dataRepo = DataRepository(self._isDev)
        self._roleManager = state.roleManager()
        self._threadPool = ThreadPool()

        self._columns: list[Column] = []
        self._assetsEntities: dict[str, Entity | None] = {}
        self._assetsHeaderMap: list[str] = []
        self._shotsEntities: dict[str, Entity | None] = {}
        self._shotsHeaderMap: list[str] = []
        self._thumbnailPathsTasks: dict[str, LoadThumbnailPathsTask] = {}
        self._thumbnailTasks: dict[str, LoadThumbnailTask] = {}
        self._columnsTask: LoadColumnsTask | None = None
        self._roleDataTask: LoadRoleDataTask | None = None
        self._thumbnailCache: dict[str, dict[str, QIcon]] = {
            'assets': {},
            'shots': {},
        }

        self.setupUi(self)
        self._statusProgressWidget = StatusProgressWidget(self.statusbar)
        self.statusbar.addPermanentWidget(self._statusProgressWidget, 1)
        self._progressMode: str | None = None
        self._progressRootRanges: dict[str, tuple[int, int]] = {}
        self._refreshPendingRoots: set[str] = set()

        self._rootsButtonGroup = QButtonGroup(self)
        self._assetsButton = CheckableButton(' Assets', QIcon(':/child_w.png'), self)
        self._shotsButton = CheckableButton(' Shots', QIcon(':/film_w.png'), self)
        self._rootsButtonGroup.addButton(self._assetsButton)
        self._rootsButtonGroup.addButton(self._shotsButton)
        self._spacer = QSpacerItem(1, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.rootButtonHLayout.insertWidget(0, self._assetsButton)
        self.rootButtonHLayout.insertWidget(1, self._shotsButton)
        self.rootButtonHLayout.addItem(self._spacer)

        self._exportCsvButton = QPushButton(' Export CSV')
        self._exportCsvButton.setIcon(QIcon(':/export.png'))
        self._exportCsvButton.setMinimumWidth(120)
        self._importCsvButton = QPushButton(' Import CSV')
        self._importCsvButton.setIcon(QIcon(':/import.png'))
        self._importCsvButton.setMinimumWidth(120)
        self.rootButtonHLayout.addWidget(self._importCsvButton)
        self.rootButtonHLayout.addWidget(self._exportCsvButton)

        self._assetsTableWidget = TableWidget(
            self._service,
            self._api,
            self._state,
            self._columns,
            self._thumbnailCache['assets'],
            'assets',
            self,
        )
        self._shotsTreeWidget = TreeWidget(
            self._service,
            self._api,
            self._state,
            self._columns,
            self._thumbnailCache['shots'],
            'shots',
            self,
        )
        self.verticalLayout.addWidget(self._assetsTableWidget)
        self.verticalLayout.addWidget(self._shotsTreeWidget)

        self._currentSortKey = 'name'
        self._currentSortDirection = 1
        self._currentRoot = 'assets'
        self._dataWidgets: dict[str, 'DataWidget'] = {
            'assets': self._assetsTableWidget,
            'shots': self._shotsTreeWidget,
        }
        for widget in self._dataWidgets.values():
            widget.dataProgressChanged.connect(self._onDataProgressChanged)

        self._aboutDialog = None
        self._cornerWidget = None

        self.refreshButton.clicked.connect(self._onRefreshClicked)
        self._rootsButtonGroup.buttonToggled.connect(self.changeRootButtonToggled)
        self.columnManagerButton.clicked.connect(self._manageColumns)
        self.roleManagerButton.clicked.connect(self._manageRoles)

        self._exportCsvButton.clicked.connect(self._onExportCsvClicked)
        self._importCsvButton.clicked.connect(self._onImportCsvClicked)

        self._genaratedMenu()

        self._assetsTableWidget.setVisible(self._currentRoot == 'assets')
        self._shotsTreeWidget.setVisible(self._currentRoot == 'shots')
        self._setRootButton(self._currentRoot)
        self.roleManagerButton.setVisible(self._state.isAdmin())

        # PPITRACKER-48: this replaced the old synchronous
        # `self._rebuildColumns(); self._refresh(True)` call that used to sit
        # here and blocked window construction. Data (columns, entities,
        # thumbnails) is now fetched asynchronously so the window can be
        # shown immediately; QTimer.singleShot(0, ...) defers this until
        # after the event loop starts, i.e. after the first paint.
        QTimer.singleShot(0, self._startInitialLoad)

    def _logElapsed(self, label: str) -> None:  # PPITRACKER-48 (new)
        elapsed = time.perf_counter() - self._initStartTime
        _logger.info('%s at %.2fs', label, elapsed)

    def _beginProgress(
        self,
        message: str,
        mode: str,
        rootRanges: dict[str, tuple[int, int]] | None = None,
    ) -> None:
        self._progressMode = mode
        self._progressRootRanges = rootRanges or {}
        self._statusProgressWidget.begin(message)

    def _setProgress(self, percent: int, message: str) -> None:
        self._statusProgressWidget.setProgress(percent, message)

    def _finishProgress(self, message: str) -> None:
        self._statusProgressWidget.finish(message)
        self._progressMode = None
        self._progressRootRanges = {}

    def _onDataProgressChanged(
        self,
        root: str,
        current: int,
        total: int,
        message: str,
    ) -> None:
        rootRange = self._progressRootRanges.get(root)
        if rootRange is None:
            return

        start, end = rootRange
        if total > 0:
            percent = start + round((end - start) * current / total)
        else:
            percent = start
        self._setProgress(percent, message)

    def showEvent(self, event: QShowEvent) -> None:  # PPITRACKER-48 (new)
        super().showEvent(event)
        if not self._openTimeReported:
            self._openTimeReported = True
            elapsed = time.perf_counter() - self._initStartTime
            _logger.info('MainWindow opened in %.2fs', elapsed)
            statusBar = self.statusBar()
            if statusBar is not None:
                statusBar.showMessage(f'UI opened in {elapsed:.2f}s', 5000)

    def _startInitialLoad(self) -> None:
        self._logElapsed('Initial async load started')
        self._beginProgress(
            'Starting update...',
            'initial',
            {
                'assets': (20, 45),
                'shots': (60, 90),
            },
        )
        self._loadColumnsAsync()
        self._loadRoleDataAsync()

    def _loadRoleDataAsync(self) -> None:
        task = LoadRoleDataTask(self._state)
        task.roleDataLoaded.connect(self._onRoleDataLoaded)
        self._roleDataTask = task
        self._threadPool.start(task)

    def _onRoleDataLoaded(self, roleData: 'OrderedDict[Role, list[str]]') -> None:
        self._roleDataTask = None
        self._state.applyRoleData(roleData)
        self._roleManager = self._state.roleManager()
        self._refreshRoleDependentUi()
        self._logElapsed('Role data loaded')

    def _refreshRoleDependentUi(self) -> None:
        if self._cornerWidget is not None:
            text = (
                f'{self._studio.displayName()}'
                f' / {self._roleManager.userName()}'
                f' / {self._roleManager.currentRoleName()}'
            )
            self._cornerWidget.setText(text)
        self.roleManagerButton.setVisible(self._state.isAdmin())

    def _loadColumnsAsync(self) -> None:
        self._setProgress(5, 'Loading column settings...')
        task = LoadColumnsTask(self._api, self._state)
        task.columnsLoaded.connect(self._onColumnsLoaded)
        self._columnsTask = task
        self._threadPool.start(task)

    def _onColumnsLoaded(
        self,
        dbColumns: list[Any],
        roleOverridesByRoot: dict[str, dict[str, str]],
    ) -> None:
        self._columnsTask = None
        self._rebuildColumns(dbColumns, roleOverridesByRoot)
        self._logElapsed('Columns loaded')
        self._setProgress(20, 'Column settings loaded.')
        self._beginStagedInitialLoad()

    def _beginStagedInitialLoad(self) -> None:
        # Headers are cheap/local, so set them for both roots immediately -
        # switching tabs looks correct even before any row data has arrived.
        self._assetsTableWidget.refreshColumns(list(self._collectColumns('assets')))
        self._shotsTreeWidget.refreshColumns(list(self._collectColumns('shots')))

        # Always Assets first, then Shots - each root's entities/thumbnails
        # run on their own background thread, but Shots doesn't start until
        # Assets has finished, regardless of which tab is currently visible.
        self._loadRootStaged('assets', nextRoot='shots')

    def _loadRootStaged(self, root: str, nextRoot: str | None) -> None:
        widget = self._dataWidgets[root]

        def _onStageDone() -> None:
            widget.dataLoaded.disconnect(_onStageDone)
            self._logElapsed(f'{root.capitalize()} rows loaded')
            # Rows for this root are in; now load its thumbnails.
            self._resetTasks(root)
            thumbStart, thumbEnd = (45, 60) if root == 'assets' else (90, 100)
            self._setProgress(thumbStart, f'Loading {root} thumbnails...')
            thumbnailCount = self._loadThumbnail(root)
            thumbMessage = (
                f'Dispatched {thumbnailCount} {root} thumbnail update(s).'
                if thumbnailCount
                else f'No {root} thumbnails to update.'
            )
            self._setProgress(thumbEnd, thumbMessage)
            self._logElapsed(f'{root.capitalize()} thumbnails dispatched')
            if nextRoot is not None:
                self._loadRootStaged(nextRoot, nextRoot=None)
            else:
                self._finishProgress('Update complete.')

        widget.dataLoaded.connect(_onStageDone)
        rangeStart, _ = self._progressRootRanges.get(root, (0, 100))
        self._setProgress(rangeStart, f'Loading {root} data...')
        widget.refreshData()

    def _genaratedMenu(self):
        # Help Menu
        self._actionAboutPpiBreakdown = QAction('About PPI Breakdown...', self)
        self.menuHelp.addAction(self._actionAboutPpiBreakdown)
        self._actionAboutPpiBreakdown.triggered.connect(self._showAboutDialog)
        self._ppiBreakdownHelp = QAction('PPI Breakdown Help', self)
        self.menuHelp.addAction(self._ppiBreakdownHelp)
        self._ppiBreakdownHelp.triggered.connect(self._showHelpDocument)

        # Corner Widget
        text = (
            f'{self._studio.displayName()}'
            f' / {self._roleManager.userName()}'
            f' / {self._roleManager.currentRoleName()}'
        )
        self._cornerWidget = CornerWidget(text, self.menuBar())
        self.menuBar().setCornerWidget(self._cornerWidget)

    def _showAboutDialog(self):
        if self._aboutDialog is None:
            from ppui.desktop.widget.aboutDialog import AboutDialog

            self._aboutDialog = AboutDialog(self._appInfo, self)
        self._aboutDialog.show()

    def _showHelpDocument(self):
        import webbrowser

        url = self._pipelineSetting.preference().get('/ppiToolsDocument/url')
        if url:
            webbrowser.open(url + '/toolList/ppiBreakdown/')

    def _onRefreshClicked(self) -> None:
        for cache in self._thumbnailCache.values():
            cache.clear()
        root = self._currentRoot
        self._beginProgress(
            f'Refreshing {root}...',
            'refresh',
            {root: (10, 85)},
        )
        self._refresh()

    def _onExportCsvClicked(self) -> None:
        widget = self._dataWidgets.get(self._currentRoot)
        if widget:
            widget.exportCsv()

    def _onImportCsvClicked(self) -> None:
        widget = self._dataWidgets.get(self._currentRoot)
        if widget:
            widget.importCsv()

    def _refresh(self, force: bool = False) -> None:
        roots: list[str] = []
        if force or self._currentRoot == 'assets':
            roots.append('assets')
        if force or self._currentRoot == 'shots':
            roots.append('shots')

        if self._progressMode is None:
            rootRanges = {root: (10, 85) for root in roots}
            self._beginProgress('Refreshing data...', 'refresh', rootRanges)

        root = None if force else self._currentRoot
        self._resetTasks(root)
        self._refreshPendingRoots = set(roots)

        for root in roots:
            widget = self._dataWidgets[root]

            def _onRowsLoaded(root: str = root, widget: 'DataWidget' = widget) -> None:
                try:
                    widget.dataLoaded.disconnect(_onRowsLoaded)
                except (RuntimeError, TypeError):
                    pass
                self._refreshPendingRoots.discard(root)
                self._setProgress(90, f'Loading {root} thumbnails...')
                thumbnailCount = self._loadThumbnail(root)
                if thumbnailCount:
                    self._setProgress(
                        95,
                        f'Dispatched {thumbnailCount} {root} thumbnail update(s).',
                    )
                if not self._refreshPendingRoots:
                    self._finishProgress('Refresh complete.')

            widget.dataLoaded.connect(_onRowsLoaded)
            _columns = list(self._collectColumns(root))
            widget.refresh(_columns)

    def _setRootButton(self, root: str) -> None:
        isBlocked = self._rootsButtonGroup.blockSignals(True)
        try:
            if root == 'assets':
                self._assetsButton.setChecked(True)
            elif root == 'shots':
                self._shotsButton.setChecked(True)
        finally:
            self._rootsButtonGroup.blockSignals(isBlocked)

    def _rebuildColumns(
        self,
        dbColumns: list[Any] | None = None,
        roleOverridesByRoot: dict[str, dict[str, str]] | None = None,
    ) -> None:
        # PPITRACKER-48: dbColumns/roleOverridesByRoot are new optional params.
        # They may be prefetched on a background thread (see LoadColumnsTask).
        # When omitted, falls back to the original synchronous fetch, for call
        # sites that run after user interaction (e.g. column manager dialog).
        project = self._project.keyName()
        tempColumns = list(self._dataRepo.loadTemplateColumns(project))
        if dbColumns is None:
            dbColumns = self._api.getColumns()
        tempExistKeys = {col.key() for col in tempColumns}
        for dbCol in dbColumns:
            column = Column.fromDict(dbCol)
            if dbCol['key'] not in tempExistKeys:
                tempColumns.append(column)
            else:
                for i, tempCol in enumerate(tempColumns):
                    if tempCol.key() == dbCol['key']:
                        tempColumns[i] = column
                        break
        if roleOverridesByRoot is None:
            roleOverridesByRoot = {
                root: self._state.columnRoleOverrides(root) for root in ('assets', 'shots')
            }
        for root in ('assets', 'shots'):
            roleOverrides = roleOverridesByRoot.get(root)
            if not roleOverrides:
                continue
            tempColumns = [
                col.withRole(roleOverrides[col.key()])
                if col.key() in roleOverrides and col.root() in ('common', root)
                else col
                for col in tempColumns
            ]
        tempColumns = [self._normalizeAssignmentColumn(col) for col in tempColumns]
        self._columns = sorted(tempColumns, key=lambda c: c.createdAtUtc() or '0')

    def _normalizeAssignmentColumn(self, column: Column) -> Column:
        displayName = ASSIGNMENT_COLUMN_DISPLAY_NAMES.get(column.key())
        if displayName is None or column.displayName() == displayName:
            return column
        data = column.asDict()
        data['display_name'] = displayName
        return Column.fromDict(data)

    def _collectColumns(self, root: str) -> Iterator[Column]:
        columns = [
            col
            for col in self._columns
            if col.visibled() and col.root() in ('common', root)
        ]
        columns = sorted(
            columns,
            key=lambda col: (
                1 if col.key() in ASSIGNMENT_COLUMN_ORDER_INDEX else 0,
                ASSIGNMENT_COLUMN_ORDER_INDEX.get(col.key(), 0),
            ),
        )
        for col in columns:
            if not col.visibled() or col.root() not in ('common', root):
                continue
            yield col

    def _manageColumns(self):
        currentWidget = self._dataWidgets.get(self._currentRoot)
        cols = [
            col
            for col in self._columns
            if col.root() in ('common', self._currentRoot)
            and col.key() not in READ_ONLY_COLUMN_KEYS
        ]
        dlg = ColumnListDialog(
            self._api,
            self._project.keyName(),
            self._studio.keyName(),
            self._currentRoot,
            cols,
            currentWidget.getColumnOrder() if currentWidget else [],
            self._dataRepo,
            self._state,
            self,
        )
        dlg.exec()
        if dlg.isChanged():
            self._rebuildColumns()
            self._refresh()

    def _manageRoles(self):
        dlg = RoleManagerDialog(self._state, self)
        dlg.exec()

    def _resetTasks(self, root: str | None = None) -> None:
        for path, task in self._thumbnailPathsTasks.items():
            if root is not None and not path.startswith(root + '/'):
                continue
            task.thumbnailPathsLoaded.disconnect(self._loadThumbnailTask)
        self._thumbnailPathsTasks.clear()
        for path, task in self._thumbnailTasks.items():
            if root is not None and not path.startswith(root + '/'):
                continue
            task.thumbnailLoaded.disconnect(self._updateThumbnailLabel)
        self._thumbnailTasks.clear()

    def _updateThumbnailLabel(self, path: str, image: QImage) -> None:
        pathParts = path.split('/')
        if len(pathParts) < 2:
            return
        root = pathParts[0]
        scaledImage = image.scaled(
            THUMBNAIL_MAX_SIZE,
            THUMBNAIL_MAX_SIZE,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        icon = QIcon(QPixmap.fromImage(scaledImage))

        if root in self._thumbnailCache:
            self._thumbnailCache[root][path] = icon

        if path in self._thumbnailTasks:
            self._thumbnailTasks.pop(path)

        widget = self._dataWidgets.get(root)
        if widget is None:
            return

        groupPath = '/'.join(pathParts[1:])
        widget.onThumbnailUpdated(groupPath, icon)

    def _loadThumbnailTask(self, path: str, thumbPaths: ThumbnailPaths) -> None:
        if path not in self._thumbnailPathsTasks:
            return
        self._thumbnailPathsTasks.pop(path)

        pathParts = path.split('/')
        root = pathParts[0]
        if root in self._thumbnailCache and path in self._thumbnailCache[root]:
            widget = self._dataWidgets.get(root)
            if widget is not None:
                groupPath = '/'.join(pathParts[1:])
                widget.onThumbnailUpdated(groupPath, self._thumbnailCache[root][path])
            return

        task = LoadThumbnailTask(
            path,
            thumbPaths,
        )
        task.thumbnailLoaded.connect(self._updateThumbnailLabel)
        self._thumbnailTasks[path] = task
        self._service.threadStart(task)

    def _loadThumbnail(self, root: str | None = None) -> int:
        loadCount = 0
        for value in self._service.iterLatestThumbnailValues():
            if root is not None and not value.location().startswith(root + '/'):
                continue
            groupPath = self._service.valueLocationToGroupPath(value)
            if groupPath is None:
                continue
            _logger.debug('Loading thumbnail for %s', groupPath)
            pathRoot = groupPath.split('/')[0]
            if pathRoot in self._thumbnailCache and groupPath in self._thumbnailCache[pathRoot]:
                widget = self._dataWidgets.get(pathRoot)
                if widget is not None:
                    widgetGroupPath = '/'.join(groupPath.split('/')[1:])
                    widget.onThumbnailUpdated(
                        widgetGroupPath, self._thumbnailCache[pathRoot][groupPath]
                    )  # noqa: E501
                continue

            task = LoadThumbnailPathsTask(
                self._service,
                value,
            )
            task.thumbnailPathsLoaded.connect(self._loadThumbnailTask)
            self._thumbnailPathsTasks[groupPath] = task
            self._service.threadStart(task)
            loadCount += 1
        return loadCount

    def changeRootButtonToggled(self, button: QPushButton, checked: bool) -> None:
        if checked:
            root = 'assets' if button == self._assetsButton else 'shots'
            _logger.debug('Root changed to %s', root)
            if root != self._currentRoot:
                self._currentRoot = root
                self._assetsTableWidget.setVisible(root == 'assets')
                self._shotsTreeWidget.setVisible(root == 'shots')


class CheckableButton(QPushButton):
    def __init__(self, text: str, icon: QIcon | None = None, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setMinimumWidth(120)

        if icon is not None:
            self.setIcon(icon)


class DataWidget(QWidget):
    GROUPPATH_ROLE = Qt.ItemDataRole.UserRole + 1
    SORT_ROLE = Qt.ItemDataRole.UserRole + 2
    FILTER_ROLE = Qt.ItemDataRole.UserRole + 3

    dataLoaded: Signal = Signal()  # type: ignore  # PPITRACKER-48 (new)
    dataProgressChanged: Signal = Signal(str, int, int, str)  # type: ignore

    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._service = service
        self._api = api
        self._state = state
        self._columns = columns
        self._thumbnailCache = thumbnailCache
        self._root = root

        self._vLayout = QVBoxLayout(self)
        self._vLayout.setContentsMargins(0, 0, 0, 0)

        self._model = QStandardItemModel(self)
        self._proxyModel = KeywordFilterProxyModel(self)
        self._proxyModel.setSourceModel(self._model)
        self._proxyModel.setRecursiveFilteringEnabled(True)
        self._proxyModel.setSortRole(self.SORT_ROLE)
        self._proxyModel.setFilterRole(self.FILTER_ROLE)

        self._currentSortKey = 'name'
        self._currentSortDirection = 1
        self._headerMap: list[str] = []
        self._hiddenColumnKeys: set[str] = set()
        self._entities: dict[str, Entity | None] = {}
        self._thumbnailSize = THUMBNAIL_DEFAULT_SIZE

        self._thumbnailItems: dict[str, QStandardItem] = {}
        self._entitiesTask: LoadEntitiesTask | None = None
        self._pendingSelection: list[str] = []
        self._applyGeneration = 0  # PPITRACKER-48 (new): guards batched row population
        self._generatedValueCache: dict[tuple[str, str], str] = {}

        defaultImg = self._service.defaultThumbnail()
        self._defaultThumbnailIcon = self._buildDefaultThumbnailIcon(defaultImg)
        self._service.defaultThumbnailChanged.connect(self._onDefaultThumbnailChanged)

    def _buildDefaultThumbnailIcon(self, image: QImage) -> QIcon:
        scaledDefault = image.scaled(
            THUMBNAIL_MAX_SIZE,
            THUMBNAIL_MAX_SIZE,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        return QIcon(QPixmap.fromImage(scaledDefault))

    def _onDefaultThumbnailChanged(self, image: QImage) -> None:
        # Any rows already rendered before this fires will have used the cheap
        # placeholder; only rows drawn from this point on pick up the styled
        # version, since a full model repaint isn't worth it for a placeholder
        # that's rarely still visible once real thumbnails start arriving.
        self._defaultThumbnailIcon = self._buildDefaultThumbnailIcon(image)

    def _getView(self) -> QAbstractItemView:
        raise NotImplementedError

    def _getHorizontalHeader(self) -> QHeaderView:
        raise NotImplementedError

    def _getVisibleColumns(self) -> list[Column]:
        raise NotImplementedError

    def _updateFrozenColumns(self) -> None:
        raise NotImplementedError

    def _applyThumbnailSize(self) -> None:
        raise NotImplementedError

    def _buildProgressMessage(self, groupKeyNames: list[str], endIdx: int) -> str:
        fallback = f'Building {self._root} rows ({endIdx}/{len(groupKeyNames)})...'
        if self._root not in ('assets', 'shots') or not groupKeyNames or endIdx <= 0:
            return fallback

        currentGroup = groupKeyNames[min(endIdx - 1, len(groupKeyNames) - 1)]
        groupParts = [part for part in currentGroup.split('/') if part]
        if len(groupParts) < 2:
            return fallback

        return (
            f'Downloading takes: '
            f'shared/publish/{self._root}/{groupParts[0]}/{groupParts[1]}/*'
        )

    def _rowHeight(self) -> int:
        if self._thumbnailSize <= THUMBNAIL_DEFAULT_SIZE:
            return ROW_DEFAULT_HEIGHT
        return self._thumbnailSize + ROW_HEIGHT_PADDING

    def _rowSizeHint(self) -> QSize:
        return QSize(0, self._rowHeight())

    def thumbnailIconSize(self) -> QSize:
        return QSize(self._thumbnailSize, self._thumbnailSize)

    def _thumbnailColumnWidth(self) -> int:
        return max(150, self._thumbnailSize + THUMBNAIL_COLUMN_PADDING)

    def _thumbnailColumnIndex(self) -> int | None:
        try:
            return self._headerMap.index('thumbnail')
        except ValueError:
            return None

    def setThumbnailSize(self, size: int) -> None:
        self._thumbnailSize = size
        self._applyThumbnailSize()

    def _updateThumbnailSizeLabel(self) -> None:
        label = getattr(self, '_thumbnailSizeValueLabel', None)
        if label is not None:
            label.setText(f'{self._thumbnailSize}px')

    def _getTypedValue(self, val: Any, dtype: str) -> Any:
        if val == '' or val is None:
            if dtype == 'int':
                return -999999999
            elif dtype == 'float':
                return -999999999.0
            return ''

        try:
            if dtype == 'int':
                return int(val)
            elif dtype == 'float':
                return float(val)
            elif dtype == 'bool':
                return str(val).lower() in ('true', '1')
        except (ValueError, TypeError):
            if dtype == 'int':
                return -999999999
            elif dtype == 'float':
                return -999999999.0

        return str(val).lower()

    def enableCustomSorting(self):
        header = self._getHorizontalHeader()
        header.setSectionsClickable(True)
        header.setSortIndicatorShown(True)
        header.sectionClicked.connect(self.onHeaderSectionClicked)

    def enableColumnReordering(self):
        header = self._getHorizontalHeader()
        header.setSectionsMovable(True)

        header.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        header.customContextMenuRequested.connect(self.showHeaderContextMenu)

    def showHeaderContextMenu(self, pos: QPoint) -> None:
        menu = QMenu(self)
        saveUserAction = menu.addAction('Save Column Order for User')
        saveProjectAction = menu.addAction('Save Column Order for Project')
        _canSaveProjectOrder = self._state.hasPermission(Permission.CanSaveProjectColumnOrder)
        saveProjectAction.setVisible(_canSaveProjectOrder)
        resetAction = menu.addAction('Reset User Column Order')

        action = menu.exec(self._getHorizontalHeader().mapToGlobal(pos))
        if action == saveUserAction:
            self._onSaveUserColumnOrder()
        elif action == saveProjectAction:
            self._onSaveProjectColumnOrder()
        elif action == resetAction:
            self._onResetColumnOrder()

    def _visibleColumnCount(self) -> int:
        return len([key for key in self._headerMap if key not in self._hiddenColumnKeys])

    def _setColumnVisible(self, key: str, visible: bool) -> None:
        if key in ALWAYS_VISIBLE_COLUMN_KEYS:
            return
        if visible:
            self._hiddenColumnKeys.discard(key)
        elif self._visibleColumnCount() > 1:
            self._hiddenColumnKeys.add(key)
        self._applyColumnVisibility()

    def _showAllColumns(self) -> None:
        self._hiddenColumnKeys.clear()
        self._applyColumnVisibility()

    def _applyColumnVisibility(self) -> None:
        hiddenKeys = self._hiddenColumnKeys.intersection(self._headerMap)
        hiddenKeys = hiddenKeys.difference(ALWAYS_VISIBLE_COLUMN_KEYS)
        self._hiddenColumnKeys = hiddenKeys
        view = self._getView()
        for idx, key in enumerate(self._headerMap):
            view.setColumnHidden(idx, key in hiddenKeys)
        self._updateFrozenColumns()

    def _refreshColumnVisibilityCombo(self) -> None:
        combo = getattr(self, '_columnVisibilityCombo', None)
        if combo is not None:
            combo.setColumns(self._getVisibleColumns(), self._hiddenColumnKeys)

    def getColumnOrder(self) -> list[str]:
        header = self._getHorizontalHeader()
        orderKeys: list[str] = []
        for visualIdx in range(header.count()):
            logicalIdx = header.logicalIndex(visualIdx)
            if 0 <= logicalIdx < len(self._headerMap):
                orderKeys.append(self._headerMap[logicalIdx])
        return orderKeys

    def _onResetColumnOrder(self) -> None:
        reply = QMessageBox.question(
            self,
            'Confirm Reset',
            'Are you sure you want to reset the data?\nThis action cannot be undone.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.saveColumnOrder([], str(Sections.USER), self._root)
            self.refresh()

    def _onSaveUserColumnOrder(self) -> None:
        self.saveColumnOrder(self.getColumnOrder(), str(Sections.USER), self._root)

    def _onSaveProjectColumnOrder(self) -> None:
        self.saveColumnOrder(self.getColumnOrder(), str(Sections.PROJECT), self._root)

    def saveColumnOrder(
        self,
        columnKeys: list[str],
        section: str,
        root: str,
    ) -> None:
        self._state.setColumnOrder(columnKeys, section, root)

    def applyColumnOrder(self, columnKeys: list[str]) -> None:
        if not columnKeys:
            return

        header = self._getHorizontalHeader()
        keyToLogical = {key: i for i, key in enumerate(self._headerMap)}

        header.blockSignals(True)
        try:
            currentVisualIdx = 0
            for key in columnKeys:
                if key not in keyToLogical or not self._shouldApplyColumnOrderKey(key):
                    continue
                logicalIdx = keyToLogical[key]
                oldVisualIdx = header.visualIndex(logicalIdx)
                if oldVisualIdx != currentVisualIdx:
                    header.moveSection(oldVisualIdx, currentVisualIdx)
                currentVisualIdx += 1
        finally:
            header.blockSignals(False)

    def _shouldApplyColumnOrderKey(self, key: str) -> bool:
        return True

    def getSavedColumnOrder(self, root: str) -> list[str]:
        return self._state.columnOrder(root)

    def onHeaderSectionClicked(self, logicalIndex: int):
        if logicalIndex < 0 or logicalIndex >= len(self._headerMap):
            return

        desc = Qt.SortOrder.DescendingOrder
        asc = Qt.SortOrder.AscendingOrder
        colKey = self._headerMap[logicalIndex]

        if colKey == 'thumbnail':
            if self._currentSortKey in self._headerMap:
                prevIdx = self._headerMap.index(self._currentSortKey)
                prevOrder = asc if self._currentSortDirection == 1 else desc
                self._getHorizontalHeader().setSortIndicator(prevIdx, prevOrder)
                _logger.debug(
                    'Set sort indicator: index=%d, order=%s',
                    prevIdx,
                    'asc' if prevOrder == asc else 'desc',
                )
            return

        header = self._getHorizontalHeader()

        if self._currentSortKey == colKey:
            new_order = desc if self._currentSortDirection == 1 else asc
        else:
            new_order = asc

        self._currentSortKey = colKey
        self._currentSortDirection = 1 if new_order == asc else -1

        header.setSortIndicator(logicalIndex, new_order)
        self._proxyModel.sort(logicalIndex, new_order)
        _logger.debug(
            'Header clicked: index=%d, key=%s, new_order=%s',
            logicalIndex,
            colKey,
            'asc' if new_order == asc else 'desc',
        )

    def setupFilterWidget(self):
        self._filterWidget = QWidget(self)
        self._filterLayout = QHBoxLayout(self._filterWidget)
        self._filterLayout.setContentsMargins(0, 0, 0, 0)
        self._filterSpacer = QSpacerItem(
            1,
            0,
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Minimum,
        )
        self._filterLabel = QLabel('Filter keyword: ', self)
        self._filterLineEdit = QLineEdit(self)
        self._filterLineEdit.setPlaceholderText('Space separated for AND search')
        self._filterLineEdit.setFixedWidth(320)
        palette = self._filterLineEdit.palette()
        placeholderColor = QColor('gray')
        palette.setColor(QPalette.ColorRole.PlaceholderText, placeholderColor)
        self._filterLineEdit.setPalette(palette)
        if hasattr(self._filterLineEdit, 'setClearButtonEnabled'):
            self._filterLineEdit.setClearButtonEnabled(True)
        self._filterLineEdit.textChanged.connect(self._proxyModel.setKeywordFilterPattern)
        self._columnVisibilityCombo = ColumnVisibilityComboBox(self)
        self._columnVisibilityCombo.setFixedWidth(140)
        self._columnVisibilityCombo.columnVisibilityChanged.connect(self._setColumnVisible)
        self._thumbnailSizeLabel = QLabel('Thumbnail:', self)
        self._thumbnailSizeSlider = QSlider(Qt.Orientation.Horizontal, self)
        self._thumbnailSizeSlider.setRange(50, THUMBNAIL_MAX_SIZE)
        self._thumbnailSizeSlider.setValue(self._thumbnailSize)
        self._thumbnailSizeSlider.setFixedWidth(160)
        self._thumbnailSizeValueLabel = QLabel('', self)
        self._thumbnailSizeValueLabel.setMinimumWidth(42)
        self._thumbnailSizeSlider.valueChanged.connect(self.setThumbnailSize)
        self._updateThumbnailSizeLabel()
        self._filterLayout.addWidget(self._thumbnailSizeLabel)
        self._filterLayout.addWidget(self._thumbnailSizeSlider)
        self._filterLayout.addWidget(self._thumbnailSizeValueLabel)
        self._filterLayout.addItem(self._filterSpacer)
        self._filterLayout.addWidget(self._filterLabel)
        self._filterLayout.addWidget(self._filterLineEdit)
        self._filterLayout.addWidget(self._columnVisibilityCombo)
        self._vLayout.insertWidget(0, self._filterWidget)

    def _getGroups(self) -> Iterator[Group]:
        for group in self._service.iterGroups(self._root):
            yield group

    def onThumbnailUpdated(self, group: str, icon: QIcon):
        item = self._thumbnailItems.get(group)
        if item is not None:
            item.setIcon(icon)

    def _canEditColumn(self, column: Column) -> bool:
        # A parameter is editable only when both global permission and column role pass.
        return (
            self._state.hasPermission(Permission.CanEditParameters)
            and self._state.currentRole().value >= column.role().value
        )

    def _editableParameterColumns(self) -> list[Column]:
        editableByKey = {
            col.key(): col
            for col in self._getVisibleColumns()
            if col.key() not in READ_ONLY_COLUMN_KEYS and self._canEditColumn(col)
        }
        orderedColumns = [
            editableByKey.pop(key)
            for key in self.getColumnOrder()
            if key in editableByKey
        ]
        orderedColumns.extend(editableByKey.values())
        return orderedColumns

    def columnForIndex(self, index: QModelIndex) -> Column | None:
        if not index.isValid() or not 0 <= index.column() < len(self._headerMap):
            return None
        key = self._headerMap[index.column()]
        return next((col for col in self._getVisibleColumns() if col.key() == key), None)

    def valueForIndex(self, index: QModelIndex, column: Column) -> Any:
        group = index.data(self.GROUPPATH_ROLE)
        entity = self._entities.get(group)
        if entity is None:
            return ''
        return entity.data().get(column.key(), '')

    def canDirectEditCell(self, index: QModelIndex, showWarning: bool = True) -> bool:
        group = index.data(self.GROUPPATH_ROLE)
        column = self.columnForIndex(index)
        if group is None or column is None:
            return False

        if column.key() in READ_ONLY_COLUMN_KEYS:
            if showWarning:
                QMessageBox.information(
                    self,
                    'Read Only',
                    f'"{column.displayName()}" cannot be edited directly.',
                )
            return False

        if not self._canEditColumn(column):
            if showWarning:
                QMessageBox.information(
                    self,
                    'Permission Denied',
                    (
                        f'"{column.displayName()}" requires '
                        f'{column.roleDisplayName()} role or higher.'
                    ),
                )
            return False

        return True

    def saveDirectCellEdit(self, index: QModelIndex, column: Column, value: Any) -> bool:
        group = index.data(self.GROUPPATH_ROLE)
        if group is None:
            return False

        if not self.canDirectEditCell(index):
            return False

        key = column.key()
        targetGroups = [group]
        changeData = {key: value}

        existingValueGroups: list[str] = []
        for targetGroup in targetGroups:
            entity = self._entities.get(targetGroup)
            oldValue = entity.data().get(key, '') if entity is not None else ''
            if oldValue is not None and str(oldValue) != '' and str(oldValue) != str(value):
                existingValueGroups.append(targetGroup)

        if existingValueGroups:
            if len(existingValueGroups) == 1:
                message = (
                    f'"{column.displayName()}" already has an old value '
                    f'for "{existingValueGroups[0]}".\n\n'
                    'Click Ok to replace the old value with the new value, '
                    'or Cancel to keep the old value.'
                )
            else:
                previewGroups = ', '.join(existingValueGroups[:5])
                if len(existingValueGroups) > 5:
                    previewGroups += f', and {len(existingValueGroups) - 5} more'
                message = (
                    f'"{column.displayName()}" already has old values in '
                    f'{len(existingValueGroups)} selected rows:\n'
                    f'{previewGroups}\n\n'
                    'Click Ok to replace the old values with the new value, '
                    'or Cancel to keep the old values.'
                )
            confirm = QMessageBox.question(
                self,
                'Confirm Replace Values',
                message,
                QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            )
            if confirm != QMessageBox.StandardButton.Ok:
                return False

        updateCount = 0
        try:
            for targetGroup in targetGroups:
                entity = self._entities.get(targetGroup)
                oldValue = entity.data().get(key, '') if entity is not None else ''
                if str(oldValue) == str(value):
                    continue

                if entity is not None:
                    self._api.updateEntity(entity.id(), self._root, targetGroup, changeData)
                else:
                    self._api.createEntity(self._root, targetGroup, changeData)
                self.updateSingleEntity(targetGroup, changeData)
                updateCount += 1
            return True
        except Exception as ex:
            QMessageBox.critical(self, 'Error', str(ex))
            return False

    def beginDirectCellEdit(
        self,
        index: QModelIndex,
    ) -> bool:
        if not self.canDirectEditCell(index):
            return False
        selectionModel = self._getView().selectionModel()
        if selectionModel is not None:
            selectionModel.setCurrentIndex(
                index,
                (
                    QItemSelectionModel.SelectionFlag.ClearAndSelect
                    | QItemSelectionModel.SelectionFlag.Rows
                ),
            )
        self._getView().edit(index)
        return True

    def showCellContextMenu(self, view: QAbstractItemView, pos: QPoint) -> None:
        index = view.indexAt(pos)
        if not index.isValid():
            return

        selectedGroups = self._getSelection()
        clickedGroup = index.data(self.GROUPPATH_ROLE)
        isMultiSelectedClick = clickedGroup in selectedGroups and len(selectedGroups) > 1
        if isMultiSelectedClick:
            return

        menu = QMenu(view)
        editAction = menu.addAction('Edit in Cell')
        editAction.setEnabled(
            self.canDirectEditCell(index, showWarning=False)
        )

        selectedAction = menu.exec(view.viewport().mapToGlobal(pos))
        if selectedAction == editAction:
            self.beginDirectCellEdit(index)

    def onDoubleClick(self, index: QModelIndex):
        group = index.data(self.GROUPPATH_ROLE)
        if group is None:
            return

        editableColumns = self._editableParameterColumns()
        if not editableColumns:
            QMessageBox.information(
                self,
                'Permission Denied',
                'You do not have permission to edit any parameters.',
            )
            return

        if 0 <= index.column() < len(self._headerMap):
            clickedKey = self._headerMap[index.column()]
            clickedColumn = next(
                (col for col in self._columns if col.key() == clickedKey),
                None,
            )
            if (
                clickedColumn is not None
                and clickedColumn.key() not in READ_ONLY_COLUMN_KEYS
                and not self._canEditColumn(clickedColumn)
            ):
                # Block opening the parameter dialog when the clicked column role is higher.
                QMessageBox.information(
                    self,
                    'Permission Denied',
                    (
                        f'"{clickedColumn.displayName()}" requires '
                        f'{clickedColumn.roleDisplayName()} role or higher.'
                    ),
                )
                return

        groups = self._getSelection()
        if group not in groups:
            groups = [group]
        else:
            groups = list(dict.fromkeys(groups))
        entities = [
            entity.asDict() if entity is not None else None
            for entity in (self._entities.get(selectedGroup) for selectedGroup in groups)
        ]
        dlg = EntityEditorDialog(
            self._api,
            self._root,
            groups,
            editableColumns,
            entities,
            self,
            columnOrder=self.getColumnOrder(),
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            newRoot, savedGroups, newData = dlg.getSavedInfo()
            if newRoot != self._root:
                self.refresh()
            else:
                for savedGroup in savedGroups:
                    self.updateSingleEntity(savedGroup, newData)

    def _getSelection(self) -> list[str]:
        selectedPaths: list[str] = []
        for index in self._getView().selectionModel().selectedRows():
            path = index.data(self.GROUPPATH_ROLE)
            if path:
                selectedPaths.append(path)
        return selectedPaths

    def _setSelection(self, paths: list[str]) -> None:
        def _searchProxyIndex(parentIdx: QModelIndex):
            for row in range(self._proxyModel.rowCount(parentIdx)):
                idx = self._proxyModel.index(row, 0, parentIdx)
                path = idx.data(self.GROUPPATH_ROLE)
                if path in targetPaths:
                    selectionModel.select(
                        idx,
                        QItemSelectionModel.SelectionFlag.Select
                        | QItemSelectionModel.SelectionFlag.Rows,  # noqa: E501
                    )
                    self._getView().scrollTo(idx)

                if self._proxyModel.hasChildren(idx):
                    _searchProxyIndex(idx)

        if not paths:
            return

        targetPaths = set(paths)
        selectionModel = self._getView().selectionModel()
        selectionModel.clearSelection()

        _searchProxyIndex(QModelIndex())

    def refresh(self, columns: list[Column] | None = None) -> None:
        self._pendingSelection = self._getSelection()
        self.refreshColumns(columns)
        self.refreshData()

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        if columns is not None:
            self._columns = columns

        visible_cols = self._getVisibleColumns()
        displayColumns = [col.displayName() for col in visible_cols]

        self._model.setColumnCount(len(displayColumns))
        self._model.setHorizontalHeaderLabels(displayColumns)
        self._headerMap = [col.key() for col in visible_cols]
        self._proxyModel.setColumnFilterNames(visible_cols)
        self._applyColumnVisibility()
        self.applyColumnOrder(self.getSavedColumnOrder(self._root))
        self._refreshColumnVisibilityCombo()

    def exportCsv(self) -> None:
        filePath, _ = QFileDialog.getSaveFileName(
            self,
            'Export CSV',
            '',
            'CSV Files (*.csv)',
        )
        if not filePath:
            return

        try:
            _logger.debug('Exporting CSV to %s', filePath)
            with open(filePath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)

                # Header
                headers = [
                    col.key()
                    for col in self._columns
                    if col.visibled() and col.key() != 'thumbnail'
                ]  # noqa: E501
                writer.writerow(headers)

                # Data
                allGroups = [grp.keyName() for grp in self._getGroups()]
                sortedKeys = sorted(allGroups)

                for key in sortedKeys:
                    entity = self._entities.get(key)

                    row: list[str] = []
                    for col in self._columns:
                        if not col.visibled() or col.key() == 'thumbnail':
                            continue

                        colKey = col.key()
                        if colKey in GENERATED_COLUMN_KEYS:
                            row.append(self._getGeneratedValue(colKey, key))
                        elif colKey == 'name':
                            row.append(key)
                        else:
                            val = ''
                            if entity:
                                val = entity.data().get(colKey, '')
                            row.append(str(val))
                    writer.writerow(row)

            _logger.debug('CSV export completed: %s', filePath)
            QMessageBox.information(self, 'Success', f'Exported to {filePath}')

        except Exception as e:
            _logger.exception('Error exporting CSV')
            QMessageBox.critical(self, 'Error', str(e))

    def _validateImportValue(self, value: str | Any, column: Column) -> str | None:
        dtype = column.dataType()

        if not value:
            return None

        if dtype == 'int':
            try:
                int(value)
                return 'valid'
            except ValueError:
                return 'error'
        elif dtype == 'float':
            try:
                float(value)
                return 'valid'
            except ValueError:
                return 'error'
        elif dtype == 'bool':
            if str(value).lower() in ('true', 'false', '0', '1'):
                return 'valid'
            return 'error'
        elif dtype == 'array':
            options = column.config().get('options', [])
            isMulti = column.config().get('multi_select', False)
            if isMulti:
                vals = [v.strip() for v in str(value).split(',')]
                for v in vals:
                    if v and v not in options:
                        return 'warning'
            else:
                if str(value) not in options:
                    return 'warning'
        return 'valid'

    def importCsv(self) -> None:
        filePath, _ = QFileDialog.getOpenFileName(
            self,
            'Import CSV',
            '',
            'CSV Files (*.csv)',
        )
        if not filePath:
            return

        try:
            _logger.debug('Importing CSV from %s', filePath)
            changes: list[CsvEntityData] = []
            validGroups = {grp.keyName() for grp in self._getGroups()}
            columnMap = {c.key(): c for c in self._columns}
            with open(filePath, 'r', newline='', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                if reader.fieldnames is not None and 'name' not in reader.fieldnames:
                    raise ValueError('CSV must have a "name" column to identify entities.')

                csvHeaders = reader.fieldnames
                if csvHeaders is None:
                    raise ValueError('CSV file is empty or invalid.')
                validKeys = {col.key() for col in self._columns}
                # Filter out read-only columns from the display columns
                # This ensures that only editable columns are considered for import
                displayColumns = [
                    h for h in csvHeaders if h in validKeys and h not in READ_ONLY_COLUMN_KEYS
                ]

                for row in reader:
                    name = row.get('name')
                    if not name or name not in validGroups:
                        continue

                    dataEntity = self._entities.get(name)
                    isNew = False
                    if dataEntity is None:
                        isNew = True
                        _logger.debug('Creating new entity for %s', name)
                        # Add an entity without updating the UI
                        dataEntity = Entity('', '', self._root, name, {}, '', '', '', '', '0')

                    entityChanges: dict[str, dict[str, str | Any]] = {}

                    for colKey in displayColumns:
                        column = columnMap.get(colKey)
                        if column is None:
                            continue

                        newVal = row.get(colKey)
                        if newVal is None:
                            continue
                        currentVal = dataEntity.data().get(colKey, '')
                        if str(currentVal) != str(newVal):
                            status = self._validateImportValue(newVal, column)
                            if status is None:
                                continue
                            entityChanges[colKey] = {
                                'value': newVal,
                                'status': status,
                            }

                    if entityChanges:
                        _logger.debug('Changes detected for entity %s: %s', name, entityChanges)
                        changes.append(
                            CsvEntityData(
                                entity=dataEntity,
                                changes=entityChanges,
                                isNew=isNew,
                            )
                        )

            if not changes:
                _logger.debug('No changes detected in CSV import.')
                QMessageBox.information(self, 'Info', 'No changes detected.')
                return

            dlg = ConfirmImportDialog(changes, displayColumns, self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                updateCount = 0
                for item in changes:
                    entity: Entity = item['entity']
                    rawChanges: dict[str, dict[str, str | Any]] = item['changes']
                    isNew: bool = item.get('isNew', False)

                    changeData: dict[str, str | Any] = {}
                    for key, val in rawChanges.items():
                        rawVal = val.get('value')
                        if val.get('status') == 'valid' and rawVal:
                            changeData[key] = rawVal
                    if not changeData:
                        continue

                    if isNew:
                        self._api.createEntity(
                            entity.root(),
                            entity.group(),
                            changeData,
                        )
                    else:
                        self._api.updateEntity(
                            entity.id(),
                            entity.root(),
                            entity.group(),
                            changeData,
                        )
                    self.updateSingleEntity(entity.group(), changeData)
                    updateCount += 1

                if updateCount > 0:
                    _logger.debug('%d entities updated/created.', updateCount)
                    QMessageBox.information(
                        self,
                        'Success',
                        f'{updateCount} entities updated/created.',
                    )
                else:
                    _logger.debug('No valid data to update.')
                    QMessageBox.warning(self, 'Warning', 'No valid data to update.')

        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        raise NotImplementedError

    def refreshData(self) -> None:
        # PPITRACKER-48: previously `raise NotImplementedError` here, with
        # TableWidget/TreeWidget each fetching via ApiClient.searchEntities()
        # directly inside their own refreshData(). Now this base
        # implementation fetches asynchronously via LoadEntitiesTask, and
        # subclasses only implement _applyEntities() (below) to consume
        # already-fetched data.
        self.dataProgressChanged.emit(
            self._root,
            0,
            0,
            f'Fetching {self._root} data...',
        )
        task = LoadEntitiesTask(
            self._api,
            self._root,
            self._currentSortKey,
            self._currentSortDirection,
        )
        task.entitiesLoaded.connect(self._onEntitiesLoaded)
        self._entitiesTask = task
        self._service.threadStart(task)

    def _onEntitiesLoaded(self, root: str, rawEntities: list[Any]) -> None:  # PPITRACKER-48 (new)
        if root != self._root:
            return
        self._entitiesTask = None
        # PPITRACKER-48: _applyEntities now populates rows in batches across
        # multiple event-loop ticks (see ROWS_PER_BATCH below) so large
        # result sets appear progressively instead of all at once. Selection
        # restore and dataLoaded now fire from _onRowsApplied, once row
        # population has actually finished, instead of immediately here.
        self._applyGeneration += 1
        self._generatedValueCache.clear()
        self.dataProgressChanged.emit(
            self._root,
            0,
            max(1, len(rawEntities)),
            f'Building {self._root} rows...',
        )
        self._applyEntities(rawEntities, self._applyGeneration, self._onRowsApplied)

    def _onRowsApplied(self) -> None:  # PPITRACKER-48 (new)
        self.dataProgressChanged.emit(
            self._root,
            1,
            1,
            f'{self._root.capitalize()} rows ready.',
        )
        self._setSelection(self._pendingSelection)
        self._pendingSelection = []
        self.dataLoaded.emit()

    def _applyEntities(
        self,
        rawEntities: list[Any],
        generation: int,
        onComplete: 'Callable[[], None]',
    ) -> None:
        raise NotImplementedError

    def _getGeneratedValue(self, colKey: str, group: str) -> str:
        if self._root == 'shots' and colKey == 'cut_number':
            parts = [part for part in group.split('/') if part]
            if len(parts) >= 3:
                return '_'.join(parts)
        if self._root == 'shots' and colKey == 'allAssets':
            cacheKey = (colKey, group)
            if cacheKey not in self._generatedValueCache:
                value = self._getPipelineGeneratedValue(
                    colKey,
                    [f'{self._root}/{group}', group],
                )
                self._generatedValueCache[cacheKey] = value or '-'
            return self._generatedValueCache[cacheKey]
        return ''

    def _getPipelineGeneratedValue(self, colKey: str, locations: list[str]) -> str:
        for parameterKey in self._pipelineParameterKeys(colKey):
            for location in locations:
                value = self._getPipelineDeliveryValue(location, parameterKey)
                if value:
                    return value

                value = self._getLocalPipelineDbValue(location, parameterKey)
                if value:
                    return value
        return ''

    def _getPipelineDeliveryValue(self, location: str, parameterKey: str) -> str:
        try:
            rawValue = self._service.pipelineParameterValue(location, parameterKey)
        except Exception:
            _logger.debug(
                'PipelineParameterDelivery failed for %s at %s',
                parameterKey,
                location,
                exc_info=True,
            )
            return ''
        return self._formatGeneratedValue(rawValue)

    def _getLocalPipelineDbValue(self, location: str, parameterKey: str) -> str:
        try:
            rawValue = self._service.localPipelineParameterValue(location, parameterKey)
        except Exception:
            _logger.debug(
                'Local pipeline parameter DB lookup failed for %s at %s',
                parameterKey,
                location,
                exc_info=True,
            )
            return ''
        return self._formatGeneratedValue(rawValue)

    def _pipelineParameterKeys(self, colKey: str) -> list[str]:
        if colKey != 'allAssets':
            return [colKey]

        project = self._service.project()
        projectKey = project.keyName() if project is not None else ''
        if projectKey == 'potoodev':
            return ['testAllAssets', 'allAssets']
        return ['allAssets', 'testAllAssets']

    def _formatGeneratedValue(self, value: Any) -> str:
        if value is None:
            return ''
        if isinstance(value, dict):
            return ', '.join(f'{key}: {val}' for key, val in value.items())
        if isinstance(value, (list, tuple, set)):
            return ', '.join(str(item) for item in value)
        return str(value)

    def _applyGeneratedValueToItem(self, item: QStandardItem, value: str) -> None:
        item.setText(value)
        item.setToolTip(value)
        item.setData(value.lower(), self.SORT_ROLE)
        item.setData(value, self.FILTER_ROLE)
        if value == '-':
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)


class TableWidget(DataWidget):
    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(service, api, state, columns, thumbnailCache, root, parent)

        self._tableWidget = QTableView(self)
        self._tableWidget.setAlternatingRowColors(True)
        self._tableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._tableWidget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._tableWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._tableWidget.verticalHeader().setDefaultSectionSize(self._rowHeight())
        self._tableWidget.setIconSize(QSize(self._thumbnailSize, self._thumbnailSize))
        self._tableWidget.setModel(self._proxyModel)
        self._tableWidget.setItemDelegate(InlineCellEditDelegate(self, self._tableWidget))
        self._vLayout.addWidget(self._tableWidget)

        # Keep Thumbnail and Name visible while scrolling horizontally.
        self._frozenColumnsTableWidget = QTableView(self._tableWidget)
        self._frozenColumnsTableWidget.setModel(self._proxyModel)
        self._frozenColumnsTableWidget.setSelectionModel(self._tableWidget.selectionModel())
        self._frozenColumnsTableWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._frozenColumnsTableWidget.setAlternatingRowColors(True)
        self._frozenColumnsTableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._frozenColumnsTableWidget.setIconSize(
            QSize(self._thumbnailSize, self._thumbnailSize),
        )
        self._frozenColumnsTableWidget.setItemDelegate(
            InlineCellEditDelegate(self, self._frozenColumnsTableWidget),
        )
        self._frozenColumnsTableWidget.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self._frozenColumnsTableWidget.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self._frozenColumnsTableWidget.verticalHeader().setDefaultSectionSize(
            self._rowHeight(),
        )
        self._frozenColumnsTableWidget.verticalHeader().hide()
        self._frozenColumnsTableWidget.horizontalHeader().setSectionsClickable(False)
        self._frozenColumnsTableWidget.horizontalHeader().setSortIndicatorShown(False)
        self._frozenColumnsTableWidget.horizontalScrollBar().hide()
        self._frozenColumnsTableWidget.verticalScrollBar().hide()
        self._frozenColumnsTableWidget.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._frozenColumnsTableWidget.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._tableWidget.viewport().installEventFilter(self)
        self._tableWidget.horizontalHeader().sectionResized.connect(
            self._updateFrozenColumns
        )
        self._tableWidget.verticalScrollBar().valueChanged.connect(
            self._frozenColumnsTableWidget.verticalScrollBar().setValue
        )
        self._frozenColumnsTableWidget.verticalScrollBar().valueChanged.connect(
            self._tableWidget.verticalScrollBar().setValue
        )
        self._tableWidget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._tableWidget.customContextMenuRequested.connect(
            lambda pos: self.showCellContextMenu(self._tableWidget, pos)
        )
        self._frozenColumnsTableWidget.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self._frozenColumnsTableWidget.customContextMenuRequested.connect(
            lambda pos: self.showCellContextMenu(self._frozenColumnsTableWidget, pos)
        )

        self.setupFilterWidget()
        self.enableCustomSorting()
        self.enableColumnReordering()
        self._tableWidget.doubleClicked.connect(self.onDoubleClick)
        self._frozenColumnsTableWidget.doubleClicked.connect(self.onDoubleClick)

    def eventFilter(self, watched: QWidget, event: QEvent) -> bool:
        if watched == self._tableWidget.viewport() and event.type() == QEvent.Type.Resize:
            self._updateFrozenColumns()
        return super().eventFilter(watched, event)

    def _getView(self) -> QTableView:
        return self._tableWidget

    def _getHorizontalHeader(self) -> QHeaderView:
        return self._tableWidget.horizontalHeader()

    def _getVisibleColumns(self) -> list[Column]:
        return [col for col in self._columns if col.visibled()]

    def _applyThumbnailSize(self) -> None:
        iconSize = QSize(self._thumbnailSize, self._thumbnailSize)
        rowHeight = self._rowHeight()
        self._tableWidget.setIconSize(iconSize)
        self._frozenColumnsTableWidget.setIconSize(iconSize)
        self._tableWidget.verticalHeader().setDefaultSectionSize(rowHeight)
        self._frozenColumnsTableWidget.verticalHeader().setDefaultSectionSize(rowHeight)
        thumbnailCol = self._thumbnailColumnIndex()
        if thumbnailCol is not None:
            width = self._thumbnailColumnWidth()
            self._tableWidget.setColumnWidth(thumbnailCol, width)
            self._frozenColumnsTableWidget.setColumnWidth(thumbnailCol, width)
        for row in range(self._model.rowCount()):
            for col in range(self._model.columnCount()):
                item = self._model.item(row, col)
                if item is not None:
                    item.setSizeHint(self._rowSizeHint())
        self._updateThumbnailSizeLabel()
        self._updateFrozenColumns()

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        super().refreshColumns(columns)

        header = self._getHorizontalHeader()
        if header.count() > 1:
            header.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
            self._tableWidget.setColumnWidth(1, 150)
        thumbnailCol = self._thumbnailColumnIndex()
        if thumbnailCol is not None:
            self._tableWidget.setColumnWidth(thumbnailCol, self._thumbnailColumnWidth())
        self._updateFrozenColumns()

    def _updateFrozenColumns(self) -> None:
        # Mirror only the first two columns and place them over the scrolling table viewport.
        frozenColumns = [
            idx
            for idx, key in enumerate(self._headerMap[:2])
            if key not in self._hiddenColumnKeys
        ]
        if not frozenColumns:
            self._frozenColumnsTableWidget.hide()
            return

        for col in range(self._proxyModel.columnCount()):
            self._frozenColumnsTableWidget.setColumnHidden(col, col not in frozenColumns)

        frozenWidth = 0
        for col in frozenColumns:
            columnWidth = self._tableWidget.columnWidth(col)
            self._frozenColumnsTableWidget.setColumnWidth(col, columnWidth)
            frozenWidth += columnWidth

        self._frozenColumnsTableWidget.setFixedWidth(frozenWidth)
        self._frozenColumnsTableWidget.setFixedHeight(
            self._tableWidget.viewport().height()
            + self._tableWidget.horizontalHeader().height()
        )
        self._frozenColumnsTableWidget.move(
            self._tableWidget.verticalHeader().width() + self._tableWidget.frameWidth(),
            self._tableWidget.frameWidth(),
        )
        self._frozenColumnsTableWidget.show()
        self._frozenColumnsTableWidget.raise_()

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        entity = self._entities.get(group)
        if entity is not None:
            entity.data().update(data)
        else:
            # Create local cache if not exists (for new entities)
            # We don't have full server info (ID etc) but enough for display
            self._entities[group] = Entity('', '', self._root, group, data, '', '', '', '', '0')

        for row in range(self._model.rowCount()):
            index = self._model.index(row, 0)
            if index.data(self.GROUPPATH_ROLE) == group:
                for colIdx, column in enumerate(self._getVisibleColumns()):
                    key = column.key()
                    if key in READ_ONLY_COLUMN_KEYS:
                        continue
                    if key in data:
                        item = self._model.itemFromIndex(self._model.index(row, colIdx))
                        if item:
                            val = data.get(key, '')
                            item.setText(str(val))
                            item.setToolTip(str(val))
                            item.setData(
                                self._getTypedValue(val, column.dataType()),
                                self.SORT_ROLE,
                            )
                            item.setData(str(val), self.FILTER_ROLE)
                break

    ROWS_PER_BATCH = 1  # PPITRACKER-48: one row per event-loop tick, per request

    def _applyEntities(
        self,
        rawEntities: list[Any],
        generation: int,
        onComplete: 'Callable[[], None]',
    ) -> None:
        # PPITRACKER-48: renamed from refreshData(); previously started with
        # `rawEntities = self._api.searchEntities(...)` (network call now
        # lives in DataWidget.refreshData()/LoadEntitiesTask). Row-building
        # logic is unchanged, but now runs in batches (see
        # _appendRowsBatched below) so rows appear progressively instead of
        # all at once - useful when there are enough rows for the build
        # itself to take noticeable time. `generation` guards against a
        # second refresh starting before this one finishes: each batch
        # checks it's still the current generation before continuing.
        self._entities = {
            ent.get('group'): Entity.fromDict(ent) for ent in rawEntities if ent.get('group')
        }  # noqa: E501

        groupKeyNames = [grp.keyName() for grp in self._getGroups()]
        self._model.removeRows(0, self._model.rowCount())
        self._thumbnailItems.clear()

        self._appendRowsBatched(groupKeyNames, 0, generation, onComplete)

    def _appendRowsBatched(
        self,
        groupKeyNames: list[str],
        startIdx: int,
        generation: int,
        onComplete: 'Callable[[], None]',
    ) -> None:
        if generation != self._applyGeneration:
            return  # a newer refresh superseded this one; abandon silently

        visible_cols = self._getVisibleColumns()
        endIdx = min(startIdx + self.ROWS_PER_BATCH, len(groupKeyNames))

        for i in range(startIdx, endIdx):
            ent = groupKeyNames[i]
            _entity = self._entities.get(ent)
            items: list[QStandardItem] = []
            for column in visible_cols:
                item = QStandardItem()
                item.setSizeHint(self._rowSizeHint())
                item.setData(ent, self.GROUPPATH_ROLE)
                item.setData(ent, self.FILTER_ROLE)

                if column.key() == 'thumbnail':
                    cacheKey = f'{self._root}/{ent}'
                    icon = self._thumbnailCache.get(cacheKey, self._defaultThumbnailIcon)
                    item.setIcon(icon)
                    # 高速アクセスのために辞書に登録
                    self._thumbnailItems[ent] = item
                    item.setData('', self.SORT_ROLE)
                    item.setData('', self.FILTER_ROLE)
                elif column.key() == 'name':
                    item.setText(str(ent))
                    item.setData(str(ent).lower(), self.SORT_ROLE)
                    item.setData(str(ent), self.FILTER_ROLE)
                elif column.key() in GENERATED_COLUMN_KEYS:
                    val = self._getGeneratedValue(column.key(), ent)
                    self._applyGeneratedValueToItem(item, val)
                else:
                    val = _entity.data().get(column.key(), '') if _entity is not None else ''
                    item.setText(str(val))
                    item.setToolTip(str(val))
                    item.setData(self._getTypedValue(val, column.dataType()), self.SORT_ROLE)
                    item.setData(str(val), self.FILTER_ROLE)
                items.append(item)
            if items:
                self._model.appendRow(items)

        self.dataProgressChanged.emit(
            self._root,
            endIdx,
            max(1, len(groupKeyNames)),
            self._buildProgressMessage(groupKeyNames, endIdx),
        )

        if endIdx < len(groupKeyNames):
            QTimer.singleShot(
                0,
                lambda: self._appendRowsBatched(groupKeyNames, endIdx, generation, onComplete),
            )
            return

        if self._currentSortKey in self._headerMap:
            colIdx = self._headerMap.index(self._currentSortKey)
            order = (
                Qt.SortOrder.AscendingOrder
                if self._currentSortDirection == 1
                else Qt.SortOrder.DescendingOrder
            )  # noqa: E501
            self._getHorizontalHeader().setSortIndicator(colIdx, order)
            self._proxyModel.sort(colIdx, order)
        onComplete()


class TreeWidget(DataWidget):
    def __init__(
        self,
        service: Service,
        api: ApiClient,
        state: State,
        columns: list[Column],
        thumbnailCache: dict[str, QIcon],
        root: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(service, api, state, columns, thumbnailCache, root, parent)

        self._treeWidget = QTreeView(self)
        self._treeWidget.setAlternatingRowColors(True)
        treeStyleSheet = (
            'QTreeView::branch:has-siblings:!adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:has-siblings:adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:!has-children:!has-siblings:adjoins-item {\n'
            '    border-image: none;\n'
            '}\n'
            'QTreeView::branch:has-children:!has-siblings:closed,\n'
            'QTreeView::branch:closed:has-children:has-siblings {\n'
            '    border-image: none;\n'
            '    image: url(:/angle-right.png);\n'
            '}\n'
            'QTreeView::branch:open:has-children:!has-siblings,\n'
            'QTreeView::branch:open:has-children:has-siblings {\n'
            '    border-image: none;\n'
            '    image: url(:/angle-down.png);\n'
            '}'
        )
        self._treeWidget.setStyleSheet(treeStyleSheet)
        self._treeWidget.setIconSize(QSize(self._thumbnailSize, self._thumbnailSize))
        self._treeWidget.setModel(self._proxyModel)
        self._treeWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._treeWidget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._treeWidget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._treeWidget.setItemDelegate(InlineCellEditDelegate(self, self._treeWidget))
        self._vLayout.addWidget(self._treeWidget)

        # Keep Thumbnail and Name visible while scrolling horizontally.
        self._frozenColumnsTreeWidget = QTreeView(self._treeWidget)
        self._frozenColumnsTreeWidget.setModel(self._proxyModel)
        self._frozenColumnsTreeWidget.setSelectionModel(self._treeWidget.selectionModel())
        self._frozenColumnsTreeWidget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._frozenColumnsTreeWidget.setAlternatingRowColors(True)
        self._frozenColumnsTreeWidget.setStyleSheet(treeStyleSheet)
        self._frozenColumnsTreeWidget.setIconSize(
            QSize(self._thumbnailSize, self._thumbnailSize),
        )
        self._frozenColumnsTreeWidget.setItemDelegate(
            InlineCellEditDelegate(self, self._frozenColumnsTreeWidget),
        )
        self._frozenColumnsTreeWidget.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self._frozenColumnsTreeWidget.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self._frozenColumnsTreeWidget.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self._frozenColumnsTreeWidget.header().setSectionsClickable(False)
        self._frozenColumnsTreeWidget.header().setSortIndicatorShown(False)
        self._frozenColumnsTreeWidget.horizontalScrollBar().hide()
        self._frozenColumnsTreeWidget.verticalScrollBar().hide()
        self._frozenColumnsTreeWidget.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._frozenColumnsTreeWidget.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._treeWidget.viewport().installEventFilter(self)
        self._treeWidget.header().sectionResized.connect(
            lambda *_: self._updateFrozenColumns()
        )
        self._treeWidget.header().sectionMoved.connect(
            lambda *_: self._updateFrozenColumns()
        )
        self._treeWidget.horizontalScrollBar().valueChanged.connect(
            lambda *_: self._updateFrozenColumns()
        )
        self._treeWidget.verticalScrollBar().valueChanged.connect(
            self._frozenColumnsTreeWidget.verticalScrollBar().setValue
        )
        self._frozenColumnsTreeWidget.verticalScrollBar().valueChanged.connect(
            self._treeWidget.verticalScrollBar().setValue
        )
        self._treeWidget.expanded.connect(self._frozenColumnsTreeWidget.expand)
        self._treeWidget.collapsed.connect(self._frozenColumnsTreeWidget.collapse)
        self._frozenColumnsTreeWidget.expanded.connect(self._treeWidget.expand)
        self._frozenColumnsTreeWidget.collapsed.connect(self._treeWidget.collapse)
        self._treeWidget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._treeWidget.customContextMenuRequested.connect(
            lambda pos: self.showCellContextMenu(self._treeWidget, pos)
        )
        self._frozenColumnsTreeWidget.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self._frozenColumnsTreeWidget.customContextMenuRequested.connect(
            lambda pos: self.showCellContextMenu(self._frozenColumnsTreeWidget, pos)
        )

        self.setupFilterWidget()
        self.enableCustomSorting()
        self.enableColumnReordering()
        self._treeWidget.doubleClicked.connect(self.onDoubleClick)
        self._frozenColumnsTreeWidget.doubleClicked.connect(self.onDoubleClick)

    def eventFilter(self, watched: QWidget, event: QEvent) -> bool:
        if watched == self._treeWidget.viewport() and event.type() == QEvent.Type.Resize:
            self._updateFrozenColumns()
        return super().eventFilter(watched, event)

    def _getView(self) -> QTreeView:
        return self._treeWidget

    def _getHorizontalHeader(self) -> QHeaderView:
        return self._treeWidget.header()

    def _applyThumbnailSize(self) -> None:
        def _updateRecursively(parentItem: QStandardItem) -> None:
            for row in range(parentItem.rowCount()):
                for col in range(self._model.columnCount()):
                    item = parentItem.child(row, col)
                    if item is not None:
                        item.setSizeHint(self._rowSizeHint())
                child = parentItem.child(row, 0)
                if child is not None and child.hasChildren():
                    _updateRecursively(child)

        iconSize = QSize(self._thumbnailSize, self._thumbnailSize)
        self._treeWidget.setIconSize(iconSize)
        self._frozenColumnsTreeWidget.setIconSize(iconSize)
        thumbnailCol = self._thumbnailColumnIndex()
        if thumbnailCol is not None:
            width = self._thumbnailColumnWidth()
            self._treeWidget.setColumnWidth(thumbnailCol, width)
            self._frozenColumnsTreeWidget.setColumnWidth(thumbnailCol, width)
        _updateRecursively(self._model.invisibleRootItem())
        self._updateThumbnailSizeLabel()
        self._updateFrozenColumns()

    def _buildColumns(self) -> list[Column]:
        _columns: list[Column] = []
        nameColumn = None
        thumbnailColumn = None
        cutNumberColumn = None
        for col in self._columns:
            if not col.visibled():
                continue
            if col.key() == 'name':
                nameColumn = col
                continue
            if col.key() == 'thumbnail':
                thumbnailColumn = col
                continue
            if col.key() == 'cut_number':
                cutNumberColumn = col
                continue
            _columns.append(col)
        if nameColumn is not None:
            _columns.insert(0, nameColumn)
        if thumbnailColumn is not None:
            _columns.insert(1, thumbnailColumn)
        if cutNumberColumn is not None:
            _columns.insert(2, cutNumberColumn)
        return _columns

    def _getVisibleColumns(self) -> list[Column]:
        return self._buildColumns()

    def refreshColumns(self, columns: list[Column] | None = None) -> None:
        super().refreshColumns(columns)

        header = self._getHorizontalHeader()
        if header.count() > 0:
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
            self._treeWidget.setColumnWidth(0, 150)
        thumbnailCol = self._thumbnailColumnIndex()
        if thumbnailCol is not None:
            self._treeWidget.setColumnWidth(thumbnailCol, self._thumbnailColumnWidth())

        _columns = self._getVisibleColumns()
        if (
            not self.getSavedColumnOrder(self._root)
            and len(_columns) >= 2
            and _columns[0].key() == 'name'
            and _columns[1].key() == 'thumbnail'
        ):
            # Ensure the 'thumbnail' column is visually before the 'name' column,
            # using current visual indices to avoid flip-flopping on repeated calls.
            nameLogical = 0
            thumbnailLogical = 1
            nameVisual = header.visualIndex(nameLogical)
            thumbnailVisual = header.visualIndex(thumbnailLogical)
            if nameVisual != -1 and thumbnailVisual != -1 and nameVisual < thumbnailVisual:
                header.moveSection(nameVisual, thumbnailVisual)
            self._syncFrozenColumnVisualOrder()

        self._updateFrozenColumns()

    def _syncFrozenColumnVisualOrder(self) -> None:
        sourceHeader = self._treeWidget.header()
        frozenHeader = self._frozenColumnsTreeWidget.header()
        frozenHeader.blockSignals(True)
        try:
            for visualIdx in range(sourceHeader.count()):
                logicalIdx = sourceHeader.logicalIndex(visualIdx)
                frozenVisualIdx = frozenHeader.visualIndex(logicalIdx)
                if frozenVisualIdx != -1 and frozenVisualIdx != visualIdx:
                    frozenHeader.moveSection(frozenVisualIdx, visualIdx)
        finally:
            frozenHeader.blockSignals(False)

    def _updateFrozenColumns(self) -> None:
        self._syncFrozenColumnVisualOrder()
        frozenColumns = [
            idx
            for idx, key in enumerate(self._headerMap)
            if key in ('thumbnail', 'name') and key not in self._hiddenColumnKeys
        ]
        if not frozenColumns:
            self._frozenColumnsTreeWidget.hide()
            return

        for col in range(self._proxyModel.columnCount()):
            self._frozenColumnsTreeWidget.setColumnHidden(col, col not in frozenColumns)

        frozenWidth = 0
        for col in sorted(frozenColumns, key=self._treeWidget.header().visualIndex):
            columnWidth = self._treeWidget.columnWidth(col)
            self._frozenColumnsTreeWidget.setColumnWidth(col, columnWidth)
            frozenWidth += columnWidth

        self._frozenColumnsTreeWidget.horizontalScrollBar().setValue(0)
        self._frozenColumnsTreeWidget.setFixedWidth(frozenWidth)
        self._frozenColumnsTreeWidget.setFixedHeight(
            self._treeWidget.viewport().height() + self._treeWidget.header().height()
        )
        self._frozenColumnsTreeWidget.move(
            self._treeWidget.frameWidth(),
            self._treeWidget.frameWidth(),
        )
        self._frozenColumnsTreeWidget.show()
        self._frozenColumnsTreeWidget.raise_()

    def updateSingleEntity(self, group: str, data: dict[str, Any]) -> None:
        def _updateRecursively(parentItem: QStandardItem):
            for row in range(parentItem.rowCount()):
                child = parentItem.child(row, 0)
                if child and child.data(self.GROUPPATH_ROLE) == group:
                    for colIdx, column in enumerate(self._getVisibleColumns()):
                        key = column.key()
                        if key in READ_ONLY_COLUMN_KEYS:
                            continue
                        if key in data:
                            sibling = parentItem.child(row, colIdx)
                            if sibling:
                                val = data.get(key, '')
                                sibling.setText(str(val))
                                sibling.setToolTip(str(val))
                                typed_val = self._getTypedValue(val, column.dataType())
                                sibling.setData(typed_val, self.SORT_ROLE)
                                sibling.setData(str(val), self.FILTER_ROLE)
                    return True
                if child and child.hasChildren():
                    if _updateRecursively(child):
                        return True
            return False

        entity = self._entities.get(group)
        if entity is not None:
            entity.data().update(data)
        else:
            # Create local cache if not exists (for new entities)
            # We don't have full server info (ID etc) but enough for display
            self._entities[group] = Entity('', '', self._root, group, data, '', '', '', '', '0')

        _updateRecursively(self._model.invisibleRootItem())

    ROWS_PER_BATCH = 1  # PPITRACKER-48: one row per event-loop tick, per request

    def _applyEntities(
        self,
        rawEntities: list[Any],
        generation: int,
        onComplete: 'Callable[[], None]',
    ) -> None:
        # PPITRACKER-48: renamed from refreshData(); previously started with
        # `rawEntities = self._api.searchEntities(...)` (network call now
        # lives in DataWidget.refreshData()/LoadEntitiesTask). Tree-building
        # logic is unchanged, but now runs in batches (see
        # _appendGroupsBatched below) so branches appear progressively
        # instead of all at once for large result sets. `generation` guards
        # against a second refresh starting before this one finishes.
        self._entities = {
            ent.get('group'): Entity.fromDict(ent) for ent in rawEntities if ent.get('group')
        }  # noqa: E501

        groupKeyNames = [grp.keyName() for grp in self._getGroups()]
        self._model.removeRows(0, self._model.rowCount())
        self._thumbnailItems.clear()

        self._appendGroupsBatched(groupKeyNames, 0, generation, onComplete)

    @staticmethod
    def _findChildByName(parentItem: QStandardItem, name: str) -> QStandardItem | None:
        for row in range(parentItem.rowCount()):
            child = parentItem.child(row, 0)
            if child and child.text() == name:
                return child
        return None

    def _appendGroupsBatched(
        self,
        groupKeyNames: list[str],
        startIdx: int,
        generation: int,
        onComplete: 'Callable[[], None]',
    ) -> None:
        if generation != self._applyGeneration:
            return  # a newer refresh superseded this one; abandon silently

        visibleCols = self._getVisibleColumns()
        endIdx = min(startIdx + self.ROWS_PER_BATCH, len(groupKeyNames))

        for i in range(startIdx, endIdx):
            groupKey = groupKeyNames[i]
            _entity = self._entities.get(groupKey)
            groupKeyParts = groupKey.split('/')
            currentParent = self._model.invisibleRootItem()

            for idx, part in enumerate(groupKeyParts):
                childItem = self._findChildByName(currentParent, part)
                if childItem is not None:
                    currentParent = childItem
                else:
                    items = [QStandardItem() for _ in visibleCols]
                    items[0].setText(part)
                    items[0].setData(part.lower(), self.SORT_ROLE)
                    partPath = '/'.join(groupKeyParts[: idx + 1])
                    items[0].setToolTip(partPath)
                    items[0].setData(partPath, self.FILTER_ROLE)
                    currentParent.appendRow(items)
                    currentParent = items[0]

                if idx == len(groupKeyParts) - 1:
                    currentParent.setSizeHint(self._rowSizeHint())

            parentOfCurrent = currentParent.parent() or self._model.invisibleRootItem()
            rowIdx = currentParent.row()

            for colIdx, colDef in enumerate(visibleCols):
                item = parentOfCurrent.child(rowIdx, colIdx)
                if not item:
                    continue
                item.setSizeHint(self._rowSizeHint())
                item.setData(groupKey, self.GROUPPATH_ROLE)
                item.setData(groupKey, self.FILTER_ROLE)

                if colDef.key() == 'name':
                    pass
                elif colDef.key() == 'thumbnail':
                    cacheKey = f'{self._root}/{groupKey}'
                    icon = self._thumbnailCache.get(cacheKey, self._defaultThumbnailIcon)
                    item.setIcon(icon)
                    self._thumbnailItems[groupKey] = item
                    item.setData('', self.SORT_ROLE)
                    item.setData('', self.FILTER_ROLE)
                elif colDef.key() in GENERATED_COLUMN_KEYS:
                    val = self._getGeneratedValue(colDef.key(), groupKey)
                    self._applyGeneratedValueToItem(item, val)
                else:
                    val = _entity.data().get(colDef.key(), '') if _entity is not None else ''
                    item.setText(str(val))
                    item.setToolTip(str(val))
                    item.setData(self._getTypedValue(val, colDef.dataType()), self.SORT_ROLE)
                    item.setData(str(val), self.FILTER_ROLE)

        self.dataProgressChanged.emit(
            self._root,
            endIdx,
            max(1, len(groupKeyNames)),
            self._buildProgressMessage(groupKeyNames, endIdx),
        )

        if endIdx < len(groupKeyNames):
            QTimer.singleShot(
                0,
                lambda: self._appendGroupsBatched(groupKeyNames, endIdx, generation, onComplete),
            )
            return

        self._treeWidget.expandAll()
        self._frozenColumnsTreeWidget.expandAll()

        if self._currentSortKey in self._headerMap:
            colIdx = self._headerMap.index(self._currentSortKey)
            order = (
                Qt.SortOrder.AscendingOrder
                if self._currentSortDirection == 1
                else Qt.SortOrder.DescendingOrder
            )
            self._getHorizontalHeader().setSortIndicator(colIdx, order)
            self._proxyModel.sort(colIdx, order)
        onComplete()
