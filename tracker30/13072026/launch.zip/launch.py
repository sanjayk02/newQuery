import logging
import logging.config
import sys
from logging import getLogger
from typing import Any, Dict, cast  # noqa: F401

from ppui.PySide.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal
from ppui.PySide.QtWidgets import QApplication, QMainWindow, QMessageBox

from .__version__ import __version__

_logger = getLogger(__name__)


def constructLogConfig(level: str, path: Any) -> Dict[str, Any]:
    """Logファイル出力の設定を返す。

    `version`: 指定できる値は1のみ。今後のバージョンアップ時の後方互換性確保のための項目。

    `disable_existing_loggers`: boolで指定する。
    dictConfig()実行時に、すでに存在する Loggerと同名の Loggerを設定しようとした際の挙動を指定する。
        `True`: 既存の Loggerと同名の新規 Loggerを使用不可にする。
        `False`: 既存の Loggerを上書きして新規 Loggerとして使用可能にする。

    `formatters`: ログ出力の際にどのような情報を、
    どういったフォーマットで出力するかのフォーマッタの種類を列挙する。
        `%(levelname)s`: ログレベル ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
        `%(asctime)s`: ログ生成日時 "yyyy-mm-dd HH:MM:SS,sss"
        `%(process)d`: プロセス ID
        `%(name)s`: ロギングに使われたロガーの名前
        `%(message)s`: 呼び出し時に引数で指定した値(logger.info("ここ"))
        `%(pathname)s`: ロギングの呼び出しが発せられたファイルの完全なパス名
        `%(funcName)s`: 呼び出し元関数名
        `%(lineno)d`: 呼び出し元ファイル内の行番号

    `handlers`: 各ロガーがログをどのように扱うかといったハンドラーの種類を列挙する。
        `class`: ハンドラーのクラスを指定する。
            `RotatingFileHandler`: logファイルに出力。
            `StreamHandler`: コンソール等に標準出力。
        `formatter`: ログ出力フォーマットを規定するフォーマッタを指定する。
        `filename`: 作成する logファイル名。
        `maxBytes`: logファイルの最大ファイルサイズを指定する。
        指定サイズを超えたら自動的に新しいログファイルが作成される。
        `backupCount`: ファイルを作成する回数。

    `root`: rootロガーの設定
        `level`: ログレベルを定義する。
        `handlers`: ロガーが使用するログハンドラーを指定する。
    """
    return {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'readable': {
                'format': (
                    '[%(levelname)s][%(asctime)s][%(process)d]%(name)s: %(message)s '
                    '(%(pathname)s:%(funcName)s:%(lineno)d)'
                ),
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'readable',
            },
            'file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'formatter': 'readable',
                'filename': path.as_posix(),
                'maxBytes': 1024 * 1024 * 10,
                'backupCount': 10,
            },
        },
        'root': {
            'level': level,
            'handlers': ['console', 'file'],
        },
    }


def setupLogging(debug: bool, homePath: Any) -> None:
    logPath = homePath / '.ppip30/ppiBreakdown/log/ppiTracker.log'
    logPath.parent.mkdir(parents=True, exist_ok=True)
    logLevel = 'DEBUG' if debug else 'INFO'
    logConfig = constructLogConfig(level=logLevel, path=logPath)
    logging.config.dictConfig(logConfig)
    logging.raiseExceptions = debug


class StartupWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.resize(1250, 800)
        self.setWindowTitle(f'PPI Breakdown (v{__version__})')
        self.statusBar().showMessage('Starting...')


class BootstrapRunnable(QRunnable):
    def __init__(self, task: 'BootstrapTask') -> None:
        super().__init__()
        self._task = task

    def run(self) -> None:
        self._task.run()


class BootstrapTask(QObject):
    bootstrapLoaded = Signal(object, object, object, bool, str)
    bootstrapFailed = Signal(str)

    def __init__(self, debug: bool) -> None:
        super().__init__()
        self._debug = debug

    def run(self) -> None:
        try:
            from ppilib.core.launcher import AppInfo
            from ppilib.desktop.setting import DesktopPipelineSetting, DesktopSectionManager

            from .state import State

            appInfo = AppInfo(
                displayName='PPI Breakdown',
                version=__version__,
                iconName=':/ppitools/ppiBreakdown.png',
                repoName='tracker30',
                package=__package__,
                modules=('ppiTracker', 'ppilib', 'ppui'),
                id='',
            )

            sectionManager = DesktopSectionManager()
            setupLogging(self._debug, sectionManager.bootstrapConf().userRootDir())

            pipelineSetting = cast(DesktopPipelineSetting, sectionManager.pipelineSetting())
            project = pipelineSetting.project()
            assert project is not None, 'No project selected in pipeline setting.'
            projectName = project.displayName()

            state = State(sectionManager, self._debug)
            title = '[%s] %s (v%s)' % (
                (projectName if projectName else 'No Project'),
                appInfo.displayName(),
                appInfo.version(),
            )
            self.bootstrapLoaded.emit(appInfo, sectionManager, state, self._debug, title)
        except Exception as ex:
            self.bootstrapFailed.emit(str(ex))


def launch() -> int:
    app = QApplication(sys.argv)
    app.setApplicationDisplayName(f'PPI Breakdown (v{__version__})')
    debug = '--debug' in sys.argv

    startupWin = StartupWindow()
    startupWin.show()

    threadPool = QThreadPool()
    bootstrapTask = BootstrapTask(debug)
    windows: dict[str, object] = {
        'startup': startupWin,
        'task': bootstrapTask,
        'threadPool': threadPool,
    }

    def _onBootstrapLoaded(
        appInfo: object,
        sectionManager: object,
        state: object,
        debug: bool,
        title: str,
    ) -> None:
        from ppui.desktop.style import default

        from .mainWindow import MainWindow

        default.setStyle(app)
        win = MainWindow(appInfo, state, debug)
        win.setWindowTitle(title)
        _logger.debug('Launching application: %s', title)
        win.show()
        startupWin.close()
        windows['main'] = win
        windows['sectionManager'] = sectionManager

    def _onBootstrapFailed(message: str) -> None:
        QMessageBox.critical(startupWin, 'PPI Breakdown', message)
        app.quit()

    bootstrapTask.bootstrapLoaded.connect(_onBootstrapLoaded)
    bootstrapTask.bootstrapFailed.connect(_onBootstrapFailed)
    # Paint the empty shell first; expensive imports/environment setup starts after show.
    QTimer.singleShot(50, lambda: threadPool.start(BootstrapRunnable(bootstrapTask)))

    return app.exec()
