@echo off
REM Runs ppiTracker with Python's import-time profiler enabled.
REM This measures how long each module takes to import - useful for
REM diagnosing startup delays that happen BEFORE any application code runs
REM (e.g. slow imports over a network drive).
REM
REM Output is saved next to this .bat file as importtime.log

set PYTHON_EXE="Z:\ppip30\shared\tools\3rdparty\python\win\v3.1.6\python311\python.exe"

echo Running ppiTracker with -X importtime...
echo This will take about as long as your normal slow launch - that's expected.
echo.

%PYTHON_EXE% -X importtime -m ppiTracker --window > importtime.log 2>&1

echo.
echo Done. Results saved to importtime.log
echo.
echo Showing the 30 slowest imports (by cumulative time) below:
echo ============================================================

REM Sort by the "cumulative" column (last numeric column) descending,
REM skip the header, show top 30
powershell -NoProfile -Command ^
    "Get-Content importtime.log | Select-String '^import time:' | " ^
    "ForEach-Object { $_.Line } | " ^
    "Select-Object -Skip 1 | " ^
    "ForEach-Object { $parts = $_ -split '\|'; if ($parts.Count -ge 3) { [PSCustomObject]@{Cumulative=[int]($parts[1].Trim()); Line=$_} } } | " ^
    "Sort-Object -Property Cumulative -Descending | " ^
    "Select-Object -First 30 -ExpandProperty Line"

echo.
echo ============================================================
echo Full log: importtime.log
pause
