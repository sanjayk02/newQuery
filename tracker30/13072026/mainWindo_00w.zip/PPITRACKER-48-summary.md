# PPITRACKER-48: Show MainWindow before fetching data

## Problem

Launching PPI Breakdown took ~14s before the window appeared. Both
`State.__init__` and `MainWindow.__init__` (via `Service.__init__`) made
blocking calls — network requests and a slow image operation — before
`win.show()` was ever reached.

## Result

Measured via instrumented timing logs across multiple runs:

| Stage | Before | After |
|---|---|---|
| Window appears (`win.show()` called) | ~14s | ~1.5-1.7s, trending toward ~0.6-0.7s after the thumbnail fix |

## Fix summary

All data loading now happens on `QThreadPool` worker threads, dispatched
only after the window is already shown, using the same `QObject` + `Signal`
task pattern the codebase already used for real thumbnails
(`LoadThumbnailTask`). Loading is staged (visible tab first, then hidden
tab) so the UI fills in step by step rather than everything appearing/
popping in at once.

```
window appears (fast, no network, no slow local work)
  -> column headers set on both tabs (local, instant)
  -> visible tab's rows load (thread)
  -> visible tab's thumbnails load (thread)
  -> hidden tab's rows load (thread)
  -> hidden tab's thumbnails load (thread)
  (in parallel, independently:)
  -> role/permission data loads (thread) -> corner widget + admin button update
  -> styled default-thumbnail placeholder builds (thread) -> swapped in once ready
```

## Files changed

### `state.py`
- `State.__init__` no longer blocks on `_getRolePreference()` (was up to
  8 sequential HTTP calls — 2 per `Role`, 4 roles). Constructs
  `RoleManager` with an empty, least-privilege default instead.
- Added `loadRolePreference()` (fetch only, safe off the main thread) and
  `applyRoleData()` (apply on the main thread). `resetRoleData()`
  unchanged.

### `mainWindow.py`
- Added `LoadColumnsTask`, `LoadEntitiesTask`, `LoadRoleDataTask` —
  background tasks for columns, entity search, and role data.
- `MainWindow.__init__` no longer calls `_rebuildColumns()` /
  `_refresh(True)` synchronously; `QTimer.singleShot(0, self._startInitialLoad)`
  defers all data loading until after the first paint.
- `_onColumnsLoaded` drives `_beginStagedInitialLoad()` /
  `_loadRootStaged()`, sequencing visible-root-first, then hidden-root,
  for both row data and thumbnails.
- `_rebuildColumns()` accepts optional prefetched `dbColumns` /
  `roleOverridesByRoot`, falling back to its old synchronous fetch when
  called with no arguments (`_manageColumns` still works unchanged).
- `DataWidget` gained a `dataLoaded` signal (emitted once
  `_onEntitiesLoaded` finishes applying rows) and now fetches entities via
  `LoadEntitiesTask` instead of calling `ApiClient.searchEntities()`
  directly. `TableWidget`/`TreeWidget`'s old `refreshData()` bodies were
  renamed to `_applyEntities()`, fed already-fetched data.
- `_refreshRoleDependentUi()` updates the corner widget text and Role
  Manager button visibility once real role data lands.
- `DataWidget` now builds its default-thumbnail icon from `Service`'s
  cheap fallback immediately, and subscribes to
  `Service.defaultThumbnailChanged` to swap in the real styled version
  once it's built off-thread.

### `service.py`
- `Service` is now a `QObject` (needed for `defaultThumbnailChanged`
  signal).
- `Service.__init__` no longer builds the styled default thumbnail
  synchronously - that took ~0.7-0.9s (mostly the
  `QImage(':/default_dark_128.png')` resource load; the per-pixel
  darkening loop itself was a smaller ~0.12s contributor, fixed
  separately via a single `QPainter` composition instead of ~9,200
  `pixel()`/`setPixel()` calls). A trivial flat-color placeholder is used
  instead, immediately.
- Added `LoadDefaultThumbnailTask`, which builds the real styled
  thumbnail off the main thread; `Service` swaps it in via
  `defaultThumbnailChanged` once ready.

### `launch.py`
- **No changes required** - `win.show()` was already called immediately
  after `MainWindow(...)` construction.

## Known follow-ups / open questions

- `CentralClient.preference()` is assumed to be a plain synchronous
  `requests`-based call (like `ApiClient`), based on codebase
  conventions - never confirmed against `centralClient.py`, which wasn't
  available during this change. Worth a read-through before merging.
- The manual **Refresh** button, **Column Manager**, and **CSV import**
  still use the original `_refresh()` path (both roots in parallel, not
  staged) - left as-is since those are user-triggered actions after the
  app is already up. Same `_loadRootStaged` pattern could be applied
  there if desired.
- The root cause of the `QImage(':/default_dark_128.png')` load itself
  being ~0.7s+ was never fully isolated (resource decode vs. something
  else in Qt's resource system) - sidestepped via async loading instead
  of fixed at the source. Worth a follow-up if that resource is reused
  elsewhere and could benefit from being fixed properly.
- Any timing-instrumented file variants (`*_timed.py`, `*_timed2.py`)
  used during investigation should **not** be merged - they were
  diagnostic only.
