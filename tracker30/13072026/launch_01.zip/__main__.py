# Copyright © 2025 Polygon Pictures Inc. All rights reserved.

import sys
from logging import DEBUG, INFO


if __name__ == '__main__':
    debug = '--debug' in sys.argv
    if '--window' in sys.argv:
        from .launch import launch

        sys.exit(launch())

    from ppilib.utils.logging import initializeLogging

    from .cli import cli

    initializeLogging(DEBUG if debug else INFO)
    cli(sys.argv[1:])
