# PPITRACKER-48: Show MainWindow before fetching data

## Problem

Launching PPI Breakdown took ~14s before the window appeared, because both
`State.__init__` and `MainWindow.__init__` made several blocking network
calls before `win.show()` was ever reached:

- `State.__init__` fetched role preference data synchronously
  (`_getRolePreference()` — up to 2 HTTP calls per `Role`, 4 roles = up to
  8 sequential calls).
- `MainWindow.__init__` called `self._rebuildColumns()`
  (`ApiClient.getColumns()`) and `self._refresh(True)`
  (`ApiClient.searchEntities()` x2, one per root) synchronously, before
  returning.

Timed with instrumented `launch.py`: window appearance went from **~14s**
to **~1.5s** after this change (see attached console log).

## Fix

Data loading (columns, entities, role preferences, thumbnails) now happens
on `QThreadPool` worker threads, dispatched only after the window has
already been shown — using the same `QObject` + `Signal` task pattern the
codebase already used for thumbnails (`LoadThumbnailTask`).

Sequencing on startup is staged rather than firing everything in parallel,
so the UI fills in step by step instead of popping in all at once:

```
window appears (~1.5s)
  -> column headers set on both tabs (local, instant)
  -> visible tab's rows load
  -> visible tab's thumbnails load
  -> hidden tab's rows load
  -> hidden tab's thumbnails load
(role data / corner widget + admin button load in parallel, independent of the above)
```

## Files changed

### `mainWindow.py`
- Added `LoadColumnsTask`, `LoadEntitiesTask`, `LoadRoleDataTask` —
  background tasks mirroring the existing `LoadThumbnailTask` pattern.
- `MainWindow.__init__` no longer calls `_rebuildColumns()` /
  `_refresh(True)` synchronously. Instead:
  `QTimer.singleShot(0, self._startInitialLoad)` defers loading until
  after the first paint; `_startInitialLoad` kicks off the columns task
  and the role-data task in parallel.
- `_onColumnsLoaded` now drives `_beginStagedInitialLoad()` /
  `_loadRootStaged()`, which sequences visible-root-first, then
  hidden-root, for both row data and thumbnails.
- `_rebuildColumns()` now accepts optional prefetched `dbColumns` /
  `roleOverridesByRoot`, falling back to its old synchronous fetch when
  called with no arguments (used by `_manageColumns`, unchanged
  behavior there).
- `DataWidget` gained a `dataLoaded` signal, emitted once
  `_onEntitiesLoaded` finishes applying rows, and its own
  `refreshData()`/`_onEntitiesLoaded()` now fetch via `LoadEntitiesTask`
  instead of calling `ApiClient.searchEntities()` directly. Old
  `TableWidget.refreshData()` / `TreeWidget.refreshData()` bodies were
  renamed to `_applyEntities()`, now fed already-fetched data instead of
  fetching it themselves.
- `_refreshRoleDependentUi()` added — updates the corner widget text and
  Role Manager button visibility once real role data lands (previously
  computed once, synchronously, in `_genaratedMenu()`).

### `state.py`
- `State.__init__` no longer blocks on `_getRolePreference()`. It now
  constructs `RoleManager` with an empty (least-privilege) role
  assignment, so every user starts as `Role.Artist` until real data
  loads — a safe default rather than defaulting to Admin.
- Added `loadRolePreference()` (fetch only, safe off the main thread)
  and `applyRoleData()` (apply on the main thread). `resetRoleData()`
  is unchanged.

### `launch.py`
- **No changes required.** `win.show()` was already called immediately
  after `MainWindow(...)` construction; once construction itself stopped
  blocking, this file didn't need to change. (A temporary
  `launch_timed.py` variant with `print()`/timing instrumentation was
  used to verify the fix — that instrumentation should **not** be merged;
  discard it or strip it back down to the original `launch.py`.)

## Known follow-ups / open questions

- `CentralClient.preference()` is assumed to be a plain synchronous
  `requests`-based call (like `ApiClient`), based on codebase
  conventions — this was never confirmed against `centralClient.py`
  since that file wasn't available during this change. Worth a quick
  read-through before merging, in case it does anything thread-unsafe.
- The manual **Refresh** button, **Column Manager** dialog close, and
  **CSV import** still use the original `_refresh()` path, which loads
  both roots in parallel (not staged). This was left as-is since those
  are user-triggered actions after the app is already up, where raw
  speed matters more than staged reveal — but the same `_loadRootStaged`
  pattern could be applied there if desired.
- `Service.__init__` (`PhaseStructure`, `SQLiteRepository` construction)
  and the per-pixel default-thumbnail generation still run synchronously
  inside `MainWindow.__init__` (~0.9s per the last timing log). Not
  addressed here since it's a small fraction of the original 14s and
  outside this ticket's stated scope, but flagged in case it's worth a
  follow-up ticket.
