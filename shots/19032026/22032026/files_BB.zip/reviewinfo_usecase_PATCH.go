// ============================================================
// FILE: usecase/reviewinfo.go
// Replace ONLY the ListShotsPivot function body with this.
// ============================================================

func (u *ReviewInfo) ListShotsPivot(ctx context.Context, p ListShotsPivotParams) (*ListShotsPivotResult, error) {
	if p.Project == "" {
		return nil, fmt.Errorf("project is required")
	}
	if p.PerPage <= 0 {
		p.PerPage = 15
	}
	if p.Page <= 0 {
		p.Page = 1
	}

	// normalize dir
	dir := strings.ToUpper(strings.TrimSpace(p.Direction))
	if dir != "ASC" && dir != "DESC" {
		dir = "ASC"
	}

	limit := p.PerPage
	offset := (p.Page - 1) * p.PerPage

	shots, total, err := u.repo.ListShotsPivot(
		ctx,
		p.Project,
		p.OrderKey,
		strings.ToLower(dir),
		limit,
		offset,
		p.ShotNameKey,      // ← search
		p.ApprovalStatuses, // ← approval filter
		p.WorkStatuses,     // ← work filter
	)
	if err != nil {
		return nil, err
	}

	pageLast := int((int64(total) + int64(p.PerPage) - 1) / int64(p.PerPage))

	return &ListShotsPivotResult{
		Shots:    shots,
		Total:    int64(total),
		Page:     p.Page,
		PerPage:  p.PerPage,
		PageLast: pageLast,
		HasNext:  offset+limit < int(total),
		HasPrev:  p.Page > 1,
		Sort:     p.OrderKey,
		Dir:      strings.ToLower(dir),
	}, nil
}
