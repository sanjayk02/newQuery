// ============================================================
// FILE: repository/reviewInfo.go  — SHOTS PIVOT SECTION
// Replace the 3 functions below in your existing file.
// ============================================================

func (r *ReviewInfo) CountShotSubmissions(
	ctx context.Context,
	project string,
	approvalStatuses []string,
	workStatuses []string,
) (int64, error) {

	statusWhere, statusArgs := buildPhaseAwareStatusWhere("", approvalStatuses, workStatuses)

	query := `
WITH latest_phase AS (
  SELECT *,
    ROW_NUMBER() OVER (
      PARTITION BY project, root, group_1, group_2, group_3, relation, component, phase
      ORDER BY modified_at_utc DESC
    ) rn
  FROM t_review_info
  WHERE project = ? AND root='shots' AND deleted=0
),
filtered AS (
  SELECT * FROM latest_phase WHERE rn=1` + statusWhere + `
)
SELECT COUNT(*) FROM (
  SELECT group_1, group_2, group_3, relation, component
  FROM filtered
  GROUP BY group_1, group_2, group_3, relation, component
) x;
`

	args := []any{project}
	args = append(args, statusArgs...)

	var total int64
	err := r.db.WithContext(ctx).Raw(query, args...).Scan(&total).Error
	return total, err
}

func (r *ReviewInfo) ListLatestShotsDynamic(
	ctx context.Context,
	project, orderKey, direction string,
	limit, offset int,
	approvalStatuses []string,
	workStatuses []string,
) ([]shotKeyRow, error) {

	aggSQL := buildPhaseAggregationSQL()
	orderClause := buildShotOrderClause("", orderKey, direction)
	statusWhere, statusArgs := buildPhaseAwareStatusWhere("", approvalStatuses, workStatuses)

	query := `
WITH latest_phase AS (
  SELECT *,
    ROW_NUMBER() OVER (
      PARTITION BY project, root, group_1, group_2, group_3, relation, component, phase
      ORDER BY modified_at_utc DESC
    ) rn
  FROM t_review_info
  WHERE project = ? AND root='shots' AND deleted=0
),
filtered AS (
  SELECT * FROM latest_phase WHERE rn=1` + statusWhere + `
),
aggregated AS (
  SELECT
    project,
    root,
    group_1,
    group_2,
    group_3,
    relation,
    COALESCE(component,'') AS component,
    ` + aggSQL + `
  FROM filtered
  GROUP BY project, root, group_1, group_2, group_3, relation, component
)
SELECT project, root, group_1, group_2, group_3, relation, component
FROM aggregated
ORDER BY ` + orderClause + `
LIMIT ? OFFSET ?
`

	args := []any{project}
	args = append(args, statusArgs...)
	args = append(args, limit, offset)

	var rows []shotKeyRow
	err := r.db.WithContext(ctx).
		Raw(query, args...).
		Scan(&rows).Error

	return rows, err
}

func (r *ReviewInfo) ListShotsPivot(
	ctx context.Context,
	project, orderKey, direction string,
	limit, offset int,
	approvalStatuses []string,
	workStatuses []string,
) ([]ShotPivot, int64, error) {

	total, err := r.CountShotSubmissions(ctx, project, approvalStatuses, workStatuses)
	if err != nil {
		return nil, 0, err
	}

	keys, err := r.ListLatestShotsDynamic(ctx, project, orderKey, direction, limit, offset, approvalStatuses, workStatuses)
	if err != nil {
		return nil, 0, err
	}

	if len(keys) == 0 {
		return []ShotPivot{}, total, nil
	}

	var sb strings.Builder
	var args []any

	sb.WriteString(`
SELECT
  project, root,
  group_1, group_2, group_3,
  relation, component,
  phase, work_status, approval_status,
  submitted_at_utc,
  RIGHT(take,4) AS take
FROM t_review_info
WHERE project=? AND root='shots' AND deleted=0 AND (
`)
	args = append(args, project)

	for i, k := range keys {
		if i > 0 {
			sb.WriteString(" OR ")
		}
		sb.WriteString("(group_1=? AND group_2=? AND group_3=? AND relation=? AND COALESCE(component,'')=?)")
		args = append(args, k.Group1, k.Group2, k.Group3, k.Relation, k.Component)
	}

	sb.WriteString(")")

	var rows []shotPhaseRow
	if err := r.db.WithContext(ctx).
		Raw(sb.String(), args...).
		Scan(&rows).Error; err != nil {
		return nil, 0, err
	}

	type key struct {
		p, r, g1, g2, g3, rel, comp string
	}

	m := map[key]*ShotPivot{}
	order := []*ShotPivot{}

	for _, k := range keys {
		id := key{k.Project, k.Root, k.Group1, k.Group2, k.Group3, k.Relation, k.Component}

		sp := &ShotPivot{
			Project:   k.Project,
			Root:      k.Root,
			Group1:    k.Group1,
			Group2:    k.Group2,
			Group3:    k.Group3,
			Relation:  k.Relation,
			Component: k.Component,
			Phases:    map[string]PhaseData{},
		}

		m[id] = sp
		order = append(order, sp)
	}

	for _, r := range rows {
		id := key{r.Project, r.Root, r.Group1, r.Group2, r.Group3, r.Relation, getStr(r.Component)}

		if sp, ok := m[id]; ok {
			sp.Phases[strings.ToLower(r.Phase)] = PhaseData{
				WorkStatus:     r.WorkStatus,
				ApprovalStatus: r.ApprovalStatus,
				SubmittedAtUTC: r.SubmittedAtUTC,
				Take:           r.Take,
			}
		}
	}

	final := make([]ShotPivot, len(order))
	for i, v := range order {
		final[i] = *v
	}

	return final, total, nil
}
