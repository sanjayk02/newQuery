package repository

import (
	"context"

	"github.com/PolygonPictures/central30-web/front/entity"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type PublishOperationInfo struct {
	db *mongo.Database
}

func NewPublishOperationInfo(db *mongo.Database) *PublishOperationInfo {
	return &PublishOperationInfo{db: db}
}

func (poi *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	param *entity.LatestAssetComponentParams,
) (documents []*entity.LatestComponentDocuments, err error) {
	col := poi.db.Collection("pc_publishOperationInfo")

	matchStage := bson.D{
		{"$match", bson.D{
			{"_central.project", param.Project},
			{"root", "assets"},
			{"groups.0", param.Asset},
			{"relation", param.Relation},
			{"component", bson.D{{"$in", param.Component}}},
		}},
	}
	projectStage := bson.D{
		{"$project", bson.D{
			{"id", 1}, {"groups", 1}, {"submitted_at_utc", 1},
			{"phase", 1}, {"component", 1}, {"_id", 0},
		}},
	}
	sortStage    := bson.D{{"$sort", bson.D{{"submitted_at_utc", -1}}}}
	groupStage   := bson.D{
		{"$group", bson.D{
			{"_id", "$component"},
			{"latest_document", bson.D{{"$first", "$$ROOT"}}},
		}},
	}

	pipeline := mongo.Pipeline{matchStage, projectStage, sortStage, groupStage}
	cursor, err := col.Aggregate(ctx, pipeline)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)
	if err = cursor.All(ctx, &documents); err != nil {
		return
	}
	if documents == nil {
		documents = []*entity.LatestComponentDocuments{}
	}
	return
}

// ListShots retrieves shots from MongoDB.
// filteredShots — when non-nil, restricts results to only those shots
// (pre-filtered by MySQL status query in the usecase layer).
func (poi *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
	filteredShots []*entity.ShotDocument,
) (documents []*entity.ShotDocument, total int64, err error) {
	col := poi.db.Collection("pc_publishOperationInfo")

	//-----------------------------------
	// Build base filter
	//-----------------------------------
	filter := bson.D{
		{"_central.project", params.Project},
		{"root", "shots"},
	}

	// Text search across all 3 group levels
	if params.Search != nil && *params.Search != "" {
		search := *params.Search
		filter = append(filter, bson.E{
			Key: "$or",
			Value: bson.A{
				bson.D{{"groups.0", bson.D{{"$regex", search}, {"$options", "i"}}}},
				bson.D{{"groups.1", bson.D{{"$regex", search}, {"$options", "i"}}}},
				bson.D{{"groups.2", bson.D{{"$regex", search}, {"$options", "i"}}}},
			},
		})
	}

	// Status-filtered shots from MySQL — restrict to only these (groups, relation) pairs
	if len(filteredShots) > 0 {
		var orFilters bson.A
		for _, shot := range filteredShots {
			orFilters = append(orFilters, bson.D{
				{"groups.0", shot.Groups[0]},
				{"groups.1", shot.Groups[1]},
				{"groups.2", shot.Groups[2]},
				{"relation", shot.Relation},
			})
		}
		filter = append(filter, bson.E{Key: "$or", Value: orFilters})
	}

	pipeline := mongo.Pipeline{}

	// 1. Match
	pipeline = append(pipeline, bson.D{{"$match", filter}})

	// 2. Group unique shots (groups + relation)
	pipeline = append(pipeline, bson.D{
		{"$group", bson.D{
			{"_id", bson.D{
				{"groups", "$groups"},
				{"relation", "$relation"},
			}},
		}},
	})

	// 3. Sort
	pipeline = append(pipeline, bson.D{
		{"$sort", bson.D{{"_id.groups", 1}}},
	})

	// 4. Paginate via $facet
	offset := (params.GetPage() - 1) * params.GetPerPage()
	if offset < 0 {
		offset = 0
	}
	pipeline = append(pipeline, bson.D{
		{"$facet", bson.D{
			{"total", bson.A{
				bson.D{{"$count", "totalCount"}},
			}},
			{"documents", bson.A{
				bson.D{{"$skip", offset}},
				bson.D{{"$limit", params.GetPerPage()}},
				bson.D{{"$project", bson.D{
					{"_id", 0},
					{"groups", "$_id.groups"},
					{"relation", "$_id.relation"},
				}}},
			}},
		}},
	})

	opts := options.Aggregate().SetAllowDiskUse(true)
	cursor, err := col.Aggregate(ctx, pipeline, opts)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)

	var result struct {
		Total []struct {
			TotalCount int64 `bson:"totalCount"`
		} `bson:"total"`
		Documents []*entity.ShotDocument `bson:"documents"`
	}
	if cursor.Next(ctx) {
		if err = cursor.Decode(&result); err != nil {
			return
		}
	}
	if len(result.Total) > 0 {
		total = result.Total[0].TotalCount
	}
	documents = result.Documents
	if documents == nil {
		documents = []*entity.ShotDocument{}
	}
	return
}

func (poi *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	param *entity.LatestShotComponentParams,
) (documents []*entity.LatestComponentDocuments, err error) {
	col := poi.db.Collection("pc_publishOperationInfo")

	matchStage := bson.D{
		{"$match", bson.D{
			{"_central.project", param.Project},
			{"root", "shots"},
			{"groups.0", param.Group1},
			{"groups.1", param.Group2},
			{"groups.2", param.Group3},
			{"relation", param.Relation},
			{"component", bson.D{{"$in", param.Component}}},
		}},
	}
	projectStage := bson.D{
		{"$project", bson.D{
			{"id", 1}, {"groups", 1}, {"submitted_at_utc", 1},
			{"phase", 1}, {"component", 1}, {"_id", 0},
		}},
	}
	sortStage  := bson.D{{"$sort", bson.D{{"submitted_at_utc", -1}}}}
	groupStage := bson.D{
		{"$group", bson.D{
			{"_id", "$component"},
			{"latest_document", bson.D{{"$first", "$$ROOT"}}},
		}},
	}

	pipeline := mongo.Pipeline{matchStage, projectStage, sortStage, groupStage}
	cursor, err := col.Aggregate(ctx, pipeline)
	if err != nil {
		return
	}
	defer cursor.Close(ctx)
	if err = cursor.All(ctx, &documents); err != nil {
		return
	}
	if documents == nil {
		documents = []*entity.LatestComponentDocuments{}
	}
	return
}
