package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PublishOperationInfo struct {
	repo        *repository.PublishOperationInfo
	readTimeout time.Duration
	reviewRepo  *repository.ReviewInfo
	mysqlDB     *gorm.DB
}

func NewPublishOperationInfo(
	repo *repository.PublishOperationInfo,
	readTimeout time.Duration,
	reviewRepo *repository.ReviewInfo,
	mysqlDB *gorm.DB,
) *PublishOperationInfo {
	return &PublishOperationInfo{
		repo:        repo,
		readTimeout: readTimeout,
		reviewRepo:  reviewRepo,
		mysqlDB:     mysqlDB,
	}
}

func (uc *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	params *entity.LatestAssetComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestAssetDocuments(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) ([]*entity.ShotDocument, int64, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()

	// Status filters live in MySQL (t_review_info), not MongoDB.
	// When filters are set, query MySQL first to get matching shots,
	// then pass them to MongoDB as an allowlist.
	var filteredShots []*entity.ShotDocument

	if len(params.ApprovalStatus) > 0 || len(params.WorkStatus) > 0 {
		var err error
		filteredShots, err = uc.reviewRepo.ListFilteredShots(
			uc.mysqlDB,
			params.Project,
			params.ApprovalStatus,
			params.WorkStatus,
		)
		if err != nil {
			return nil, 0, err
		}
		// No shots matched the status filter — return empty immediately
		if len(filteredShots) == 0 {
			return []*entity.ShotDocument{}, 0, nil
		}
	}

	return uc.repo.ListShots(timeoutCtx, params, filteredShots)
}

func (uc *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	params *entity.LatestShotComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestShotDocuments(timeoutCtx, params)
}
