package usecase

import (
	"context"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
)

type PublishOperationInfo struct {
	repo        *repository.PublishOperationInfo
	readTimeout time.Duration
	reviewRepo  *repository.ReviewInfo
	mysqlDB     *gorm.DB
}

func NewPublishOperationInfo(
	repo *repository.PublishOperationInfo,
	readTimeout time.Duration,
	reviewRepo *repository.ReviewInfo,
	mysqlDB *gorm.DB,
) *PublishOperationInfo {
	return &PublishOperationInfo{
		repo:        repo,
		readTimeout: readTimeout,
		reviewRepo:  reviewRepo,
		mysqlDB:     mysqlDB,
	}
}

func (uc *PublishOperationInfo) ListLatestAssetDocuments(
	ctx context.Context,
	params *entity.LatestAssetComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestAssetDocuments(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListShots(
	ctx context.Context,
	params *entity.ShotListParams,
) ([]*entity.ShotDocument, int64, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, 0, err
	}

	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()

	// When status filters are active, MySQL (t_review_info) is the
	// authoritative source. Query MySQL with pagination directly —
	// this avoids passing a huge $or list to MongoDB which causes timeouts.
	if len(params.ApprovalStatus) > 0 || len(params.WorkStatus) > 0 {
		return uc.reviewRepo.ListFilteredShotsPaginated(
			uc.mysqlDB,
			params.Project,
			params.ApprovalStatus,
			params.WorkStatus,
			params.Search,
			params.GetPage(),
			params.GetPerPage(),
		)
	}

	// No status filters — query MongoDB as normal (handles search + pagination)
	return uc.repo.ListShots(timeoutCtx, params)
}

func (uc *PublishOperationInfo) ListLatestShotDocuments(
	ctx context.Context,
	params *entity.LatestShotComponentParams,
) ([]*entity.LatestComponentDocuments, error) {
	if err := binding.Validator.ValidateStruct(params); err != nil {
		return nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(ctx, uc.readTimeout)
	defer cancel()
	return uc.repo.ListLatestShotDocuments(timeoutCtx, params)
}
