package repository

import (
	"strings"

	"github.com/PolygonPictures/central30-web/front/entity"
	"gorm.io/gorm"
)

// ListFilteredShotsPaginated queries MySQL to find unique shots matching
// the given status filters, with search and pagination applied.
// This is called instead of MongoDB when status filters are active,
// avoiding the expensive $or array that caused 504 timeouts.
func (r *ReviewInfo) ListFilteredShotsPaginated(
	db *gorm.DB,
	project string,
	approvalStatus []string,
	workStatus []string,
	search *string,
	page int,
	perPage int,
) ([]*entity.ShotDocument, int64, error) {

	base := db.Model(&model.ReviewInfo{}).
		Where("project = ?", project).
		Where("root = ?", "shots").
		Where("deleted = 0")

	if len(approvalStatus) > 0 {
		base = base.Where("approval_status IN ?", approvalStatus)
	}
	if len(workStatus) > 0 {
		base = base.Where("work_status IN ?", workStatus)
	}
	if search != nil && strings.TrimSpace(*search) != "" {
		s := strings.TrimSpace(*search) + "%"  // starts-with, not contains
		base = base.Where(
			"group_1 LIKE ? OR group_2 LIKE ? OR group_3 LIKE ?",
			s, s, s,
		)
	}

	// Count total unique shots matching the filter
	type uniqueShot struct {
		Group1   string `gorm:"column:group_1"`
		Group2   string `gorm:"column:group_2"`
		Group3   string `gorm:"column:group_3"`
		Relation string `gorm:"column:relation"`
	}

	var rows []uniqueShot
	if err := base.
		Select("group_1, group_2, group_3, relation").
		Group("group_1, group_2, group_3, relation").
		Order("group_1 ASC, group_2 ASC, group_3 ASC").
		Scan(&rows).Error; err != nil {
		return nil, 0, err
	}

	total := int64(len(rows))

	// Apply pagination in Go (simple slice) since GROUP BY + COUNT is already done
	offset := (page - 1) * perPage
	if offset >= len(rows) {
		return []*entity.ShotDocument{}, total, nil
	}
	end := offset + perPage
	if end > len(rows) {
		end = len(rows)
	}
	rows = rows[offset:end]

	shots := make([]*entity.ShotDocument, len(rows))
	for i, row := range rows {
		shots[i] = &entity.ShotDocument{
			Groups:   []string{row.Group1, row.Group2, row.Group3},
			Relation: row.Relation,
		}
	}
	return shots, total, nil
}
