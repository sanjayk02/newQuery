import { Fab } from '@material-ui/core';
import { styled } from '@material-ui/core/styles';
import { GetApp } from '@material-ui/icons';
import React from 'react';

const StyledFab = styled(Fab)(({ theme }) => ({
  position: 'absolute',
  bottom: theme.spacing(2),
  right: theme.spacing(2),
}));

type DownloadFabProps = {
  onClick: () => void,
  disabled?: boolean,
};

const DownloadFab = React.memo<DownloadFabProps>(({ onClick, disabled }) => {
  return (
    <StyledFab
      color="primary"
      size="medium"
      aria-label="download CSV"
      onClick={onClick}
      disabled={disabled}
    >
      <GetApp />
    </StyledFab>
  );
});

export default DownloadFab;
