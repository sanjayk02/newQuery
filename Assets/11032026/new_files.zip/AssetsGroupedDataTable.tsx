import React, { useCallback, useMemo, useState } from "react";
import {
  Box,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  makeStyles,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import { PivotGroup, SortDir } from "./types";
import { components } from "react-select";

/** ----------------------------------------------------------------
 *  COLORS (match list view look)
 *  ---------------------------------------------------------------- */
const COLORS = {
  PAGE_BG: "#3d3d3dff",
  TABLE_BG: "#3d3d3dff",
  HEADER_BG: "#3d3d3dff",
  HEADER_BORDER: "#3d3d3dff",
  GRID_LINE: "#555555",
  ROW_BG: "#3d3d3dff",
  GROUP_BG: "#3a3838ff",
  GROUP_TEXT: "#00b7ff",
  TEXT: "#e0e0e0",
  MUTED: "#bdbdbd",

  // top/bottom edge line for NON-phase columns
  COL_EDGE: "#6b6b6b",

  // ✅ use your phase config (lineColor + backgroundColor)
  PHASE: {
    mdl: { lineColor: "#3295fd", backgroundColor: "#354d68" },
    rig: { lineColor: "#c061fd", backgroundColor: "#5e3568" },
    bld: { lineColor: "#fc2f8c", backgroundColor: "#5a0028" },
    dsn: { lineColor: "#98f2bf", backgroundColor: "#045660" },
    ldv: { lineColor: "#fe5cff", backgroundColor: "#683566" },
  },
};

/** ----------------------------------------------------------------
 *  UI controls - REDUCED FOR COMPACTNESS
 *  ---------------------------------------------------------------- */
const UI = {
  ROW_HEIGHT: 54, // Reduced from 54
  ROW_PAD_Y: 2,
  ROW_PAD_X: 2, // Reduced from 8

  // ✅ move NAME + THUMB a bit left
  NAME_PAD_X: 2, // Reduced from 4
  THUMB_PAD_X: 4, // Reduced from 6

  ROW_GAP_PX: 0,
  GROUP_ROW_GAP_PX: 0,
  PHASE_GAP_PX: 0,

  RAIL_PX: 3, // Reduced from 3

  THUMB_WIDTH: 50, // Reduced from 90
  NAME_WIDTH: 90, // Reduced from 150
  RELATION_WIDTH: 50, // Reduced from 70
  PHASE_COL_WIDTH: 85, // Reduced from 97 - KEY REDUCTION

  // ✅ "top & bottom line" thickness in header
  COL_EDGE_PX: 3, // Reduced from 2

  // ✅ thumbs width/height
  THUMB_BOX_W: 75, // Reduced from 50
  THUMB_BOX_H: 54, // Reduced from 28
  THUMB_RADIUS: 2,
  
  // ✅ Font sizes matching your image
  FONT_SIZE_HEADER: 12,    // Column headers
  FONT_SIZE_CONTENT: 13,   // Content text
  FONT_SIZE_GROUP: 13,     // Group header text
};

// Column IDs are dynamic (driven by phaseComponents config), so we use a plain string
// rather than a fixed union type that would need updating per project.
type ColumnId = string;

type Column = {
  id: ColumnId;
  label: string;
  sortable?: boolean;
  phase?: keyof typeof COLORS.PHASE; // mdl|rig|bld|dsn|ldv
  kind?: "work" | "appr" | "submitted" | "take";
  isComponent?: boolean; // true for dynamic component columns (mdlRend, bldAnm, etc.)
  headerMode?: "phaseKind" | "label";
};

const getSortValue = (
  asset: any,
  key: string,
  latestComponents?: Record<string, any>
) => {

  /* ----------------------------------------
     TAKE columns (numeric)
  ---------------------------------------- */
  const takeMatch = key.match(/^(mdl|rig|bld|dsn|ldv)_take$/i);

  if (takeMatch) {
    const val = asset[key];
    return val ? parseInt(String(val).replace(/\D/g, ""), 10) : 0;
  }


  /* ----------------------------------------
     Phase Submitted columns
     mdl_submitted, rig_submitted etc
  ---------------------------------------- */
  if (key.endsWith("_submitted")) {
    const date = new Date(asset[key + "_at_utc"] || asset[key]);
    return isNaN(date.getTime()) ? 0 : date.getTime();
  }


  /* ----------------------------------------
     Dynamic Component Submitted columns
     mdlRend, bldAnm, bldRend, dsnImg etc
  ---------------------------------------- */
  if (latestComponents) {

    const cleanRelation = (asset.relation || "")
      .toString()
      .trim()
      .replace(/^_+|_+$/g, "");

    const assetKey = `${asset.group_1}-${cleanRelation}`;

    const componentList = latestComponents && latestComponents[assetKey] || [];

    const componentData =
      componentList.find((item: any) => item.component === key) ||
      componentList.find(
        (item: any) =>
          item.component &&
          item.component.toLowerCase() === key.toLowerCase()
      );

    if (
      componentData && 
      componentData.latest_document && 
      componentData.latest_document.submitted_at_utc) {

      const date = new Date(
        componentData.latest_document.submitted_at_utc
      );

      return isNaN(date.getTime()) ? 0 : date.getTime();
    }
  }


  /* ----------------------------------------
     Default fallback
  ---------------------------------------- */
  return asset[key] || "";
};


type Props = {
  groups?: PivotGroup[];

  // sorting
  sortKey: string;
  sortDir: SortDir;
  onSortChange: (key: string) => void;

  // group name sorting
  groupSortDir?: SortDir;
  onGroupSortToggle?: () => void;

  dateTimeFormat: Intl.DateTimeFormat;
  hiddenColumns?: Set<string>;

  /** ✅ IMPORTANT: pass footer from Panel so it renders (sticky) */
  tableFooter?: React.ReactNode;

  latestComponents?: any;

  /**
   * Pipeline phase component configuration for the current project.
   * Drives which component columns appear in the table.
   * e.g. { mdl: ['mdlRend', 'mdlAnm'], bld: ['bldAnm', 'bldRend'] }
   */
  phaseComponents?: { [phase: string]: string[] };
};

/**
 * Returns the dynamic component columns for a given phase, based on the
 * project's pipeline configuration. Mirrors the pattern in AssetsDataTable.tsx.
 */
function buildComponentColumns(
  phase: keyof typeof COLORS.PHASE,
  phaseComponents: { [phase: string]: string[] } | undefined,
): Column[] {
  const componentIds = (phaseComponents && phaseComponents[phase]) || [];
  return componentIds.map((id) => ({
    id,
    label: `${id.toUpperCase()} Submitted`,
    sortable: true,
    phase,
    isComponent: true,
    headerMode: "label" as const,
  }));
}

/**
 * Builds the full column list. Fixed columns are declared explicitly;
 * only per-phase component columns are dynamic via buildComponentColumns().
 */
function buildColumns(phaseComponents: { [phase: string]: string[] } | undefined): Column[] {
  return [
    { id: "thumbnail",    label: "THUMB" },
    { id: "group_1_name", label: "NAME", sortable: true },

    // MDL Phase
    { id: "mdl_work", label: "MDL Work", sortable: true, phase: "mdl" as const, kind: "work" as const },
    { id: "mdl_appr", label: "MDL Appr", sortable: true, phase: "mdl" as const, kind: "appr" as const },
    { id: "mdl_take", label: "MDL TAKE", sortable: true, phase: "mdl" as const, kind: "take" as const },
    ...buildComponentColumns("mdl", phaseComponents),

    // RIG Phase
    { id: "rig_work", label: "RIG Work", sortable: true, phase: "rig" as const, kind: "work" as const },
    { id: "rig_appr", label: "RIG Appr", sortable: true, phase: "rig" as const, kind: "appr" as const },
    { id: "rig_take", label: "RIG TAKE", sortable: true, phase: "rig" as const, kind: "take" as const },
    ...buildComponentColumns("rig", phaseComponents),

    // BLD Phase
    { id: "bld_work", label: "BLD Work", sortable: true, phase: "bld" as const, kind: "work" as const },
    { id: "bld_appr", label: "BLD Appr", sortable: true, phase: "bld" as const, kind: "appr" as const },
    { id: "bld_take", label: "BLD TAKE", sortable: true, phase: "bld" as const, kind: "take" as const },
    ...buildComponentColumns("bld", phaseComponents),

    // DSN Phase
    { id: "dsn_work", label: "DSN Work", sortable: true, phase: "dsn" as const, kind: "work" as const },
    { id: "dsn_appr", label: "DSN Appr", sortable: true, phase: "dsn" as const, kind: "appr" as const },
    { id: "dsn_take", label: "DSN TAKE", sortable: true, phase: "dsn" as const, kind: "take" as const },
    ...buildComponentColumns("dsn", phaseComponents),

    // LDV Phase
    { id: "ldv_work", label: "LDV Work", sortable: true, phase: "ldv" as const, kind: "work" as const },
    { id: "ldv_appr", label: "LDV Appr", sortable: true, phase: "ldv" as const, kind: "appr" as const },
    { id: "ldv_take", label: "LDV TAKE", sortable: true, phase: "ldv" as const, kind: "take" as const },
    ...buildComponentColumns("ldv", phaseComponents),

    { id: "relation", label: "Relation", sortable: true },
  ];
}


const useStyles = makeStyles(() => ({
  root: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    background: COLORS.PAGE_BG,
  },

  // IMPORTANT: do NOT create a nested scroll container in Group view.
  // The parent panel (ListView behavior) should be the only scrolling ancestor.
  scroller: {
    width: "100%",
    whiteSpace: "pre-wrap",
    overflow: "visible",
  },

  // COMPACT TABLE STYLING
  table: {
    background: COLORS.TABLE_BG,
    width: "100%",
    minWidth: "100%",
    tableLayout: "fixed",
    borderCollapse: "separate",
    borderSpacing: 0,
  },

  groupHeader: {
    '&:hover': {
      backgroundColor: `${COLORS.GROUP_BG}dd !important`,
    },
  },
  
  sortIndicator: {
    transition: 'color 0.2s ease-in-out',
  },
  
  activeSort: {
    color: '#00b7ff !important',
  },
}));

/**
 * Utility functions for consistent empty value handling
 */
const isEmptyValue = (value: any): boolean => {
  if (value === null || value === undefined) return true;
  const str = String(value).trim();
  return str === '' || str === '-' || str === '—' || str === 'null' || str === 'undefined';
};

const formatForDisplay = (value: any): string => {
  if (isEmptyValue(value)) return '—';
  return String(value).trim();
};

function getPhaseMetadata(visibleCols: Column[]) {
  const map: Record<string, { start: string; end: string }> = {};
  visibleCols.forEach((col) => {
    if (!col.phase) return;
    if (!map[col.phase]) map[col.phase] = { start: col.id, end: col.id };
    else map[col.phase].end = col.id;
  });
  return map;
}

function formatSubmitted(val: any, dateTimeFormat: Intl.DateTimeFormat) {
  if (isEmptyValue(val)) return '—';

  try {
    const d = new Date(val);
    if (isNaN(d.getTime())) return '—';

    const formatted = dateTimeFormat.format(d);
    

    return formatted.replace('AM', '\nAM').replace('PM', '\nPM'); // Remove AM/PM for compactness
  } catch {
    return '—';
  }
}

function statusColor(status?: string) {
  if (isEmptyValue(status)) return COLORS.MUTED;
  
  const s = (status || "").toLowerCase();
  if (s.includes("approved")) return "#32cd32";
  if (s.includes("review")) return "#ffa500";
  if (s.includes("retake")) return "#ff4f4f";
  if (s.includes("hold")) return "#ffdd55";
  if (s === "check") return "#e221e2";
  return COLORS.MUTED;
}

function renderThumbnail(asset: any) {
  const url = asset.thumbnail_url || asset.thumbnail;
  return (
    <Box display="flex" alignItems="center" justifyContent="flex-start">
      <Box
        style={{
          width: UI.THUMB_BOX_W,
          height: UI.THUMB_BOX_H,
          borderRadius: UI.THUMB_RADIUS,
          backgroundColor: "#2a2a2a",
          overflow: "hidden",
        }}
      >
        {url ? (
          <img
            src={url}
            alt=""
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
          />
        ) : null}
      </Box>
    </Box>
  );
}

// In AssetsGroupedDataTable.tsx, update the renderAssetField function

function renderAssetField(
  asset: any,
  col: Column,
  dateTimeFormat: Intl.DateTimeFormat,
  latestComponents?: Record<string, any>
) {
  {/* THUMBNAIL */}
  if (col.id === "thumbnail") return renderThumbnail(asset);

  {/* GROUP 1 NAME */}
  if (col.id === "group_1_name") {
    return (
      <Typography noWrap style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 500 
      }}>
        {formatForDisplay(asset.group_1 || asset.group_1_name)}
      </Typography>
    );
  }

  {/* RELATION */}
  if (col.id === "relation") {
    return (
      <Typography style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 500 
      }}>
        {formatForDisplay(asset.relation)}
      </Typography>
    );
  }

  {/* Component columns — identified by col.isComponent flag set in buildComponentColumns() */}
  if (col.isComponent) {
    const cleanRelation = (asset.relation || "").toString().trim();
    const assetKey = `${asset.group_1}-${cleanRelation}`;
    const componentList: any[] = (latestComponents && latestComponents[assetKey]) || [];

    // Match by component name directly — works for any project config, no hardcoding needed
    const componentData =
      componentList.find((item: any) => item.component === col.id) ||
      componentList.find((item: any) => item.component && item.component.toLowerCase() === col.id.toLowerCase());

    const submittedAt = (componentData && componentData.latest_document && componentData.latest_document.submitted_at_utc) || null;
    const submittedText = submittedAt ? formatSubmitted(submittedAt, dateTimeFormat) : "—";

    return (
      <Typography
        style={{
          fontSize: UI.FONT_SIZE_CONTENT,
          whiteSpace: "normal",
          lineHeight: 1.2,
        }}
      >
        {submittedText}
      </Typography>
    );
  }

  {/* Phase columns (WORK/APPR/SUBMITTED/TAKE) */}
  if (col.kind === "appr" || col.kind === "work") {
    const field = col.kind === "work" ? "work_status" : "approval_status";
    const raw = col.phase ? asset[col.phase + "_" + field] : undefined;

    if (isEmptyValue(raw)) {
      return <Typography style={{ fontSize: UI.FONT_SIZE_CONTENT }}>—</Typography>;
    }

    const text = String(raw).trim();

    // Split prefix and status at first capital letter
    const match = text.match(/^([a-z]+)([A-Z].*)$/);

    let prefix = "";
    let status = text;

    if (match) {
      prefix = match[1];
      status = match[2];
    }

    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        lineHeight={1}
      >
        {prefix && (
          <Typography
            style={{
              fontSize: UI.FONT_SIZE_CONTENT,
              fontWeight: 400,
              color: "#32cd32", // prefix color (you can change)
            }}
          >
            {prefix}
          </Typography>
        )}

        <Typography
          style={{
            fontSize: UI.FONT_SIZE_CONTENT,
            fontWeight: 400,
            color: statusColor(status),
          }}
        >
          {status}
        </Typography>
      </Box>
    );
  }

  {/* Phase columns (WORK/APPR/SUBMITTED/TAKE) */}
  if (col.kind === "take") {
    const takeValue = col.phase ? asset[col.phase + "_take"] : undefined;
    let takeText = '—';
    
    if (!isEmptyValue(takeValue)) {
      const rawTake = String(takeValue).trim();
      takeText = rawTake.slice(-4); // Last 4 characters as fallback
    }
    
    return (
      <Typography style={{ 
        fontSize: UI.FONT_SIZE_CONTENT, 
        fontWeight: 400
      }}>
        {takeText}
      </Typography>
    );
  }

}

/*
======================================================================================
  CELL STYLING LOGIC ==
  - Handles header vs content styling
  - Handles phase column styling with rails and background colors
  - Handles edge cases for first/last columns and phase start/end
======================================================================================
*/
function buildCellStyle(
  col: Column,
  phaseMeta: Record<string, { start: string; end: string }>,
  opts: { header?: boolean; isGroupRow?: boolean } = {}
): React.CSSProperties {
  const { header = false, isGroupRow = false } = opts;

  const meta          = col.phase ? phaseMeta[col.phase] : null;
  const isPhaseStart  = !!(meta && meta.start === col.id);
  const isPhaseEnd    = !!(meta && meta.end === col.id);

  const phaseCfg      = col.phase ? COLORS.PHASE[col.phase] : null;
  const edgeColor     = col.phase ? phaseCfg!.lineColor : COLORS.COL_EDGE;

  const headerBg      = col.phase ? phaseCfg!.backgroundColor : COLORS.HEADER_BG;

  const paddingX =
    col.id === "group_1_name" ? UI.NAME_PAD_X : col.id === "thumbnail" ? UI.THUMB_PAD_X : UI.ROW_PAD_X;

  const style: React.CSSProperties = {
    backgroundColor: header ? headerBg : COLORS.ROW_BG,
    color: header ? "#fff" : COLORS.TEXT,
    whiteSpace: "normal",
    overflow: "hidden",
    textOverflow: "ellipsis",
    height: UI.ROW_HEIGHT,
    padding: `${header ? 4 : UI.ROW_PAD_Y}px ${paddingX}px`,
    fontSize: header ? UI.FONT_SIZE_HEADER : UI.FONT_SIZE_CONTENT,
    fontWeight: header ? 500 : 300,
    borderLeft: "0px",
    borderRight: "0px",
    borderBottom: header
      ? "1px solid " + COLORS.HEADER_BORDER
      : (isGroupRow ? UI.GROUP_ROW_GAP_PX : UI.ROW_GAP_PX) + "px solid " + COLORS.TABLE_BG,
  };

  // Shadow logic for header top/bottom lines
  const shadows: string[] = [];
  if (header) {
    shadows.push(`inset 0 ${UI.COL_EDGE_PX}px 0 0 ${edgeColor}`);
    // shadows.push(`inset 0 -${UI.COL_EDGE_PX}px 0 0 ${edgeColor}`);
  }

  // Phase rails logic
  if (col.phase) {
    const rail = phaseCfg!.lineColor;
    if (isPhaseStart) shadows.push(`inset ${UI.RAIL_PX}px 0 0 0 ${rail}`);
    if (isPhaseEnd) shadows.push(`inset -${UI.RAIL_PX}px 0 0 0 ${rail}`);

    // Gap after phase end
    if (isPhaseEnd) style.borderRight = `1px solid ${phaseCfg!.lineColor}`;
  } else {
    // Standard column logic
    if (col.id === "thumbnail") {
      style.borderRight = "0px";
    } else if (col.id === "component") {
      // ✅ ADDED: Proper terminal rail border for COMPONENT column
      style.borderRight = `solid ${UI.RAIL_PX}px ${COLORS.COL_EDGE}`; 
      
      // Add top/bottom rail shadow in header to complete the box look
      if (header) {
          shadows.push(`inset -${UI.RAIL_PX}px 0 0 0 ${COLORS.COL_EDGE}`);
      }
    } else {
      style.borderRight = "1px solid " + (header ? COLORS.HEADER_BORDER : COLORS.GRID_LINE);
    }
  }

  if (shadows.length) style.boxShadow = shadows.join(", ");

  return style;
}

const AssetsGroupedDataTable: React.FC<Props> = ({
  groups = [],
  sortKey,
  sortDir,
  onSortChange,
  dateTimeFormat,
  hiddenColumns = new Set(),
  tableFooter,
  latestComponents,
  phaseComponents,
}) => {
  const classes = useStyles();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const toggle = useCallback((key: string) => {
    setCollapsed((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);

  // Build full column list from this project's phase component config
  const ALL_COLUMNS = useMemo(() => buildColumns(phaseComponents), [phaseComponents]);

  /*
  ======================================================================================
  COLUMN VISIBILITY LOGIC ==
  The grouped table uses different column IDs from the list table (e.g. "mdl_work" vs
  "mdl_work_status"), so we map them here. Component columns use their own id directly.
  ======================================================================================
  */
  const isGroupedColHidden = useCallback(
    (groupColId: string, col?: Column) => {
      if (!hiddenColumns || hiddenColumns.size === 0) return false;

      // fixed columns — always visible
      if (groupColId === "thumbnail" || groupColId === "group_1_name") return false;
      if (groupColId === "relation") return hiddenColumns.has("relation");

      // Component columns — id is the component name (e.g. "mdlRend", "bldAnm")
      if (col && col.isComponent) return hiddenColumns.has(groupColId);

      // Phase columns — map grouped IDs to panel storage keys
      const m = groupColId.match(/^(mdl|rig|bld|dsn|ldv)_(work|appr|submitted|take)$/i);
      if (!m) return hiddenColumns.has(groupColId);

      const phase = m[1].toLowerCase();
      const kind  = m[2].toLowerCase();

      if (kind === "work") return hiddenColumns.has(`${phase}_work_status`);
      if (kind === "appr") return hiddenColumns.has(`${phase}_approval_status`);
      if (kind === "take") return hiddenColumns.has(`${phase}_take`);
      return hiddenColumns.has(`${phase}_submitted_at`);
    },
    [hiddenColumns],
  );

  const visibleColumns = useMemo(() => {
    return ALL_COLUMNS.filter((c) => !isGroupedColHidden(c.id, c));
  }, [ALL_COLUMNS, isGroupedColHidden]);

  const phaseMeta = useMemo(() => getPhaseMetadata(visibleColumns), [visibleColumns]);

  return (
    <Box className={classes.root}>
      <Box className={classes.scroller}>
        <Table size="small" stickyHeader className={classes.table}>
          {/* fixed column widths - COMPACT SIZES */}
          <colgroup>
            {visibleColumns.map((col) => {
              let w = UI.PHASE_COL_WIDTH;
              if (col.id === "thumbnail") w = UI.THUMB_WIDTH;
              if (col.id === "group_1_name") w = UI.NAME_WIDTH;
              if (col.id === "relation") w = UI.RELATION_WIDTH;
              // if (col.id === "component") w = UI.COMPONENT_WIDTH;

              // set specific widths for phase columns
              if (col.kind === 'appr') w = UI.PHASE_COL_WIDTH;
              if (col.kind === 'work') w = UI.PHASE_COL_WIDTH;
              // if (col.kind === 'submitted') w = UI.PHASE_COL_WIDTH;
              if (col.kind === 'take') w = UI.PHASE_COL_WIDTH;

              // return col element
              return <col key={col.id} style={{ width: w }} />;
            })}
          </colgroup>

          <TableHead>
            <TableRow>
              {visibleColumns.map((col) => (
                <TableCell
                  key={col.id}
                  align={col.id === "group_1_name" || col.id === "thumbnail" ? "left" : "center"}
                  onClick={() => col.sortable && onSortChange(col.id)}
                  style={{
                    ...buildCellStyle(col, phaseMeta, { header: true }),
                    whiteSpace: "pre-wrap",
                    cursor: col.sortable ? "pointer" : "default",
                    zIndex: 5,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    alignItems={col.id === "group_1_name" || col.id === "thumbnail" ? "flex-start" : "center"}
                  >
                    <Typography style={{ 
                      fontSize: UI.FONT_SIZE_HEADER, 
                      fontWeight: 500,
                      lineHeight: 1,
                      textAlign: "center", 
                    }}>
                    {col.isComponent ? (
                      <>
                        {col.id.toUpperCase()}
                        <br />
                        Submitted
                      </>
                    ) : col.phase ? (
                      <>
                        {col.phase.toUpperCase()}
                        <br />
                        {col.kind ? col.kind.toUpperCase() : ""}
                      </>
                    ) : (
                      col.label
                    )}
                    </Typography>

                    {sortKey === col.id && (
                      <span style={{
                        fontSize: 11,
                        color: '#fcfeffff',
                        lineHeight: '11px',
                        fontWeight: 'bold',
                        marginTop: 2,
                      }}>
                        {sortDir === "asc" ? "▲" : "▼"}
                      </span>
                    )}
                  </Box>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {groups.map((group) => {
              const groupName = group.top_group_node || "UNASSIGNED";
              const isCollapsed = !!collapsed[groupName];
              const visibleCount = (group.items || []).length;
              const totalCount = (group as any).totalCount || visibleCount;

              const sortedItems = [...(group.items || [])];
              if (sortKey && sortDir !== "none") {
                sortedItems.sort((a: any, b: any) => {
                  const aVal = getSortValue(a, sortKey, latestComponents);
                  const bVal = getSortValue(b, sortKey, latestComponents);

                  const aEmpty = aVal === null || aVal === undefined || aVal === 0 || aVal === "";
                  const bEmpty = bVal === null || bVal === undefined || bVal === 0 || bVal === "";

                  // push empty values to bottom
                  if (aEmpty && bEmpty) return 0;
                  if (aEmpty) return 1;
                  if (bEmpty) return -1;

                  if (aVal === bVal) return 0;

                  return sortDir === "asc"
                    ? aVal > bVal ? 1 : -1
                    : aVal < bVal ? 1 : -1;
                });
              }

              return (
                <React.Fragment key={groupName}>
                  {/* Group row (click only expands/collapses) */}
                  <TableRow
                    className={classes.groupHeader}
                    onClick={() => {
                      // ✅ Group row click should ONLY expand/collapse
                      toggle(groupName);
                    }}
                    style={{ cursor: "pointer" }}
                  >
                    <TableCell
                      colSpan={visibleColumns.length}
                      style={{
                        backgroundColor: COLORS.GROUP_BG,
                        color: COLORS.GROUP_TEXT,
                        borderBottom: UI.GROUP_ROW_GAP_PX + "px solid " + COLORS.TABLE_BG,
                        padding: 0,
                        fontWeight: 500,
                        position: "relative",
                      }}
                    >
                      <Box display="flex" alignItems="center" justifyContent="space-between">
                        <Box display="flex" alignItems="center">
                          <IconButton
                            size="small"
                            style={{ color: COLORS.GROUP_TEXT, padding: 0 }}
                            onClick={(e) => {
                              // ✅ clicking the chevron should only toggle (and not bubble to other handlers)
                              e.stopPropagation();
                              toggle(groupName);
                            }}
                          >
                            {isCollapsed ? (
                              <ChevronRightIcon fontSize="small" />
                            ) : (
                              <ExpandMoreIcon fontSize="small" />
                            )}
                          </IconButton>

                          <Typography
                            style={{
                              color: COLORS.GROUP_TEXT,
                              fontSize: UI.FONT_SIZE_GROUP,
                              fontWeight: 900,
                            }}
                          >
                            {groupName.toUpperCase()}
                          </Typography>
                          <Typography
                            style={{
                              fontSize: UI.FONT_SIZE_GROUP - 1,
                              fontWeight: 800,
                              marginLeft: 1,
                            }}>
                             ({visibleCount} of {totalCount})
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                  </TableRow>

                  {/* Data rows */}
                  {/* Data rows */}
                  {!isCollapsed &&
                    sortedItems.map((asset: any, idx: number) => (
                      <TableRow key={groupName + "-" + idx} hover>
                        {visibleColumns.map((col) => (
                          <TableCell
                            key={col.id}
                            align={col.id === "group_1_name" || col.id === "thumbnail" ? "left" : "center"}
                            style={buildCellStyle(col, phaseMeta)}
                          >
                            {renderAssetField(asset, col, dateTimeFormat, latestComponents)}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                </React.Fragment>
              );
            })}
          </TableBody>

          {/* ✅ Sticky footer pagination */}
          {tableFooter ? tableFooter : null}
        </Table>
      </Box>
      
    </Box>
  );
};

export default AssetsGroupedDataTable;