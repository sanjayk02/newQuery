/* _________________________________________________________________________________
  
  Module Name:
  AssetsDataTable.tsx
  
  Module Description:
  React component that renders a data table displaying asset information for a project.
  
  Details:
  - Fetches and displays asset thumbnails.
  - Supports sorting by various asset attributes.
  - Allows hiding/showing of specific columns.
  - Compact mode for minimal column display.

  * Update and Modification History:
    * - 29-10-2025 - SanjayK PSI - Initial creation sorting pagination implementation.
    * - 07-11-2025 - SanjayK PSI - Column visibility toggling implementation.
    * - 20-11-2025 - SanjayK PSI - Fixed typo in filter property names handling.
    * - 24-11-2025 - SanjayK PSI - Added detailed doc comments for functions and types.
    * - 05-02-2026 - SanjayK PSI - Added components for column visibility drawer and filter status selection.
    * - 09-02-2026 - SanjayK PSI - Added take number column and updated column sections for asset data table.
    
  Function:
    * - AssetsDataTable: Main component rendering the assets data table.
    * - RecordTableHead: Renders the table header with sortable columns.
    * - AssetRow: Renders individual rows for each asset.
    * - Styled components for consistent theming.
    * - MultIineTooltipTableCell: Table cell with multi-line tooltip support.
    * - Constants for asset phases, approval statuses, and work statuses.
    * - Column definitions for the data table.
    * - NON_FIXED_IDS: Array of column IDs excluding fixed columns.
    * - isOnlyFixedVisible: Utility to check if only fixed columns are visible.
    * - TooltipTableCellProps: Props for the MultiLineTooltipTableCell component.
    * - Status: Type defining display name and color for statuses.
    * - Columns: Configuration for the data table columns.
    * - ASSET_PHASES, APPROVAL_STATUS, WORK_STATUS: Mappings for phases and statuses.
    * - getPhaseData: Utility to extract phase-related data from an asset.
    * - isHidden: Utility to check if a column is hidden.
    * - RecordTableHead: Renders the table header with sortable columns
  * 
  ___________________________________________________________________________________ */
import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  TableSortLabel,
  Box,
} from "@material-ui/core";
import {
  AssetRowProps,
  AssetsDataTableProps,
  Colors,
  Column,
  RecordTableHeadProps,
  SortDir,
  Asset,
} from "./types";
import { useFetchAssetThumbnails, useFetchLatestAssetComponents } from "./hooks";

const ASSET_PHASES: { [key: string]: Colors } = {
  mdl: {
    lineColor: '#3295fd',
    backgroundColor: '#354d68',
  },
  rig: {
    lineColor: '#c061fd',
    backgroundColor: '#5e3568',
  },
  bld: {
    lineColor: '#fc2f8c',
    backgroundColor: '#5a0028',
  },
  dsn: {
    lineColor: '#98f2fb',
    backgroundColor: '#045660',
  },
  ldv: {
    lineColor: '#fe5cff',
    backgroundColor: '#683566',
  },
};

type Status = Readonly<{
  displayName: string,
  color: string,
}>;

const APPROVAL_STATUS: { [key: string]: Status } = {
  check: {
    displayName: 'Check',
    color: '#ca25ed',
  },
  clientReview: {
    displayName: 'Client Review',
    color: '#005fbd',
  },
  dirReview: {
    displayName: 'Dir Review',
    color: '#007fff',
  },
  epdReview: {
    displayName: 'EPD Review',
    color: '#4fa7ff',
  },
  clientOnHold: {
    displayName: 'Client On Hold',
    color: '#d69b00',
  },
  dirOnHold: {
    displayName: 'Dir On Hold',
    color: '#ffcc00',
  },
  epdOnHold: {
    displayName: 'EPD On Hold',
    color: '#ffdd55',
  },
  execRetake: {
    displayName: 'Exec Retake',
    color: '#a60000',
  },
  clientRetake: {
    displayName: 'Client Retake',
    color: '#c60000',
  },
  dirRetake: {
    displayName: 'Dir Retake',
    color: '#ff0000',
  },
  epdRetake: {
    displayName: 'EPD Retake',
    color: '#ff4f4f',
  },
  clientApproved: {
    displayName: 'Client Approved',
    color: '#1d7c39',
  },
  dirApproved: {
    displayName: 'Dir Approved',
    color: '#27ab4f',
  },
  epdApproved: {
    displayName: 'EPD Approved',
    color: '#5cda82',
  },
  other: {
    displayName: 'Other',
    color: '#9a9a9a',
  },
  omit: {
    displayName: 'Omit',
    color: '#646464',
  },
  approved: {
    displayName: 'Approved',
    color: '#32cd32',
  },
  review: {
    displayName: 'Review',
    color: '#ffa500',
  },
};

const WORK_STATUS: { [key: string]: Status } = {
  check: { displayName: "Check", color: "#e287f5" },
  cgsvOnHold: { displayName: "CGSV On Hold", color: "#ffdd55" },
  svOnHold: { displayName: "SV On Hold", color: "#ffe373" },
  leadOnHold: { displayName: "Lead On Hold", color: "#fff04f" },
  cgsvRetake: { displayName: "CGSV Retake", color: "#ff4f4f" },
  svRetake: { displayName: "SV Retake", color: "#ff8080" },
  leadRetake: { displayName: "Lead Retake", color: "#ffbbbb" },
  cgsvApproved: { displayName: "CGSV Approved", color: "#5cda82" },
  svApproved: { displayName: "SV Approved", color: "#83e29f" },
  leadApproved: { displayName: "Lead Approved", color: "#b9eec9" },
  svOther: { displayName: "SV Other", color: "#9a9a9a" },
  leadOther: { displayName: "Lead Other", color: "#dbdbdb" },
  review: { displayName: "Review", color: "#ffa500" },
  inProgress: { displayName: "In Progress", color: "#00bfff" },
  notStarted: { displayName: "Not Started", color: "#d3d3d3" },
  approved: { displayName: "Approved", color: "#32cd32" },
};

// ============================================
// 2. BUILD COLUMN DEFINITIONS DYNAMICALLY FROM phaseComponents
// ============================================

/**
 * Builds the full column list for the table header based on the project's
 * pipeline phase component configuration. Only component columns that actually
 * exist in the project are included — nothing is hardcoded.
 *
 * @param phaseComponents - Map of phase → component ID array, e.g. { mdl: ['mdlRend', 'mdlAnm'], bld: ['bldAnm'] }
 */
/**
 * Returns the dynamic component columns for a given phase, based on the
 * project's pipeline configuration. Spread this into the columns array
 * after the fixed phase columns (WORK / APPR / TAKE).
 *
 * @param phase           - Phase key, e.g. "mdl"
 * @param colors          - Phase colour config (lineColor + backgroundColor)
 * @param phaseComponents - Map of phase → component ID array from pipeline settings
 */
function buildComponentColumns(
  phase: string,
  colors: Colors,
  phaseComponents: { [phase: string]: string[] } | undefined,
): Column[] {
  const componentIds = (phaseComponents && phaseComponents[phase]) || [];
  return componentIds.map((id) => ({
    id,
    label: `${id.toUpperCase()} Submitted`,
    colors,
    sortable: true,
    sortKey: id,
  }));
}

/**
 * Builds the full column list. Fixed columns are declared explicitly so they
 * stay readable; only the per-phase component columns are dynamic via
 * buildComponentColumns().
 */
function buildColumns(phaseComponents: { [phase: string]: string[] } | undefined): Column[] {
  return [
    { id: "thumbnail",    label: "Thumbnail" },
    { id: "group_1_name", label: "Name", sortable: true, sortKey: "group_1" },

    // MDL Phase
    { id: "mdl_work_status",     label: "MDL WORK", colors: ASSET_PHASES.mdl, sortable: true, sortKey: "mdl_work" },
    { id: "mdl_approval_status", label: "MDL APPR", colors: ASSET_PHASES.mdl, sortable: true, sortKey: "mdl_appr" },
    { id: "mdl_take",            label: "MDL TAKE", colors: ASSET_PHASES.mdl, sortable: true, sortKey: "mdl_take" },
    ...buildComponentColumns("mdl", ASSET_PHASES.mdl, phaseComponents), // Dynamic component columns

    // RIG Phase
    { id: "rig_work_status",     label: "RIG WORK", colors: ASSET_PHASES.rig, sortable: true, sortKey: "rig_work" },
    { id: "rig_approval_status", label: "RIG APPR", colors: ASSET_PHASES.rig, sortable: true, sortKey: "rig_appr" },
    { id: "rig_take",            label: "RIG TAKE", colors: ASSET_PHASES.rig, sortable: true, sortKey: "rig_take" },
    ...buildComponentColumns("rig", ASSET_PHASES.rig, phaseComponents), // Dynamic component columns

    // BLD Phase
    { id: "bld_work_status",     label: "BLD WORK", colors: ASSET_PHASES.bld, sortable: true, sortKey: "bld_work" },
    { id: "bld_approval_status", label: "BLD APPR", colors: ASSET_PHASES.bld, sortable: true, sortKey: "bld_appr" },
    { id: "bld_take",            label: "BLD TAKE", colors: ASSET_PHASES.bld, sortable: true, sortKey: "bld_take" },
    ...buildComponentColumns("bld", ASSET_PHASES.bld, phaseComponents), // Dynamic component columns

    // DSN Phase
    { id: "dsn_work_status",     label: "DSN WORK", colors: ASSET_PHASES.dsn, sortable: true, sortKey: "dsn_work" },
    { id: "dsn_approval_status", label: "DSN APPR", colors: ASSET_PHASES.dsn, sortable: true, sortKey: "dsn_appr" },
    { id: "dsn_take",            label: "DSN TAKE", colors: ASSET_PHASES.dsn, sortable: true, sortKey: "dsn_take" },
    ...buildComponentColumns("dsn", ASSET_PHASES.dsn, phaseComponents), // Dynamic component columns

    // LDV Phase
    { id: "ldv_work_status",     label: "LDV WORK", colors: ASSET_PHASES.ldv, sortable: true, sortKey: "ldv_work" },
    { id: "ldv_approval_status", label: "LDV APPR", colors: ASSET_PHASES.ldv, sortable: true, sortKey: "ldv_appr" },
    { id: "ldv_take",            label: "LDV TAKE", colors: ASSET_PHASES.ldv, sortable: true, sortKey: "ldv_take" },
    ...buildComponentColumns("ldv", ASSET_PHASES.ldv, phaseComponents), // Dynamic component columns

    { id: "relation", label: "Relation", sortable: true, sortKey: "relation" },
  ];
}

const FIXED_IDS = new Set(["thumbnail", "group_1_name"]);

/**
 * Returns true only when every non-fixed column in the *current* dynamic column
 * list is hidden — used to activate compact/fixed-layout mode.
 */
const isOnlyFixedVisible = (cols: Column[], hidden: Set<string>) =>
  cols.filter(c => !FIXED_IDS.has(c.id)).every(c => hidden.has(c.id));

type TooltipTableCellProps = {
  tooltipText: string;
  status?: Status;
  leftBorderStyle: string;
  rightBorderStyle: string;
  bottomBorderStyle: string;
  children?: React.ReactNode;
};

/**
 * Utility functions for consistent empty value handling
 */
const isEmptyValue = (value: any): boolean => {
  if (value === null || value === undefined) return true;
  const str = String(value).trim();
  return str === '' || str === '-' || str === '—' || str === 'null' || str === 'undefined';
};

const formatForDisplay = (value: any): string => {
  if (isEmptyValue(value)) return '—';
  return String(value).trim();
};

const MultiLineTooltipTableCell: React.FC<TooltipTableCellProps> = ({
  tooltipText,
  status,
  leftBorderStyle,
  rightBorderStyle,
  bottomBorderStyle = "none",
  children,
}) => {
  const [open, setOpen] = React.useState(false);
  const hasTooltipText = tooltipText && tooltipText.trim().length > 0;

  const displayText = children || (status ? status.displayName : "—");

  return (
    <TableCell
      style={{
        textAlign: "center",
        verticalAlign: "middle",
        padding: "8px",
        color: status ? status.color : "",
        borderLeft: leftBorderStyle,
        borderRight: rightBorderStyle,
        borderBottom: bottomBorderStyle,
      }}
      onClick={hasTooltipText ? () => setOpen(true) : undefined}
    >
      {hasTooltipText ? (
        <Tooltip
          title={
            <div style={{ fontSize: "0.8rem", whiteSpace: "pre-wrap" }}>
              {tooltipText}
            </div>
          }
          onClose={() => setOpen(false)}
          open={open}
          arrow
        >
          <span>{displayText}</span>
        </Tooltip>
      ) : (
        <span>{displayText}</span>
      )}
    </TableCell>
  );
};       

// ============================================
// 3. UPDATE THE RECORDTABLEHEAD COMPONENT
// ============================================
const RecordTableHead: React.FC<RecordTableHeadProps & {
  onSortChange: (sortKey: string) => void;
  currentSortKey: string;
  currentSortDir: SortDir;
  headerCellStylesById?: Record<string, React.CSSProperties>;
}> = ({
  columns, onSortChange, currentSortKey, currentSortDir, headerCellStylesById = {},
}) => {
  const getSortDir = (id: string, activeKey: string, activeDir: SortDir): SortDir =>
    activeKey === id ? activeDir : "none";

  const createSortHandler = (id: string) => () => onSortChange(id);

  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => {
          // Group columns by phase using the colors reference — more reliable than
          // string-prefix matching, since component column IDs like "bldAnm" don't
          // follow the "phase_field" naming convention.
          const inPhaseIds = column.colors
            ? columns
                .filter(c => c.colors === column.colors)
                .map(c => c.id)
            : [];
          const firstId = inPhaseIds[0];
          const lastId  = inPhaseIds[inPhaseIds.length - 1];

          const hasPhase = Boolean(column.colors);
          const rail = hasPhase ? `solid 3px ${column.colors!.lineColor}` : "none";

          const sortKey = column.sortKey || column.id;
          const sortDir = getSortDir(sortKey, currentSortKey, currentSortDir);

          return (
            <TableCell
              key={column.id}
              style={{
                backgroundColor: column.colors ? column.colors.backgroundColor : "none",
                borderTop: hasPhase ? rail : "none",
                borderLeft: hasPhase && firstId === column.id ? rail : "none",
                borderRight: hasPhase && lastId  === column.id ? rail : "none",
                ...(headerCellStylesById[column.id] || {}),
                cursor: column.sortable ? "pointer" : "default",
              }}
              onClick={column.sortable ? createSortHandler(sortKey) : undefined}
            >
              {column.sortable ? (
                <Box display="flex" alignItems="center" justifyContent="center">
                  <span style={{ fontSize: 12, fontWeight: 500 }}>
                    {column.label}
                  </span>
                  <Box ml={0.5} display="inline-flex" alignItems="center">
                    {sortDir !== "none" && (
                      <span style={{ 
                        fontSize: 12,
                        color: '#fcfeffff',
                        lineHeight: '12px',
                        marginLeft: 2,
                        fontWeight: 'bold'
                      }}>
                        {sortDir === "asc" ? "▲" : "▼"}
                      </span>
                    )}
                  </Box>
                </Box>
              ) : (
                column.label
              )}
            </TableCell>
          );
        })}
      </TableRow>
    </TableHead>
  );
};


const AssetRow: React.FC<AssetRowProps & { hiddenColumns: Set<string>; compact: boolean }> = ({
  asset, thumbnails, dateTimeFormat, isLastRow, hiddenColumns, compact, phaseComponents, latestComponents,
}) => {
  const isHidden = (id: string) => hiddenColumns.has(id);

  // ================= COMPONENT HELPERS =================
  const getComponentCellData = (
    asset: any,
    componentName: string
  ) => {
    const assetKey = `${asset.group_1}-${asset.relation}`;
    const componentList: any[] = latestComponents && latestComponents[assetKey] ? latestComponents[assetKey] : [];

    const item =
      componentList.find(
        (x: any) =>
          x.component === componentName ||
          (
            x.latest_document && 
            x.latest_document.component === componentName)
      ) ||
      componentList.find(
        (x: any) =>
          x.component && x.component.toLowerCase() === componentName.toLowerCase() ||
          (
            x.latest_document && 
            x.latest_document.component && 
            x.latest_document.component.toLowerCase() === componentName.toLowerCase())
      );

    if (item && item.latest_document) {
      return {
        component: item.component || item.latest_document.component,
        phase: item.latest_document.phase,
        submittedAt: item.latest_document.submitted_at_utc,
      };
    }

    return null;
  };

  const getComponentDisplayText = (
    asset: any,
    componentName: string
  ): string => {
    const data = getComponentCellData(asset, componentName);

    if (!data || !data.submittedAt) return "—";

    return dateTimeFormat.format(new Date(data.submittedAt));
  };

  const getComponentTooltip = (
    asset: any,
    componentName: string
  ): string => {
    const data = getComponentCellData(asset, componentName);

    if (!data) {
      return "No submission available";
    }

    const submittedText = data.submittedAt
      ? dateTimeFormat.format(new Date(data.submittedAt))
      : "—";

    return [
      `Component: ${data.component}`,
      `Phase: ${data.phase}`,
      `Submitted: ${submittedText}`,
    ].join("\n");
  };

  const getPhaseData = (phase: string) => {
    const workStatusKey     = `${phase}_work_status` as keyof Asset;
    const approvalStatusKey = `${phase}_approval_status` as keyof Asset;
    // const submittedAtKey    = `${phase}_submitted_at_utc` as keyof Asset;
    const takeKey           = `${phase}_take` as keyof Asset;

    const workStatusValue     = asset[workStatusKey];
    const approvalStatusValue = asset[approvalStatusKey];
    // const submittedAtValue    = asset[submittedAtKey];
    const takeValue           = asset[takeKey];

    // Status lookup with fallback for empty values
    let workStatus: Status | undefined = undefined;
    if (!isEmptyValue(workStatusValue)) {
        const raw = String(workStatusValue);
        workStatus = WORK_STATUS[raw] || 
        WORK_STATUS[raw.toLowerCase()] || 
        WORK_STATUS[raw.charAt(0).toLowerCase() + raw.slice(1)];

        // Use a generic status if the key is not found
        if (!workStatus) {
            workStatus = WORK_STATUS.svOther;
        }
    }
    
    let approvalStatus: Status | undefined = undefined;
    if (!isEmptyValue(approvalStatusValue)) {
        const raw = String(approvalStatusValue);
        approvalStatus = APPROVAL_STATUS[raw] || 
        APPROVAL_STATUS[raw.toLowerCase()] || 
        APPROVAL_STATUS[raw.charAt(0).toLowerCase() + raw.slice(1)];

        // Use a generic status if the key is not found
        if (!approvalStatus) {
            approvalStatus = APPROVAL_STATUS.other;
        }
    }

    const takeText = !isEmptyValue(takeValue) ? String(takeValue) : '—';

    return { 
      workStatus, 
      approvalStatus, 
      // localTimeText,
      takeText,
      tooltipText: "" };
  };


  return (
    <TableRow>
      {!isHidden("thumbnail") && (
        <TableCell style={compact ? { width: 140, minWidth: 140, maxWidth: 140 } : undefined}>
          {thumbnails[`${asset.group_1}-${asset.relation}`] ? (
            <img
              src={thumbnails[`${asset.group_1}-${asset.relation}`]}
              alt={`${asset.group_1} thumbnail`}
              style={{ width: "100px", height: "auto" }}
            />
          ) : (
            <span>No Thumbnail</span>
          )}
        </TableCell>
      )}

      {/* NAME */}
      {!isHidden("group_1_name") && (
        <TableCell style={compact ? { minWidth: 220 } : undefined}>
          {formatForDisplay(asset.group_1)}
        </TableCell>
      )}

      {/* PHASES */}
      {(Object.entries(ASSET_PHASES) as Array<[string, { lineColor: string }]>).map(
          ([phase, { lineColor }]) => {
            const ids = {
              work: `${phase}_work_status`,
              appr: `${phase}_approval_status`,
              take: `${phase}_take`,
            };

            const componentIds = phaseComponents && phaseComponents[phase] || [];
            
            const visibleIds = [
              ids.work,
              ids.appr,
              ids.take,
              ...componentIds
            ]
              .filter((id): id is string => typeof id === "string" && !!id)
              .filter((id) => !isHidden(id));

            if (visibleIds.length === 0) return null;

            const firstId = visibleIds[0];
            const lastId  = visibleIds[visibleIds.length - 1];
            const rail = `solid 3px ${lineColor}`;

            const { workStatus, approvalStatus, /* localTimeText, */ takeText, tooltipText } = getPhaseData(phase);

            return (
              <React.Fragment key={`${asset.group_1}-${asset.relation}-${phase}`}>
                {/* WORK */}
                {!isHidden(ids.work) && (
                  <MultiLineTooltipTableCell
                    tooltipText={tooltipText}
                    status={workStatus}
                    leftBorderStyle={firstId === ids.work ? rail : "none"}
                    rightBorderStyle={lastId  === ids.work ? rail : "none"}
                    bottomBorderStyle={isLastRow ? rail : "none"}
                  />
                )}

                {/* APPR */}
                {!isHidden(ids.appr) && (
                  <MultiLineTooltipTableCell
                    tooltipText={tooltipText}
                    status={approvalStatus}
                    leftBorderStyle={firstId === ids.appr ? rail : "none"}
                    rightBorderStyle={lastId  === ids.appr ? rail : "none"}
                    bottomBorderStyle={isLastRow ? rail : "none"}
                  />
                )}

                {/* TAKE */}
                {!isHidden(ids.take) && (
                  <TableCell
                    style={{
                      borderLeft: firstId === ids.take ? rail : "none",
                      borderRight: lastId === ids.take ? rail : "none",
                      borderBottom: isLastRow ? rail : "none",
                    }}
                  >
                    {takeText}
                  </TableCell>
                )}

                {/* ================= MANUAL COMPONENTS ================= */}
                {/* PIPELINE SETTING COMPONENTS */}
                {componentIds.map((componentId) =>
                  !isHidden(componentId) && (
                    <MultiLineTooltipTableCell
                      key={`${asset.group_1}-${asset.relation}-${componentId}`}
                      tooltipText={getComponentTooltip(asset, componentId)}
                      status={undefined}
                      leftBorderStyle={firstId === componentId ? rail : "none"}
                      rightBorderStyle={lastId === componentId ? rail : "none"}
                      bottomBorderStyle={isLastRow ? rail : "none"}
                    >
                      {getComponentDisplayText(asset, componentId)}
                    </MultiLineTooltipTableCell>
                  )
                )}
              </React.Fragment>
            );
          }
        )}

      {/* RELATION */}
      {!isHidden("relation") && !compact && (
        <TableCell>{formatForDisplay(asset.relation)}</TableCell>
      )}
    </TableRow>
  );
};

const AssetsDataTable: React.FC<AssetsDataTableProps> = ({
  project,
  assets,
  tableFooter,
  dateTimeFormat,
  onSortChange,
  currentSortKey,
  currentSortDir,
  hiddenColumns = new Set(),
  phaseComponents,
  latestComponents,
}) => {
  if (!project) return null;

  const { thumbnails } = useFetchAssetThumbnails(
    project,
    assets
  );

  // Build the column list from this project's pipeline phase configuration.
  // Only component columns that actually exist in the project will appear.
  const columns = buildColumns(phaseComponents);

  // Compact mode: only Thumbnail + Name visible
  const compact = isOnlyFixedVisible(columns, hiddenColumns);

  // Header widths to keep header/body aligned in compact mode
  const headerCellStylesById: Record<string, React.CSSProperties> = compact
    ? {
        thumbnail: { width: 140, minWidth: 140, maxWidth: 140 },
        group_1_name: { minWidth: 220 },
      }
    : {};

  // Visible columns for header — always show fixed columns, hide the rest if toggled off
  const visibleColumns = columns.filter(
    (c) => FIXED_IDS.has(c.id) || !hiddenColumns.has(c.id)
  );

  return (
    <Table stickyHeader style={{ ...(compact ? { tableLayout: 'fixed' } : {}), width: '100%' }}>
      <RecordTableHead
        key="asset-data-table-head"
        columns={visibleColumns}
        onSortChange={onSortChange}
        currentSortKey={currentSortKey}
        currentSortDir={currentSortDir}
        headerCellStylesById={headerCellStylesById}
      />

      <TableBody>
        {assets.map((asset, index) => (
          <AssetRow
            key={`${asset.group_1}-${asset.relation}-${asset.component}-${index}`} // Unique key for each asset row
            asset={asset}
            thumbnails={thumbnails}
            dateTimeFormat={dateTimeFormat}
            isLastRow={index === assets.length - 1}
            hiddenColumns={hiddenColumns}
            compact={compact}
            phaseComponents={phaseComponents}
            latestComponents={latestComponents} 
          />
        ))}
      </TableBody>

      {tableFooter || null}
    </Table>
  );
};

export default AssetsDataTable;