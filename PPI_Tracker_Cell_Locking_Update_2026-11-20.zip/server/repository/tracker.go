package repository

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"slices"
	"time"

	"github.com/PolygonPictures/central30-web/front/entity"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type Tracker struct {
	db *mongo.Database
}

var ErrEditLockMissing = errors.New("edit lock is missing, expired, or does not cover this update")

type EditLockConflictError struct {
	User   string
	Studio string
}

func (e *EditLockConflictError) Error() string {
	if e.User == "" {
		return "this tracker item is currently being edited"
	}
	if e.Studio == "" {
		return fmt.Sprintf("this tracker item is currently being edited by %s", e.User)
	}
	return fmt.Sprintf("this tracker item is currently being edited by %s (%s)", e.User, e.Studio)
}

func NewTracker(mongodb *mongo.Database) *Tracker {
	return &Tracker{
		db: mongodb,
	}
}

// --- Column ---

func (r *Tracker) GetColumns(ctx context.Context, project string, root string) ([]entity.TrackerColumn, error) {
	scopeFilter := bson.M{
		"$or": []bson.M{
			{"scope": "global"},
			{"project": project, "scope": "project"},
			{"scope": bson.M{"$exists": false}, "project": project},
		},
	}

	filter := bson.M{
		"deleted": "0",
		"$and": []bson.M{
			scopeFilter,
		},
	}

	if root != "" {
		rootFilter := bson.M{
			"root": bson.M{"$in": []string{root, ""}},
		}
		filter["$and"] = append(filter["$and"].([]bson.M), rootFilter)
	}

	cursor, err := r.db.Collection(entity.ColTrackerColumns).Find(ctx, filter)
	if err != nil {
		return nil, err
	}
	var rawColumns []entity.TrackerColumn
	if err = cursor.All(ctx, &rawColumns); err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	columnMap := make(map[string]entity.TrackerColumn)

	for _, col := range rawColumns {
		if col.Scope == "global" {
			if col.IsSystem {
				columnMap[col.Key] = col
			} else {
				isExcluded := false
				for _, p := range col.ExcludeProjects {
					if p == project {
						isExcluded = true
						break
					}
				}
				if !isExcluded {
					columnMap[col.Key] = col
				}
			}
		}
	}

	for _, col := range rawColumns {
		if col.Scope == "project" || col.Scope == "" {
			if col.Project == project {
				columnMap[col.Key] = col
			}
		}
	}

	var result = []entity.TrackerColumn{}
	for _, col := range columnMap {
		result = append(result, col)
	}

	return result, nil
}

func (r *Tracker) GetColumnByID(ctx context.Context, id primitive.ObjectID) (*entity.TrackerColumn, error) {
	var col entity.TrackerColumn
	err := r.db.Collection(entity.ColTrackerColumns).FindOne(ctx, bson.M{"_id": id}).Decode(&col)
	if err != nil {
		return nil, err
	}
	return &col, nil
}

func (r *Tracker) CreateColumn(ctx context.Context, col entity.TrackerColumn) error {
	_, err := r.db.Collection(entity.ColTrackerColumns).InsertOne(ctx, col)
	return err
}

func (r *Tracker) UpdateColumn(ctx context.Context, col entity.TrackerColumn) error {
	update := bson.M{
		"$set": bson.M{
			"display_name":     col.DisplayName,
			"data_type":        col.DataType,
			"config":           col.Config,
			"visibled":         col.Visibled,
			"scope":            col.Scope,
			"exclude_projects": col.ExcludeProjects,
			"is_system":        col.IsSystem,
			"modified_at_utc":  col.ModifiedAtUTC,
			"modified_by":      col.ModifiedBy,
		},
	}
	_, err := r.db.Collection(entity.ColTrackerColumns).UpdateOne(ctx, bson.M{"_id": col.ID}, update)
	return err
}

func (r *Tracker) SoftDeleteColumn(ctx context.Context, id primitive.ObjectID) error {
	update := bson.M{"$set": bson.M{"deleted": id.String()}}
	_, err := r.db.Collection(entity.ColTrackerColumns).UpdateOne(ctx, bson.M{"_id": id}, update)
	return err
}

// --- Entity ---

func (r *Tracker) SearchEntities(ctx context.Context, req entity.SearchRequest) ([]entity.TrackerEntity, error) {
	filter := bson.M{
		"project": req.Project,
		"deleted": "0",
	}

	defaultFields := []string{"_id", "project", "root", "group", "created_at_utc", "modified_at_utc", "created_by", "modified_by", "deleted"}

	for _, f := range req.Filters {
		dbKey := f.Key
		if !slices.Contains(defaultFields, dbKey) {
			dbKey = "data." + f.Key
		}

		switch f.Operator {
		case "eq":
			filter[dbKey] = bson.M{"$eq": f.Value}
		case "contains":
			filter[dbKey] = bson.M{"$regex": primitive.Regex{Pattern: fmt.Sprintf("%v", f.Value), Options: "i"}}
		case "gt":
			filter[dbKey] = bson.M{"$gt": f.Value}
		case "lt":
			filter[dbKey] = bson.M{"$lt": f.Value}
		}
	}

	opts := options.Find()
	if len(req.Fields) > 0 {
		projection := bson.M{}
		for _, field := range req.Fields {
			key := field
			if !slices.Contains(defaultFields, key) {
				key = "data." + key
			}
			projection[key] = 1
		}
		opts.SetProjection(projection)
	}

	if len(req.Sorts) > 0 {
		sortD := bson.D{}
		for _, s := range req.Sorts {
			key := s.Key
			if !slices.Contains(defaultFields, key) {
				key = "data." + key
			}
			sortD = append(sortD, bson.E{Key: key, Value: s.Direction})
		}
		opts.SetSort(sortD)
	} else {
		opts.SetSort(bson.D{{Key: "group", Value: -1}})
	}

	cursor, err := r.db.Collection(entity.ColTrackerEntities).Find(ctx, filter, opts)
	if err != nil {
		return nil, err
	}
	var results = []entity.TrackerEntity{}
	if err = cursor.All(ctx, &results); err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)
	return results, nil
}

func (r *Tracker) GetEntityByID(ctx context.Context, id primitive.ObjectID) (*entity.TrackerEntity, error) {
	var ent entity.TrackerEntity
	err := r.db.Collection(entity.ColTrackerEntities).FindOne(ctx, bson.M{"_id": id}).Decode(&ent)
	if err != nil {
		return nil, err
	}
	return &ent, nil
}

func (r *Tracker) CreateEntity(ctx context.Context, ent entity.TrackerEntity) error {
	_, err := r.db.Collection(entity.ColTrackerEntities).InsertOne(ctx, ent)
	return err
}

func (r *Tracker) UpdateEntity(ctx context.Context, ent entity.TrackerEntity) error {
	update := bson.M{
		"$set": bson.M{
			"root":            ent.Root,
			"group":           ent.Group,
			"data":            ent.Data,
			"modified_at_utc": ent.ModifiedAtUTC,
			"modified_by":     ent.ModifiedBy,
		},
	}
	_, err := r.db.Collection(entity.ColTrackerEntities).UpdateOne(ctx, bson.M{"_id": ent.ID}, update)
	return err
}

func (r *Tracker) RestoreEntity(ctx context.Context, ent entity.TrackerEntity) error {
	_, err := r.db.Collection(entity.ColTrackerEntities).ReplaceOne(ctx, bson.M{"_id": ent.ID}, ent)
	return err
}

func (r *Tracker) SoftDeleteEntity(ctx context.Context, id primitive.ObjectID) error {
	update := bson.M{"$set": bson.M{"deleted": id.String()}}
	_, err := r.db.Collection(entity.ColTrackerEntities).UpdateOne(ctx, bson.M{"_id": id}, update)
	return err
}

// --- Temporary edit locks ---

func newEditLockToken() (string, error) {
	bytes := make([]byte, 32)
	if _, err := rand.Read(bytes); err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}

func editLockTokenHash(token string) string {
	digest := sha256.Sum256([]byte(token))
	return hex.EncodeToString(digest[:])
}

func (r *Tracker) withTransaction(
	ctx context.Context,
	callback func(mongo.SessionContext) error,
) error {
	session, err := r.db.Client().StartSession()
	if err != nil {
		return err
	}
	defer session.EndSession(ctx)
	_, err = session.WithTransaction(ctx, func(sessionCtx mongo.SessionContext) (interface{}, error) {
		return nil, callback(sessionCtx)
	})
	return err
}

// WithTransaction is used when a tracker operation must update several
// entities as one all-or-nothing operation.
func (r *Tracker) WithTransaction(
	ctx context.Context,
	callback func(mongo.SessionContext) error,
) error {
	return r.withTransaction(ctx, callback)
}

func (r *Tracker) AcquireEditLocks(
	ctx context.Context,
	project string,
	targets []entity.EditLockTargetRequest,
	user string,
	studio string,
) (string, error) {
	token, err := newEditLockToken()
	if err != nil {
		return "", err
	}
	tokenHash := editLockTokenHash(token)
	now := time.Now().UTC()
	expiresAt := now.Add(5 * time.Minute)

	err = r.withTransaction(ctx, func(sessionCtx mongo.SessionContext) error {
		seen := make(map[string]struct{}, len(targets))
		locks := make([]entity.TrackerEditLock, 0, len(targets))
		for _, target := range targets {
			entityID, err := primitive.ObjectIDFromHex(target.EntityID)
			if err != nil {
				return fmt.Errorf("invalid entity id: %w", err)
			}
			if target.LockScope == entity.LockScopeCell && target.FieldKey == "" {
				return errors.New("field_key is required for a cell lock")
			}
			if target.LockScope == entity.LockScopeEntity {
				target.FieldKey = ""
			}
			key := entityID.Hex() + ":" + target.LockScope + ":" + target.FieldKey
			if _, alreadySeen := seen[key]; alreadySeen {
				return errors.New("duplicate edit lock target")
			}
			seen[key] = struct{}{}

			var trackerEntity entity.TrackerEntity
			err = r.db.Collection(entity.ColTrackerEntities).FindOne(
				sessionCtx,
				bson.M{"_id": entityID, "project": project, "deleted": "0"},
			).Decode(&trackerEntity)
			if err != nil {
				return err
			}

			// Every acquisition updates one stable guard document. This makes two
			// concurrent attempts for the same entity conflict at the MongoDB
			// transaction level, including entity-vs-different-cell requests.
			_, err = r.db.Collection(entity.ColTrackerEditLockGuards).UpdateOne(
				sessionCtx,
				bson.M{"project": project, "entity_id": entityID},
				bson.M{"$set": bson.M{"updated_at_utc": now}},
				options.Update().SetUpsert(true),
			)
			if err != nil {
				return err
			}

			conflictFilter := bson.M{
				"project": project, "entity_id": entityID,
				"expires_at": bson.M{"$gt": now},
			}
			if target.LockScope == entity.LockScopeCell {
				conflictFilter["$or"] = []bson.M{
					{"lock_scope": entity.LockScopeEntity},
					{"lock_scope": entity.LockScopeCell, "field_key": target.FieldKey},
				}
			}
			var conflict entity.TrackerEditLock
			err = r.db.Collection(entity.ColTrackerEditLocks).FindOne(
				sessionCtx, conflictFilter,
			).Decode(&conflict)
			if err == nil {
				return &EditLockConflictError{User: conflict.User, Studio: conflict.Studio}
			}
			if !errors.Is(err, mongo.ErrNoDocuments) {
				return err
			}

			locks = append(locks, entity.TrackerEditLock{
				ID: primitive.NewObjectID(), Project: project, EntityID: entityID,
				Scope: target.LockScope, FieldKey: target.FieldKey,
				TokenHash: tokenHash, User: user, Studio: studio,
				ExpiresAt: expiresAt, CreatedAt: now,
			})
		}
		if len(locks) == 0 {
			return errors.New("at least one edit lock target is required")
		}
		_, err := r.db.Collection(entity.ColTrackerEditLocks).InsertMany(sessionCtx, locks)
		return err
	})
	if err != nil {
		return "", err
	}
	return token, nil
}

func (r *Tracker) RenewEditLocks(ctx context.Context, project string, token string) error {
	result, err := r.db.Collection(entity.ColTrackerEditLocks).UpdateMany(
		ctx,
		bson.M{"project": project, "token_hash": editLockTokenHash(token), "expires_at": bson.M{"$gt": time.Now().UTC()}},
		bson.M{"$set": bson.M{"expires_at": time.Now().UTC().Add(5 * time.Minute)}},
	)
	if err != nil {
		return err
	}
	if result.MatchedCount == 0 {
		return ErrEditLockMissing
	}
	return nil
}

func (r *Tracker) ReleaseEditLocks(ctx context.Context, project string, token string) error {
	_, err := r.db.Collection(entity.ColTrackerEditLocks).DeleteMany(
		ctx, bson.M{"project": project, "token_hash": editLockTokenHash(token)},
	)
	return err
}

func (r *Tracker) ValidateEditLock(
	ctx context.Context,
	project string,
	entityID primitive.ObjectID,
	token string,
	fieldKeys []string,
	requireEntityLock bool,
) error {
	if token == "" {
		return ErrEditLockMissing
	}
	cursor, err := r.db.Collection(entity.ColTrackerEditLocks).Find(ctx, bson.M{
		"project": project, "entity_id": entityID,
		"token_hash": editLockTokenHash(token),
		"expires_at": bson.M{"$gt": time.Now().UTC()},
	})
	if err != nil {
		return err
	}
	defer cursor.Close(ctx)

	locks := []entity.TrackerEditLock{}
	if err := cursor.All(ctx, &locks); err != nil {
		return err
	}
	for _, lock := range locks {
		if lock.Scope == entity.LockScopeEntity {
			return nil
		}
	}
	if requireEntityLock {
		return ErrEditLockMissing
	}
	coveredFields := make(map[string]bool, len(locks))
	for _, lock := range locks {
		if lock.Scope == entity.LockScopeCell {
			coveredFields[lock.FieldKey] = true
		}
	}
	for _, fieldKey := range fieldKeys {
		if !coveredFields[fieldKey] {
			return ErrEditLockMissing
		}
	}
	return nil
}

// --- History ---

func (r *Tracker) CreateHistory(ctx context.Context, h entity.History) error {
	_, err := r.db.Collection(entity.ColTrackerHistories).InsertOne(ctx, h)
	return err
}

func (r *Tracker) GetHistories(ctx context.Context, entityID primitive.ObjectID) ([]entity.History, error) {
	opts := options.Find().SetSort(bson.D{{Key: "modified_at_utc", Value: -1}})
	cursor, err := r.db.Collection(entity.ColTrackerHistories).Find(ctx, bson.M{"entity_id": entityID}, opts)
	if err != nil {
		return nil, err
	}
	var histories []entity.History
	if err = cursor.All(ctx, &histories); err != nil {
		return nil, err
	}
	return histories, nil
}

func (r *Tracker) GetHistoryByID(ctx context.Context, id primitive.ObjectID, targetType string) (*entity.History, error) {
	var h entity.History
	err := r.db.Collection(entity.ColTrackerHistories).FindOne(
		ctx,
		bson.M{"_id": id, "target_type": targetType},
	).Decode(&h)
	if err != nil {
		return nil, err
	}
	return &h, nil
}

// --- Index ---

func (r *Tracker) EnsureIndexes(ctx context.Context) error {
	// Column Collection Indexes
	colColumns := r.db.Collection(entity.ColTrackerColumns)
	_, err := colColumns.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "root", Value: 1},
				{Key: "scope", Value: 1},
				{Key: "deleted", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_scope_del"),
		},
	})
	if err != nil {
		return err
	}

	// Entity Collection Indexes
	colEntities := r.db.Collection(entity.ColTrackerEntities)
	_, err = colEntities.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "deleted", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_del"),
		},
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "group", Value: 1},
			},
			Options: options.Index().SetName("idx_proj_group"),
		},
		{
			Keys: bson.D{
				{Key: "data.$**", Value: 1},
			},
			Options: options.Index().SetName("idx_wildcard_data"),
		},
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "modified_at_utc", Value: -1},
			},
			Options: options.Index().SetName("idx_proj_modified"),
		},
	})
	if err != nil {
		return err
	}

	//History Collection Indexes
	colHistory := r.db.Collection(entity.ColTrackerHistories)
	_, err = colHistory.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "entity_id", Value: 1},
				{Key: "modified_at_utc", Value: -1},
			},
			Options: options.Index().SetName("idx_entity_modified"),
		},
	})
	if err != nil {
		return err
	}

	// Temporary edit locks automatically disappear at their expiry time. MongoDB
	// TTL cleanup runs in the background; lock queries also check expires_at so
	// an expired lock is never treated as active during that cleanup window.
	colLocks := r.db.Collection(entity.ColTrackerEditLocks)
	_, err = colLocks.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys:    bson.D{{Key: "expires_at", Value: 1}},
			Options: options.Index().SetName("ttl_expires_at").SetExpireAfterSeconds(0),
		},
		{
			Keys: bson.D{
				{Key: "project", Value: 1},
				{Key: "entity_id", Value: 1},
				{Key: "expires_at", Value: 1},
			},
			Options: options.Index().SetName("idx_project_entity_expiry"),
		},
		{
			Keys:    bson.D{{Key: "project", Value: 1}, {Key: "token_hash", Value: 1}},
			Options: options.Index().SetName("idx_project_token"),
		},
	})
	if err != nil {
		return err
	}

	colGuards := r.db.Collection(entity.ColTrackerEditLockGuards)
	_, err = colGuards.Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys: bson.D{{Key: "project", Value: 1}, {Key: "entity_id", Value: 1}},
		Options: options.Index().SetName("uniq_project_entity_guard").SetUnique(true),
	})
	if err != nil {
		return err
	}
	return nil
}
