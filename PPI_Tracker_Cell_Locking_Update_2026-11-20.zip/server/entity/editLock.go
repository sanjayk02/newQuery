package entity

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

const (
	ColTrackerEditLocks      = "tracker_edit_lock"
	ColTrackerEditLockGuards = "tracker_edit_lock_guard"
	LockScopeEntity          = "entity"
	LockScopeCell            = "cell"
)

// TrackerEditLock is a temporary server-side edit lease. The token hash is
// stored instead of the raw token, so a database read cannot be used to take
// over another user's edit session.
type TrackerEditLock struct {
	ID        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	Project   string             `bson:"project" json:"project"`
	EntityID  primitive.ObjectID `bson:"entity_id" json:"entity_id"`
	Scope     string             `bson:"lock_scope" json:"lock_scope"`
	FieldKey  string             `bson:"field_key,omitempty" json:"field_key,omitempty"`
	TokenHash string             `bson:"token_hash" json:"-"`
	User      string             `bson:"user" json:"user"`
	Studio    string             `bson:"studio" json:"studio"`
	ExpiresAt time.Time          `bson:"expires_at" json:"expires_at"`
	CreatedAt time.Time          `bson:"created_at_utc" json:"created_at_utc"`
}

// TrackerEditLockGuard serializes lock acquisition for one entity. It is not a
// user-visible lock: it only prevents two concurrent transactions from both
// deciding that incompatible entity/cell locks are free.
type TrackerEditLockGuard struct {
	ID        primitive.ObjectID `bson:"_id,omitempty"`
	Project   string             `bson:"project"`
	EntityID  primitive.ObjectID `bson:"entity_id"`
	UpdatedAt time.Time          `bson:"updated_at_utc"`
}

type EditLockTargetRequest struct {
	EntityID  string `json:"entity_id" binding:"required"`
	LockScope string `json:"lock_scope" binding:"required,oneof=entity cell"`
	FieldKey  string `json:"field_key"`
}

type AcquireEditLocksRequest struct {
	Targets []EditLockTargetRequest `json:"targets" binding:"required,min=1"`
	User    string                  `json:"user" binding:"required"`
	Studio  string                  `json:"studio" binding:"required"`
}

type LockTokenRequest struct {
	LockToken string `json:"lock_token" binding:"required"`
}

type BulkUpdateEntityTarget struct {
	ID    string `json:"id" binding:"required"`
	Group string `json:"group"`
}

type BulkUpdateEntitiesRequest struct {
	Root      string                   `json:"root"`
	Entities  []BulkUpdateEntityTarget `json:"entities" binding:"required,min=1"`
	Data      map[string]interface{}   `json:"data" binding:"required,min=1"`
	LockToken string                   `json:"lock_token" binding:"required"`
	User      string                   `json:"user" binding:"required"`
	Studio    string                   `json:"studio" binding:"required"`
}
