package delivery

import (
	"errors"
	"net/http"

	"github.com/PolygonPictures/central30-web/front/entity"
	"github.com/PolygonPictures/central30-web/front/repository"
	"github.com/PolygonPictures/central30-web/front/usecase"
	"github.com/gin-gonic/gin"
)

type Tracker struct {
	uc *usecase.Tracker
}

func NewTracker(uc *usecase.Tracker) *Tracker {
	return &Tracker{
		uc: uc,
	}
}

func writeTrackerError(c *gin.Context, err error) {
	var conflict *repository.EditLockConflictError
	if errors.As(err, &conflict) {
		c.JSON(http.StatusConflict, gin.H{
			"message": conflict.Error(), "owner": conflict.User, "studio": conflict.Studio,
		})
		return
	}
	if errors.Is(err, repository.ErrEditLockMissing) {
		c.JSON(http.StatusConflict, gin.H{
			"message": "The edit lock is missing or expired. Refresh and reopen the editor.",
		})
		return
	}
	c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
}

func (t *Tracker) GetColumns(c *gin.Context) {
	project := c.Param("project")
	root := c.Query("root")
	cols, err := t.uc.GetColumns(c.Request.Context(), project, root)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, cols)
}

func (t *Tracker) CreateColumn(c *gin.Context) {
	var req entity.CreateColumnRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	req.Project = c.Param("project")

	if err := t.uc.CreateColumn(c.Request.Context(), req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, req)
}

func (t *Tracker) UpdateColumn(c *gin.Context) {
	id := c.Param("id")
	var req entity.UpdateColumnRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.UpdateColumn(c.Request.Context(), id, req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, req)
}

func (t *Tracker) DeleteColumn(c *gin.Context) {
	var req entity.DeleteColumnParams
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	id := c.Param("id")
	project := c.Param("project")
	if err := t.uc.DeleteColumn(c.Request.Context(), id, project, req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "deleted"})
}

func (t *Tracker) SearchEntities(c *gin.Context) {
	var req entity.SearchRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	req.Project = c.Param("project")

	results, err := t.uc.SearchEntities(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, results)
}

func (t *Tracker) CreateEntity(c *gin.Context) {
	var req entity.CreateEntityRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.CreateEntity(c.Request.Context(), req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"message": "created"})
}

func (t *Tracker) AcquireEditLocks(c *gin.Context) {
	var req entity.AcquireEditLocksRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	token, err := t.uc.AcquireEditLocks(c.Request.Context(), c.Param("project"), req)
	if err != nil {
		writeTrackerError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"lock_token": token})
}

func (t *Tracker) RenewEditLocks(c *gin.Context) {
	var req entity.LockTokenRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.RenewEditLocks(c.Request.Context(), c.Param("project"), req.LockToken); err != nil {
		writeTrackerError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "renewed"})
}

func (t *Tracker) ReleaseEditLocks(c *gin.Context) {
	var req entity.LockTokenRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.ReleaseEditLocks(c.Request.Context(), c.Param("project"), req.LockToken); err != nil {
		writeTrackerError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "released"})
}

func (t *Tracker) UpdateEntity(c *gin.Context) {
	id := c.Param("id")
	var req entity.UpdateEntityRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.UpdateEntity(c.Request.Context(), id, req); err != nil {
		writeTrackerError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "updated"})
}

func (t *Tracker) BulkUpdateEntities(c *gin.Context) {
	var req entity.BulkUpdateEntitiesRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.BulkUpdateEntities(c.Request.Context(), c.Param("project"), req); err != nil {
		writeTrackerError(c, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "updated"})
}

func (t *Tracker) DeleteEntity(c *gin.Context) {
	id := c.Param("id")
	var req entity.DeleteEntityParams
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.DeleteEntity(c.Request.Context(), id, req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "deleted"})
}

func (t *Tracker) GetHistory(c *gin.Context) {
	id := c.Param("id")
	hist, err := t.uc.GetHistories(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, hist)
}

func (t *Tracker) RollbackEntity(c *gin.Context) {
	id := c.Param("id")
	var req entity.RollbackRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := t.uc.RollbackTarget(c.Request.Context(), id, req); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "rollback success"})
}
