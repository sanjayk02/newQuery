"""Client-side lifecycle management for temporary tracker edit locks.

The tracker server is the source of truth.  This module deliberately keeps no
shared state between users: it only obtains a server-issued lock token, renews
it while an editor is open, and releases it when editing ends.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from ppui.PySide.QtCore import QObject, QTimer, Signal

if TYPE_CHECKING:
    from .apiClient import ApiClient


LockScope = Literal['entity', 'cell']


@dataclass(frozen=True)
class LockTarget:
    """One server-side lock target.

    ``fieldKey`` is required for a cell lock and is omitted for an entity lock.
    The server must acquire a list of targets atomically for bulk editing.
    """

    entityID: str
    scope: LockScope
    fieldKey: str | None = None

    def asPayload(self) -> dict[str, str]:
        payload = {'entity_id': self.entityID, 'lock_scope': self.scope}
        if self.fieldKey:
            payload['field_key'] = self.fieldKey
        return payload


@dataclass(frozen=True)
class EditLock:
    """A handle for one server-issued lock session."""

    token: str
    targets: tuple[LockTarget, ...]


class EditLockManager(QObject):
    """Owns edit-lock sessions opened by this PPI Tracker window.

    A timer renews locks before their server expiry.  If renewal fails, the
    caller receives ``lockLost``.  The subsequent save still carries the lock
    token, so the server must reject it rather than allow an unsafe overwrite.
    """

    lockLost = Signal(str)

    def __init__(self, api: 'ApiClient', parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._api = api
        self._locks: dict[str, EditLock] = {}
        self._renewTimer = QTimer(self)
        self._renewTimer.setInterval(60_000)
        self._renewTimer.timeout.connect(self._renewAll)

    def acquireCell(self, entityID: str, fieldKey: str) -> EditLock:
        return self.acquire((LockTarget(str(entityID), 'cell', fieldKey),))

    def acquireEntities(self, entityIDs: list[str]) -> EditLock:
        targets = tuple(LockTarget(str(entityID), 'entity') for entityID in entityIDs)
        if not targets:
            raise ValueError('At least one entity is required to start editing.')
        return self.acquire(targets)

    def acquire(self, targets: tuple[LockTarget, ...]) -> EditLock:
        token = self._api.acquireEditLocks([target.asPayload() for target in targets])
        lock = EditLock(token=token, targets=targets)
        self._locks[token] = lock
        if not self._renewTimer.isActive():
            self._renewTimer.start()
        return lock

    def release(self, lock: EditLock | None) -> None:
        if lock is None or lock.token not in self._locks:
            return
        try:
            self._api.releaseEditLocks(lock.token)
        finally:
            self._locks.pop(lock.token, None)
            if not self._locks:
                self._renewTimer.stop()

    def releaseAll(self) -> None:
        for lock in list(self._locks.values()):
            try:
                self.release(lock)
            except Exception:
                # Expiry on the server is the final safety net during shutdown.
                pass

    def _renewAll(self) -> None:
        for lock in list(self._locks.values()):
            try:
                self._api.renewEditLocks(lock.token)
            except Exception:
                self._locks.pop(lock.token, None)
                self.lockLost.emit(lock.token)
        if not self._locks:
            self._renewTimer.stop()
