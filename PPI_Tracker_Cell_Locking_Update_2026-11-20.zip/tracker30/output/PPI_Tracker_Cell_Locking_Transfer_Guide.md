# PPI Tracker Cell Locking Update

Created: 20 November 2026

## Included desktop-client files

- `tracker30/src/ppiTracker/editLockManager.py` — new lock lifecycle manager.
- `tracker30/src/ppiTracker/apiClient.py` — calls acquire, renew, release and bulk-update APIs.
- `tracker30/src/ppiTracker/mainWindow.py` — starts and releases locks for direct edits, Edit Entity, multi-row edit and clear-content actions.
- `tracker30/src/ppiTracker/entityEditorDialog.py` — sends the active lock token when saving.

## Included backend files

- `server/entity/editLock.go` — MongoDB lock models and API request structures.
- `server/entity/tracker.go` — adds `lock_token` to entity updates.
- `server/repository/tracker.go` — MongoDB lock storage, expiry, conflict checks, validation, indexes and transactions.
- `server/usecase/tracker.go` — lock operations and atomic bulk-update use case.
- `server/delivery/tracker.go` — HTTP handlers and HTTP 409 conflict responses.
- `server/main.go` — routes.

## Backend routes

- `POST /api/projects/:project/tracker/edit-locks/acquire`
- `POST /api/projects/:project/tracker/edit-locks/renew`
- `DELETE /api/projects/:project/tracker/edit-locks/release`
- `POST /api/projects/:project/tracker/entities/bulk-update`

## Important transfer instructions

The existing desktop files may contain other ongoing local changes. Compare and merge the desktop files with the work-system versions; do not blindly overwrite them.

The server code requires Go 1.22 and a MongoDB deployment that supports transactions (replica set). Before deployment, run:

```powershell
gofmt -w entity/editLock.go entity/tracker.go repository/tracker.go usecase/tracker.go delivery/tracker.go main.go
go test ./delivery ./usecase ./repository ./entity
```

Deploy the desktop and server changes together. After the server requires `lock_token`, an older desktop client cannot save edits safely.
