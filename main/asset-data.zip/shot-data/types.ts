import { TableCellProps } from "@material-ui/core/TableCell";
import { ReactElement } from "react";
import { Project } from '../../types';
import { group } from "console";


export type ShotsDataTableProps = {
    project:        Project | null | undefined;
    shots:          ShotPivot[];
    tableFooter:    React.ReactElement;
    dateTimeFormat: Intl.DateTimeFormat;
    columnsState:   ColumnState;
    sortKey:        string;
    sortDir:        'asc' | 'desc';
    onSortChange:   (key: string) => void;
    total:          {[group1: string]: number};
    phaseComponents: { [key: string]: string[] };
    group1Totals?:    { [group1: string]: { totalShots: number; totalGroup2s: number } };
    group2Totals?:    { [key: string]: number};
    camDataTypes:    { [shotKey: string]: string };
    selectedCellIds?: Set<string>;
    onCellSelect?:    (cellId: string) => void;
    selectedRowId?:   string | null;
    onRowSelect?:     (rowId: string | null) => void;
};

export type RecordTableHeadProps = {
  columns: Column[],
  phaseComponents: { [key: string]: string[] },
  latestComponents: LatestComponents,
  columnsState: ColumnState,
  sortKey: string,
  sortDir: 'asc' | 'desc',
  onSortChange: (key: string) => void,
};

export type Colors = Readonly<{
    lineColor:       string;
    backgroundColor: string;
}>;

export type Column = Readonly<{
    id:      string;
    label:   string;
    colors?: Colors;
    align?:  TableCellProps['align'];
    fixed?:  boolean;
}>;

export type ColumnState = {
    [key: string]: boolean;
};

export type PageProps = Readonly<{
    page:        number;
    rowsPerPage: number;
}>;

export type ReviewInfo = {
    task_id:          string;
    project:          string;
    take_path:        string;
    root:             string;
    relation:         string;
    phase:            string;
    component:        string;
    take:             string;
    approval_status:  string;
    work_status:      string;
    submitted_at_utc: string;
    submitted_user:   string;
    modified_at_utc:  string;
    id:               number;
    groups:           string[];
    group_1:          string;
    review_comments:  ReviewComment[];
};

type ReviewComment = {
    text:             string;
    language:         string;
    attachments:      string[];
    is_translated:    boolean;
    need_translation: boolean;
};

export type Shot = Readonly<{
    groups:   string[];
    relation: string;
}>;

export type FilterProps = Readonly<{
  assetNameKey: string;
  applovalStatues: string[];
  workStatues: string[];
}>;

export type ChipDeleteFunction = (value: string) => void;

export type ShotRowProps = Readonly<{
  shot: Shot,
  reviewInfos: { [key: string]: ReviewInfo },
  thumbnails: { [key: string]: string },
  phaseComponents: { [key: string]: string[] },
  latestComponents:{ [key: string]: string[] },
  dateTimeFormat: Intl.DateTimeFormat,
  isLastRow: boolean,
  columnsState: ColumnState,

}>;

export type LatestShotComponentDocument = Readonly<{
    component:        string;
    groups:           string[];
    phase:            string;
    submitted_at_utc: string;
}>;

type LatestComponent = Readonly<{
    component:       string;
    latest_document: LatestShotComponentDocument;
}>;

export type LatestComponents = {
    [key: string]: LatestComponent[];
};

export type LatestShotComponentDocumentsResponse = Readonly<{
    component:       string;
    latest_document: LatestShotComponentDocument;
}>;


/* ── New Shot Pivot Types ───────────────────────────────────────────────── */
export type PhaseData = {
    work_status:      string | null;
    approval_status:  string | null;
    submitted_at_utc: string | null;
    take:             string | null;
};

export type ShotPivot = {
    root:      string;
    project:   string;
    group_1:   string;
    group_2:   string;
    group_3:   string;
    relation:  string;
    component: string;
    phases:    { [key: string]: PhaseData };
};

export type ShotPivotResponse = {
    items:    ShotPivot[];
    total:    number;
    page:     number;
    perPage:  number;
    pageLast: number;
    hasNext:  boolean;
    hasPrev:  boolean;
    sort:     string;
    dir:      string;
    groupCounts: { [key: string]: number };
};

export type ShotCamDataTypesResponse = {
    items: { [shotKey: string]: string};
};

export type ReviewShotsPivotResponse = {
    items:    ShotPivot[];
    phases:   string[];   // dynamic phase list for building columns
    total:    number;
    page:     number;
    perPage:  number;
    pageLast: number;
    hasNext:  boolean;
    hasPrev:  boolean;
    sort:     string;
    dir:      string;
};