/**
 * AssetsRowPanel.tsx
 *
 * Your route is importing `./assets-row/AssetsRowPanel.tsx`.
 * The first draft landed as `AssetsRowTablePanel.tsx`.
 * This file simply re-exports the same component so the build succeeds.
 */

import AssetsRowTablePanel from './AssetsRowTablePanel';

export default AssetsRowTablePanel;
