"""Temporary local-only edit locks for UI testing.

Enabled only with ``PPI_TRACKER_LOCK_MODE=demo``.  It is intentionally kept
separate from the production lock manager: each computer has its own SQLite
file, so it must never be used as a replacement for the shared backend.
"""
from __future__ import annotations

import os
from pathlib import Path
import secrets
import sqlite3
import tempfile
import time
from typing import Any


class DemoLockConflictError(RuntimeError):
    def __init__(self, user: str, studio: str) -> None:
        self.user = user
        self.studio = studio
        owner = user or 'another user'
        if studio:
            owner += f' ({studio})'
        super().__init__(f'This item is currently being edited by {owner}.')


class DemoLockStore:
    """A small SQLite implementation used only for a same-computer demo."""

    def __init__(self) -> None:
        configuredPath = os.environ.get('PPI_TRACKER_DEMO_LOCK_DB', '')
        self._path = Path(configuredPath) if configuredPath else Path(tempfile.gettempdir()) / 'ppi_tracker_demo_locks.sqlite3'
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._path, timeout=10, isolation_level=None)

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute(
                '''
                CREATE TABLE IF NOT EXISTS edit_locks (
                    token TEXT NOT NULL,
                    project TEXT NOT NULL,
                    entity_id TEXT NOT NULL,
                    lock_scope TEXT NOT NULL,
                    field_key TEXT NOT NULL DEFAULT '',
                    username TEXT NOT NULL,
                    studio TEXT NOT NULL,
                    expires_at REAL NOT NULL
                )
                ''',
            )
            connection.execute(
                'CREATE INDEX IF NOT EXISTS idx_demo_lock_target '
                'ON edit_locks(project, entity_id, expires_at)',
            )
            connection.execute(
                'CREATE INDEX IF NOT EXISTS idx_demo_lock_token '
                'ON edit_locks(token, expires_at)',
            )

    def acquire(
        self,
        project: str,
        targets: list[dict[str, str]],
        user: str,
        studio: str,
    ) -> str:
        now = time.time()
        token = secrets.token_urlsafe(32)
        with self._connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            try:
                connection.execute('DELETE FROM edit_locks WHERE expires_at <= ?', (now,))
                for target in targets:
                    entityID = str(target.get('entity_id', ''))
                    scope = str(target.get('lock_scope', ''))
                    fieldKey = str(target.get('field_key', ''))
                    if not entityID or scope not in ('entity', 'cell'):
                        raise ValueError('Invalid demo lock target.')
                    if scope == 'cell' and not fieldKey:
                        raise ValueError('A cell lock requires a field key.')
                    if scope == 'entity':
                        query = (
                            'SELECT username, studio FROM edit_locks '
                            'WHERE project = ? AND entity_id = ? AND expires_at > ? LIMIT 1'
                        )
                        params: tuple[Any, ...] = (project, entityID, now)
                    else:
                        query = (
                            'SELECT username, studio FROM edit_locks '
                            'WHERE project = ? AND entity_id = ? AND expires_at > ? '
                            'AND (lock_scope = \'entity\' OR (lock_scope = \'cell\' AND field_key = ?)) '
                            'LIMIT 1'
                        )
                        params = (project, entityID, now, fieldKey)
                    conflict = connection.execute(query, params).fetchone()
                    if conflict is not None:
                        raise DemoLockConflictError(str(conflict[0]), str(conflict[1]))
                expiresAt = now + 300
                for target in targets:
                    connection.execute(
                        'INSERT INTO edit_locks '
                        '(token, project, entity_id, lock_scope, field_key, username, studio, expires_at) '
                        'VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        (
                            token, project, str(target['entity_id']),
                            str(target['lock_scope']), str(target.get('field_key', '')),
                            user, studio, expiresAt,
                        ),
                    )
                connection.execute('COMMIT')
            except Exception:
                connection.execute('ROLLBACK')
                raise
        return token

    def renew(self, token: str) -> None:
        with self._connect() as connection:
            result = connection.execute(
                'UPDATE edit_locks SET expires_at = ? WHERE token = ? AND expires_at > ?',
                (time.time() + 300, token, time.time()),
            )
            if result.rowcount == 0:
                raise ValueError('The demo lock is missing or has expired.')

    def release(self, token: str) -> None:
        with self._connect() as connection:
            connection.execute('DELETE FROM edit_locks WHERE token = ?', (token,))
